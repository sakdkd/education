<form method="post" action="upload.php" enctype="multipart/form-data">


<input type="file" name="upload" />
<input type="submit" name="submit" value="submit" />
</form>