<div class="footer-widget-area wow fadeInUp">
    <div class="container">
        <div class="row">
             <div class="col-md-3">
                <div class="footer-single-widget">
                    <h4 class="widget-title">COMPANY AND LOGO</h4>
                    
                    <ul>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                            
                        </ul>
                </div>
            </div>
			 <div class="col-md-3">
                <div class="footer-single-widget">
                    <h4 class="widget-title">COMPANY AND LOGO</h4>
                      <ul>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                            <li><a href="#">COMPANY NAME</a> <span style="margin-left:20%;"><img src="assets/img/clogo.png"></span></li>
                          
                        </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-single-widget">
                    <h4 class="widget-title">TOP DESTINATIONS</h4>
                    <ul>
                            <li><a href="#">EUROPE TOUR</a></li>
                            <li><a href="#">SCOTT DOWN  </a></li>
                            <li><a href="#">SHEARINGS</a></li>
                            <li><a href="#">SOUTHALL TRAVEL</a></li>
                            <li><a href="#">KASHMIR TOUR</a></li>
                        </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-3">
                <div class="footer-single-widget-cta">
                    <h4 class="widget-title">Contact us</h4>
                  
                    
                    <span class="icon-float-left">
                        <i class="zmdi zmdi-home"></i>
                    </span>
                    <span class="widget-content">
                       Al Aqiq, 7080, Prince Muhammad lbn Saad Ibn Abdulaziz Rd, Hittin, Riyadh
                    </span>
                   <br> <a href="#"><i class="fa fa-phone"></i> 1800 123 5555</a>
                </div>
            </div>
           
        </div>
    </div>
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                 <div class="col-md-10 col-xs-12">
                     <div class="footer-bottom">
                        <ul>
                            <li><a href="aboutus.php">ABOUT US</a></li>
                            <li><a href="tourguide.php">TOUR GUIDE</a></li>
                            <li><a href="payment.php">PAYMENT TERMS</a></li>
                            <li><a href="privacy.php">PRIVACY POLICY</a></li>
                            <li><a href="contactus.php">CONTACT US</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-2 col-xs-12">
                      <div class="footer-bottom-social">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                
                            </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--  footer widget area end -->
    <!-- jquery.js -->
    <script src="assets/js/jquery.js"></script>
    <!-- jquery.popper.min.js -->
    <script src="assets/js/popper.min.js"></script>
    <!-- bootstrap.min.js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- jquery.slicknav.min.js -->
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <!-- nice select.js -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- jquery.magnific.min.js -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- jquery.inview.js -->
    <script src="assets/js/inview.js"></script>
    <!-- jquery.counter.js -->
    <script src="assets/js/counter.js"></script>
    <!-- jquery.owl.min.js -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- jquery.masonry.min.js -->
    <script src="assets/js/masonary.js"></script>
    <!-- jquery.wow.min.js -->
    <script src="assets/js/wow.min.js"></script>
    <!-- main.js -->
    <script src="assets/js/main.js"></script>
	<script>
		$(document).ready(function() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
});
	</script>