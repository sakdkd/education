<?php


ob_start();
session_start();
unset($_SESSION['cart_array']);

?>