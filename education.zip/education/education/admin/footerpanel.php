



<footer>

          <div class="pull-right">

           <!-- Gentelella - Bootstrap Admin Template by <a href="#https://colorlib.com">Colorlib</a>-->

          </div>

          <div class="clearfix"></div>

        </footer>

         <!-- jQuery -->

    <script src="../assets/js/jquery-1.12.4.min.js"></script>
   <script src="../assets/js/jquery.validate.min.js"></script>
    <script src="../javascript/scripts.js"></script>

    <!-- Bootstrap -->

    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- FastClick -->

    <script src="vendors/fastclick/lib/fastclick.js"></script>

    <!-- NProgress -->

    <script src="vendors/nprogress/nprogress.js"></script>

                <script src="../ckeditor/ckeditor.js"></script>
                <script src="../ckeditor/build-config.js"></script>

<!--<script src="//cdn.ckeditor.com/4.11.4/full/ckeditor.js"></script>-->
    <!-- Custom Theme Scripts -->

    <script src="build/js/custom.min.js"></script>