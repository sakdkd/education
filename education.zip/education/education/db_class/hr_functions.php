 <?php
include_once('dbconfig.php');
include_once('sendgrid-php/vendor/autoload.php'); // If you're using Composer (recommended)
 
  function getservice_form_details_from_id($conn,$code,$type){
	 
	$ds=mysqli_query($conn,"SELECT * FROM `services` where `id`='$code' and `requesttype`='$type'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
} 

 function getchildcaredetails_from_sid($conn,$code,$servicetype){
	 
	if($servicetype=='2')
	{
		
		$table='childcaredetails';
		
	}
	
	if($servicetype=='3')
	{
		
		$table='elderlycaredetails';
		
	}
		if($servicetype=='4')
	{
		
		$table='cookingdetails';
		
	}
	
	
		if($servicetype=='5')
	{
		
		$table='housekeepingdetails';
		
	}
	
	$ds=mysqli_query($conn,"SELECT * FROM $table where `service_id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
} 

 function getservice_typefromsid($conn,$code){
	 
	$ds=mysqli_query($conn,"SELECT `servicetype` FROM `services` where `id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['servicetype'];
 
}

 function getpost_replytabledetails($conn,$serviceid,$request){
	 
	$ds=mysqli_query($conn,"SELECT * FROM `postreply` where `service_id`='$serviceid' and `requesttype`='$request'"); 
	$dsr=mysqli_num_rows($ds);
	return $dsr;
 
}



 function getrecordidfromrequestandservice($conn,$request,$service){
	 
	$ds=mysqli_query($conn,"SELECT `id` FROM `services` where `servicetype`='$service' and `requesttype`='$request'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['id'];
 
}

function gettestidetails($conn,$code){
	 
	$ds=mysqli_query($conn,"SELECT * FROM `testimonial` where `id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
}

function getdestinationdetails($conn,$code){
	$ds=mysqli_query($conn,"SELECT * FROM `destination` where `id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getbannerdetails($conn,$code){
	$ds=mysqli_query($conn,"SELECT * FROM `banner` where `id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function getinclusiondetails($conn,$code){
	$ds=mysqli_query($conn,"SELECT * FROM `inclusions` where `id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}


function getdestinationNameById($conn,$did){
	$ds=mysqli_query($conn,"SELECT `name` FROM `destination` where `id`='$did'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getdestinationIdByCountryId($conn,$did){
	$ds=mysqli_query($conn,"SELECT `destinationid` FROM `country` where `id`='$did'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['destinationid'];
}

function getCountryIdBylocationId($conn,$did){
	$ds=mysqli_query($conn,"SELECT `countryid` FROM `location` where `id`='$did'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['countryid'];
}
function getcountrydetails($conn,$code){
	$ds=mysqli_query($conn,"SELECT * FROM `country` where `id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function getcountryNameById($conn,$did){
	$ds=mysqli_query($conn,"SELECT `name` FROM `country` where `id`='$did'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}

function getlocationdetails($conn,$code){
	$ds=mysqli_query($conn,"SELECT * FROM `location` where `id`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function getlocationNameById($conn,$did){
	$ds=mysqli_query($conn,"SELECT `name` FROM `location` where `id`='$did'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}



 function getpostreplydetailsfromsidandtype($conn,$sid,$type){
	$ds=mysqli_query($conn,"SELECT * FROM `postreply` where `requesttype`='$type' and `service_id`='$sid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
}

function getpostreplycountidandtype($conn,$sid,$type){
	 
	$ds=mysqli_query($conn,"SELECT * FROM `postreply` where `requesttype`='$type' and `service_id`='$sid'"); 
	$ds1=mysqli_num_rows($ds);
	return $ds1;
 
}
 function associatenamefromcode($conn,$code){
	 
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['first_name']." ".$ds1['middle_name']." ".$ds1['last_name'];
 
} 
 
 function associatenamefromid($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_detail_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['first_name']." ".$ds1['middle_name']." ".$ds1['last_name'];
 
} 

 function associatenameandmobilefromid($conn,$id){
	$ds=mysqli_query($conn,"SELECT  concat(`first_name`,' ',`last_name`) as name,`contact_no` as mobile ,`associate_detail_id` as aid FROM `mlm_associate_detail` where `associate_detail_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
} 


function associatecodefromid($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_detail_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	return $ds1['associate_code'];
 
} 
function getassociatedetailsbyid($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_detail_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	return $ds1;
 
} 

function associateidfromcode($conn,$code){
	//echo "SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'";
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['associate_detail_id'];
 
} 
function associateContactfromcode($conn,$code){
	//echo "SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'";
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['contact_no'];
 
} 


function associatePrimaryContactfromcode($conn,$code){
	//echo "SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'";
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	$contact= trim($ds1['contact_no']);
	return substr($contact,0,10);
 
} 

function associateMobilefromid($conn,$id){
	//echo "SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'";
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_detail_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['contact_no'];
 
}


//////////////////////////////  ////////////////////// / functions made by sagar ///////////////////////////////////////////////////////////////////////////////




function getSlotNameById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `slots` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getSlotTimingById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `slots` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['startsfrom'];
}
function getModuleNameById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `seminars` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['code'];
}


function getModuleNameANdTitleById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `seminars` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['code']." - ".$ds1['title'];
}
function getModuleSeatsById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `seminars` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['seats'];
}
function getModuleNameAndCodeById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `seminars` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['code']." - ".$ds1['title']." ( ".$ds1['duration']." mins ) ";
}





function getModuleDurationById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `seminars` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['duration'];
}

function getRoasterDetailById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `roasters` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function getRoasterRemarksById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT `remarks` FROM `roasters` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['remarks'];
}
function getRoasterDetailsDetailById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `roasterdetails` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getRoasterDetailsDetailByRoasterId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `roasterdetails` where `roaster_id`='$id' and `view` ='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $data[]=$fetch['module_id']."##".$fetch['slot_id'];
		}
	}
	//$improaster=implode(",",$data);
	return $data;
}

 function getDesignationAttheTimeofSaleBySaleIdAndAssId($conn,$aid,$saleid){
	// echo "SELECT * FROM `mlm_associate_calculate` where `sales_details_id`='$saleid' and `associate_detail_id` ='$aid'";
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_calculate` where `sales_details_id`='$saleid' and `associate_detail_id` ='$aid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['desigination_id'];
 
}

function checkReraStatusByAssociateId($conn,$aid){ 
	//echo "SELECT * FROM `mlm_assiciate_desigination` where `desigination_name`='$desg'";
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_detail_id`='$aid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	if(  ($ds1['rara_number']=='') || ($ds1['rara_number']=='NULL') || ($ds1['rera_rk_approval']=='0')){
		return false;	
	}else{
		return true;	
	}
 
}


function checkReraStatusByAssociateIdWithEmpCheck($conn,$aid){ 
	//echo "SELECT * FROM `mlm_assiciate_desigination` where `desigination_name`='$desg'";
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where `associate_detail_id`='$aid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	$emptype=$ds1['emp_type'];
	if($emptype==2){
		
		return true;
	}else{
	
	if(  ($ds1['rara_number']=='') || ($ds1['rara_number']=='NULL') || ($ds1['rera_rk_approval']=='0')){
		return false;	
	}else{
		return true;	
	}
	
	}
 
}

function getRoasterDescriptionById($conn,$id){
	//echo "SELECT * FROM `roasterdetails` where `roaster_id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `roasterdetails` where `roaster_id`='$id' and `view`='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $data[]=getSlotNameById($conn,$fetch['slot_id'])." - ".getModuleNameById($conn,$fetch['module_id']);
		}
	}
	$improaster=implode(",",$data);
	return $improaster;
	
 }
 
 function getRoasterDescriptionWithTitleById($conn,$id){
	//echo "SELECT * FROM `roasterdetails` where `roaster_id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `roasterdetails` where `roaster_id`='$id' and `view`='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
			$remark=$fetch['description'];
			if($remark!=''){
$data[]="<b style='color:blue;'>".getSlotNameById($conn,$fetch['slot_id'])." </b>- ".getModuleNameAndTitleById($conn,$fetch['module_id'])." -<b style='color:red;'>(".$remark.")</b>";

			}else{

				$data[]="<b style='color:blue;'>".getSlotNameById($conn,$fetch['slot_id'])." </b>- ".getModuleNameAndTitleById($conn,$fetch['module_id']);
			}
		
			 
		}
	}
	$improaster=implode(",",$data);
	return $improaster;
	
 }
 
/* function getAllowedSeminarsById($conn,$impids){
	//echo "SELECT * FROM `roasterdetails` where `roaster_id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `roasterdetails` where `id` in ($impids) and `view`='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $data[]=getSlotNameById($conn,$fetch['slot_id'])." - ".getModuleNameById($conn,$fetch['module_id']);
		}
	}
	$improaster=implode(",",$data);
	return $improaster;
	
 }*/
 
 
function changeDateToSlash($conn,$date){
	$expDate=explode("-",$date);
	$newDate=$expDate[2]."/".$expDate[1]."/".$expDate[0];	
	return $newDate;
}
function changeDateToYMD($date){
	$expDate=explode("-",$date);
	$newDate=$expDate[2]."-".$expDate[1]."-".$expDate[0];	
	return $newDate;
}

function changeDateToYMDfromSlash($date){
	$expDate=explode("/",$date);
	$newDate=$expDate[2]."-".$expDate[1]."-".$expDate[0];	
	return $newDate;
}
function getMonthFull($val){
	if($val<=9){
	$val=substr($val,1,1);	
	}
$monthArr=array("","January","Febuary","March","April","May","June","July","August","September","October","November","December");
return	$monthArr[$val];
	
}

function checkRoasterExistsForDate($conn,$days,$month,$year){
	$ds=mysqli_query($conn,"SELECT * FROM `roasters` where `rdate`='$days' and `rmonth`='$month' and `ryear`='$year' and `view`='1' "); 
	$numrows=mysqli_num_rows($ds);
	if($numrows>0){
	return true;	
	}else{
	return false;	
	}
	
	
}

function getRoasterIdByDateMonthYear($conn,$days,$month,$year){
	$ds=mysqli_fetch_row(mysqli_query($conn,"SELECT * FROM `roasters` where `rdate`='$days' and `rmonth`='$month' and `ryear`='$year' and `view`='1' order by `id` desc limit 0,1 ")); 
	return $ds[0]; 
}

function getBookingId($id){
	$text="BKSM";
	$fid=1000+$id;
	$final=$text."".$fid;
	return $final; 
}


function barcode( $filepath="", $text="0", $size="80", $orientation="horizontal", $code_type="code128", $print=true, $SizeFactor=1 ) {
	$code_string = "";
	// Translate the $text into barcode the correct $code_type
	if ( in_array(strtolower($code_type), array("code128", "code128b")) ) {
		$chksum = 104;
		// Must not change order of array elements as the checksum depends on the array's key to validate final code
		$code_array = array(" "=>"212222","!"=>"222122","\""=>"222221","#"=>"121223","$"=>"121322","%"=>"131222","&"=>"122213","'"=>"122312","("=>"132212",")"=>"221213","*"=>"221312","+"=>"231212",","=>"112232","-"=>"122132","."=>"122231","/"=>"113222","0"=>"123122","1"=>"123221","2"=>"223211","3"=>"221132","4"=>"221231","5"=>"213212","6"=>"223112","7"=>"312131","8"=>"311222","9"=>"321122",":"=>"321221",";"=>"312212","<"=>"322112","="=>"322211",">"=>"212123","?"=>"212321","@"=>"232121","A"=>"111323","B"=>"131123","C"=>"131321","D"=>"112313","E"=>"132113","F"=>"132311","G"=>"211313","H"=>"231113","I"=>"231311","J"=>"112133","K"=>"112331","L"=>"132131","M"=>"113123","N"=>"113321","O"=>"133121","P"=>"313121","Q"=>"211331","R"=>"231131","S"=>"213113","T"=>"213311","U"=>"213131","V"=>"311123","W"=>"311321","X"=>"331121","Y"=>"312113","Z"=>"312311","["=>"332111","\\"=>"314111","]"=>"221411","^"=>"431111","_"=>"111224","\`"=>"111422","a"=>"121124","b"=>"121421","c"=>"141122","d"=>"141221","e"=>"112214","f"=>"112412","g"=>"122114","h"=>"122411","i"=>"142112","j"=>"142211","k"=>"241211","l"=>"221114","m"=>"413111","n"=>"241112","o"=>"134111","p"=>"111242","q"=>"121142","r"=>"121241","s"=>"114212","t"=>"124112","u"=>"124211","v"=>"411212","w"=>"421112","x"=>"421211","y"=>"212141","z"=>"214121","{"=>"412121","|"=>"111143","}"=>"111341","~"=>"131141","DEL"=>"114113","FNC 3"=>"114311","FNC 2"=>"411113","SHIFT"=>"411311","CODE C"=>"113141","FNC 4"=>"114131","CODE A"=>"311141","FNC 1"=>"411131","Start A"=>"211412","Start B"=>"211214","Start C"=>"211232","Stop"=>"2331112");
		$code_keys = array_keys($code_array);
		$code_values = array_flip($code_keys);
		for ( $X = 1; $X <= strlen($text); $X++ ) {
			$activeKey = substr( $text, ($X-1), 1);
			$code_string .= $code_array[$activeKey];
			$chksum=($chksum + ($code_values[$activeKey] * $X));
		}
		$code_string .= $code_array[$code_keys[($chksum - (intval($chksum / 103) * 103))]];

		$code_string = "211214" . $code_string . "2331112";
	} elseif ( strtolower($code_type) == "code128a" ) {
		$chksum = 103;
		$text = strtoupper($text); // Code 128A doesn't support lower case
		// Must not change order of array elements as the checksum depends on the array's key to validate final code
		$code_array = array(" "=>"212222","!"=>"222122","\""=>"222221","#"=>"121223","$"=>"121322","%"=>"131222","&"=>"122213","'"=>"122312","("=>"132212",")"=>"221213","*"=>"221312","+"=>"231212",","=>"112232","-"=>"122132","."=>"122231","/"=>"113222","0"=>"123122","1"=>"123221","2"=>"223211","3"=>"221132","4"=>"221231","5"=>"213212","6"=>"223112","7"=>"312131","8"=>"311222","9"=>"321122",":"=>"321221",";"=>"312212","<"=>"322112","="=>"322211",">"=>"212123","?"=>"212321","@"=>"232121","A"=>"111323","B"=>"131123","C"=>"131321","D"=>"112313","E"=>"132113","F"=>"132311","G"=>"211313","H"=>"231113","I"=>"231311","J"=>"112133","K"=>"112331","L"=>"132131","M"=>"113123","N"=>"113321","O"=>"133121","P"=>"313121","Q"=>"211331","R"=>"231131","S"=>"213113","T"=>"213311","U"=>"213131","V"=>"311123","W"=>"311321","X"=>"331121","Y"=>"312113","Z"=>"312311","["=>"332111","\\"=>"314111","]"=>"221411","^"=>"431111","_"=>"111224","NUL"=>"111422","SOH"=>"121124","STX"=>"121421","ETX"=>"141122","EOT"=>"141221","ENQ"=>"112214","ACK"=>"112412","BEL"=>"122114","BS"=>"122411","HT"=>"142112","LF"=>"142211","VT"=>"241211","FF"=>"221114","CR"=>"413111","SO"=>"241112","SI"=>"134111","DLE"=>"111242","DC1"=>"121142","DC2"=>"121241","DC3"=>"114212","DC4"=>"124112","NAK"=>"124211","SYN"=>"411212","ETB"=>"421112","CAN"=>"421211","EM"=>"212141","SUB"=>"214121","ESC"=>"412121","FS"=>"111143","GS"=>"111341","RS"=>"131141","US"=>"114113","FNC 3"=>"114311","FNC 2"=>"411113","SHIFT"=>"411311","CODE C"=>"113141","CODE B"=>"114131","FNC 4"=>"311141","FNC 1"=>"411131","Start A"=>"211412","Start B"=>"211214","Start C"=>"211232","Stop"=>"2331112");
		$code_keys = array_keys($code_array);
		$code_values = array_flip($code_keys);
		for ( $X = 1; $X <= strlen($text); $X++ ) {
			$activeKey = substr( $text, ($X-1), 1);
			$code_string .= $code_array[$activeKey];
			$chksum=($chksum + ($code_values[$activeKey] * $X));
		}
		$code_string .= $code_array[$code_keys[($chksum - (intval($chksum / 103) * 103))]];

		$code_string = "211412" . $code_string . "2331112";
	} elseif ( strtolower($code_type) == "code39" ) {
		$code_array = array("0"=>"111221211","1"=>"211211112","2"=>"112211112","3"=>"212211111","4"=>"111221112","5"=>"211221111","6"=>"112221111","7"=>"111211212","8"=>"211211211","9"=>"112211211","A"=>"211112112","B"=>"112112112","C"=>"212112111","D"=>"111122112","E"=>"211122111","F"=>"112122111","G"=>"111112212","H"=>"211112211","I"=>"112112211","J"=>"111122211","K"=>"211111122","L"=>"112111122","M"=>"212111121","N"=>"111121122","O"=>"211121121","P"=>"112121121","Q"=>"111111222","R"=>"211111221","S"=>"112111221","T"=>"111121221","U"=>"221111112","V"=>"122111112","W"=>"222111111","X"=>"121121112","Y"=>"221121111","Z"=>"122121111","-"=>"121111212","."=>"221111211"," "=>"122111211","$"=>"121212111","/"=>"121211121","+"=>"121112121","%"=>"111212121","*"=>"121121211");

		// Convert to uppercase
		$upper_text = strtoupper($text);

		for ( $X = 1; $X<=strlen($upper_text); $X++ ) {
			$code_string .= $code_array[substr( $upper_text, ($X-1), 1)] . "1";
		}

		$code_string = "1211212111" . $code_string . "121121211";
	} elseif ( strtolower($code_type) == "code25" ) {
		$code_array1 = array("1","2","3","4","5","6","7","8","9","0");
		$code_array2 = array("3-1-1-1-3","1-3-1-1-3","3-3-1-1-1","1-1-3-1-3","3-1-3-1-1","1-3-3-1-1","1-1-1-3-3","3-1-1-3-1","1-3-1-3-1","1-1-3-3-1");

		for ( $X = 1; $X <= strlen($text); $X++ ) {
			for ( $Y = 0; $Y < count($code_array1); $Y++ ) {
				if ( substr($text, ($X-1), 1) == $code_array1[$Y] )
					$temp[$X] = $code_array2[$Y];
			}
		}

		for ( $X=1; $X<=strlen($text); $X+=2 ) {
			if ( isset($temp[$X]) && isset($temp[($X + 1)]) ) {
				$temp1 = explode( "-", $temp[$X] );
				$temp2 = explode( "-", $temp[($X + 1)] );
				for ( $Y = 0; $Y < count($temp1); $Y++ )
					$code_string .= $temp1[$Y] . $temp2[$Y];
			}
		}

		$code_string = "1111" . $code_string . "311";
	} elseif ( strtolower($code_type) == "codabar" ) {
		$code_array1 = array("1","2","3","4","5","6","7","8","9","0","-","$",":","/",".","+","A","B","C","D");
		$code_array2 = array("1111221","1112112","2211111","1121121","2111121","1211112","1211211","1221111","2112111","1111122","1112211","1122111","2111212","2121112","2121211","1121212","1122121","1212112","1112122","1112221");

		// Convert to uppercase
		$upper_text = strtoupper($text);

		for ( $X = 1; $X<=strlen($upper_text); $X++ ) {
			for ( $Y = 0; $Y<count($code_array1); $Y++ ) {
				if ( substr($upper_text, ($X-1), 1) == $code_array1[$Y] )
					$code_string .= $code_array2[$Y] . "1";
			}
		}
		$code_string = "11221211" . $code_string . "1122121";
	}

	// Pad the edges of the barcode
	$code_length = 20;
	if ($print) {
		$text_height = 30;
	} else {
		$text_height = 0;
	}
	
	for ( $i=1; $i <= strlen($code_string); $i++ ){
		$code_length = $code_length + (integer)(substr($code_string,($i-1),1));
        }

	if ( strtolower($orientation) == "horizontal" ) {
		$img_width = $code_length*$SizeFactor;
		$img_height = $size;
	} else {
		$img_width = $size;
		$img_height = $code_length*$SizeFactor;
	}

	$image = imagecreate($img_width, $img_height + $text_height);
	$black = imagecolorallocate ($image, 0, 0, 0);
	$white = imagecolorallocate ($image, 255, 255, 255);

	imagefill( $image, 0, 0, $white );
	if ( $print ) {
		imagestring($image, 5, 31, $img_height, $text, $black );
	}

	$location = 10;
	for ( $position = 1 ; $position <= strlen($code_string); $position++ ) {
		$cur_size = $location + ( substr($code_string, ($position-1), 1) );
		if ( strtolower($orientation) == "horizontal" )
			imagefilledrectangle( $image, $location*$SizeFactor, 10, $cur_size*$SizeFactor, $img_height, ($position % 2 == 0 ? $white : $black) );
		else
			imagefilledrectangle( $image, 0, $location*$SizeFactor, $img_width, $cur_size*$SizeFactor, ($position % 2 == 0 ? $white : $black) );
		$location = $cur_size;
	}
//	$filepath="barcodes/barcode1.png";
	// Draw barcode to the screen or save in a file
	if ( $filepath=="" ) {
		header ('Content-type: image/jpeg');
		imagejpeg($image);
		imagedestroy($image);
	} else {
		imagepng($image,$filepath);
		imagedestroy($image);		
	}
}

function seminarbookingmailcontent($baseurl,$name,$moduleName,$sessionDetail,$sessiondate,$bookingid,$barcodePath){
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:center;">
                                                <h1 style="color:#606060 !important; font-family:Helvetica, Arial, sans-serif; font-size:22px; font-weight:bold; letter-spacing:-1px; line-height:115%; margin:0; padding:0; text-align:center;"><i class="fa fa-facebook-official" aria-hidden="true"></i> Dear '.$name.'</h1>
                                                <br />
                                                <br />
										   				<img src="'.$baseurl.'/barcodes/'.$barcodePath.'">
										   		<br />
										        <br/><p style="text-align:left"><br/>
												 You have successfully booked session<br/> <span style="color:#06C">'.$moduleName.' on <b>'.$sessiondate.'  ( '.$sessionDetail.' ) </b></span>
												 
												 <br/><br/>
												 <span style="text-align:left">Venue : <b style="color:#06C">Acresninches Pvt. Ltd.</b> C-26, 1st / 2nd Floor, Sector-3, Noida (U.P) - 201301  </span>
												
									            <br/><br/>Your booking referrence number is : <b>'.$bookingid.'</b><br/> (Please keep this for future use)<br/><br/><b>Note:</b> On the date of session it is mandatory to show the email either on your smart phone ,or through a printout of the email.<br/><br/>Thanks & Regards<br/><br/><b>Acres N Inches Team</b><br/><br/>If you have any query feel free to mail us at training@acresninches.in.
										</p>
												
												 
                                            </td>
                                        </tr>
                                        <tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <td align="center" valign="middle" style="padding-right:40px; padding-bottom:40px; padding-left:40px;">
                                                <table border="0" cellpadding="0" cellspacing="0" class="emailButton" style="background-color:#6DC6DD; border-collapse:separate !important; border-radius:3px;">
                                                  
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                           The information contained in and accompanying this communication may be confidential, subject to legal privilege, or otherwise protected from disclosure, and is intended solely for the use of the intended recipient(s). 
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}




function holdedmail($baseurl,$name,$otp,$hid,$inventory){ 
$unText=" <a style='color:#FFFFFF;text-decoration:none' href ='".$baseurl."/approveinventory.php?hid=".base64_encode($hid)."'>Approve Inventory</a> ";
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:center;">
                                                <h1 style="color:#606060 !important; font-family:Helvetica, Arial, sans-serif; font-size:22px; font-weight:bold; letter-spacing:-1px; line-height:115%; margin:0; padding:0; text-align:center;"><i class="fa fa-facebook-official" aria-hidden="true"></i> Dear '.$name.'</h1>
                                                <br />
                                                
												
												<br/><br/><p style="text-align:left"><br/>
												 Inventory : <span style="color:#06C">'.$inventory.'  </b></span>
												 <br/><br/>
												
										        <br/><br/><p style="text-align:left"><br/>
												 Your One Time Password is : <span style="color:#06C">'.$otp.'  </b></span>
												 <br/><br/>
												 
												  <span style="text-align:left"><span style="color:#933;">Please note   that this transaction will be valid only subject to acceptance by our <b style="border-bottom:dotted 1px #999;">accounts</b> and <b style="border-bottom:dotted 1px #999;">operations</b> department alongwith acknowledgement of the same by the concerned <b style="border-bottom:dotted 1px #999;">Developer / Builder</b>. </span></span>
												 
												 <br/><br/>
												
												 <span style="text-align:left">Please click the below button to approve  </span>
												
									          
                                                  <tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <td align="center" valign="middle" style="padding-right:40px; padding-bottom:40px; padding-left:40px;">
                                                <table border="0" cellpadding="0" cellspacing="0" class="emailButton" style="background-color:#6DC6DD; border-collapse:separate !important; border-radius:3px;">
                                                  <tr>
                                                        <td align="center" valign="middle" class="emailButtonContent" style="color:#FFFFFF; font-family:Helvetica, Arial, sans-serif; font-size:15px; font-weight:bold; line-height:100%; padding-top:18px; padding-right:15px; padding-bottom:15px; padding-left:15px;">'.$unText.'</td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                           The information contained in and accompanying this communication may be confidential, subject to legal privilege, or otherwise protected from disclosure, and is intended solely for the use of the intended recipient(s). 
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}



function sendElasticEmail($to,$from,$subject,$message){
	
	
	$url = 'https://api.elasticemail.com/v2/email/send';

try{
      $post = array('from' => $from,
                    'fromName' => 'Acresninches',
                    'apikey' => 'ec9e9ab5-d3ba-4876-b148-b1f56b1e6821',
                    'subject' => $subject,
                    'bodyHtml' => $message,
                    //'bodyText' => $message,
                    'isTransactional' => true,
					'to'=>$to,
                   );
      
      $ch = curl_init();
          
      curl_setopt_array($ch, array(
          CURLOPT_URL => $url,
          CURLOPT_POST => true,
          CURLOPT_POSTFIELDS => $post,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_HEADER => false,
          CURLOPT_SSL_VERIFYPEER => false
      ));
      
      $result=curl_exec ($ch);
      curl_close ($ch);
      
    //  echo $result;    
}
catch(Exception $ex){
  echo $ex->getMessage();
}
	
	
	

	/*$headers = 'MIME-Version: 1.0 \r\n'.
		'Content-type: text/html \r\n'.
		'X-Mailer: PHP/' . phpversion();
		$mail = new PHPMailer();
		$mail->IsSMTP();                                      // Set mailer to use SMTP
		
		$mail->IsHTML(true);
		$mail->From = $from;
		$mail->FromName =$fromname;
		
		$mail->SMTPAuth = true;
		$mail->Host = $smtphost;  // specify main and backup server
		$mail->Username = $smtpusername;  // SMTP username
		$mail->Password = $smtppassword; // SMTP password
		$mail->Port = 587;
		$mail->AddAddress($to);
		$mail->Subject = $subject;
		$mail->Body    = $msg;
		$mail=$mail->Send();
		if($mail){
		return true;
		}else{
		return false;
		}*/
}

function getSeminarBookingDetailById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `seminarbookings` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function scheduleAlreadyBooked($conn,$roasterdetailid,$associd){
	
	//echo "SELECT * FROM `seminarbookings` where `roaster_id`='$roasterdetailid' and `assoc_id`='$associd' ";
	$ds=mysqli_query($conn,"SELECT * FROM `seminarbookings` where `roaster_detail_id`='$roasterdetailid' and `assoc_id`='$associd' and `status`='1' "); 
	$numrows=mysqli_num_rows($ds);
	if($numrows>0){
	return true;	
	}else{
	return false;	
	}
}

function getAlreadyBookedDetails($conn,$roasterdetailid,$associd){
	
	//echo "SELECT * FROM `seminarbookings` where `roaster_id`='$roasterdetailid' and `assoc_id`='$associd' ";
	$ds=mysqli_query($conn,"SELECT `barcodeno` FROM `seminarbookings` where `roaster_detail_id`='$roasterdetailid' and `assoc_id`='$associd' and `status`='1' "); 
	$numrows=mysqli_fetch_assoc($ds);
	return $numrows['barcodeno'];
}


function getAlreadyBookedId($conn,$roasterdetailid,$associd){
	
	//echo "SELECT * FROM `seminarbookings` where `roaster_id`='$roasterdetailid' and `assoc_id`='$associd' ";
	$ds=mysqli_query($conn,"SELECT `id` FROM `seminarbookings` where `roaster_detail_id`='$roasterdetailid' and `assoc_id`='$associd' and `status`='1' "); 
	$numrows=mysqli_fetch_assoc($ds);
	return $numrows['id'];
}

function getSeatsLeft($conn,$date,$sid,$mid){
	$rids=array();
	$expDate=explode("-",$date);
	$totalSeatLeft=getModuleSeatsById($conn,$mid);
	$radte=$expDate[2];
	$rmonth=$expDate[1];
	$ryear=$expDate[0];
	//echo "SELECT * FROM `roasters` where `rdate`='$radte' and `rmonth`='$rmonth' and `ryear`='$ryear' and `view`='1'";
	$flag=1;
	$ds=mysqli_query($conn,"SELECT * FROM `roasters` where `rdate`='$radte' and `rmonth`='$rmonth' and `ryear`='$ryear' and `view`='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $rids[]=$fetch['id'];
		}
	}else{
	//$flag=0;	
	}
	if(count($rids)>0){
	$impids=implode(",",$rids);
	//echo "SELECT count(*) FROM `roasterdetails` where `roaster_id` in ($impids) and `slot_id`='$sid' and `module_id`='$mid' and `view`='1'";
	//$ds=mysqli_fetch_row(mysqli_query($conn,"SELECT count(*) FROM `roasterdetails` where `roaster_id` in ($impids) and `slot_id`='$sid' and `module_id`='$mid' and `view`='1'"));
	
	//echo "SELECT * FROM `roasters` where `roaster_id` in ($impids) and  `view`='1'";
	$ds=mysqli_query($conn,"SELECT * FROM `roasterdetails` where `roaster_id` in ($impids) and   `view`='1'  and `slot_id`='$sid' and `module_id`='$mid'"); 
	$numrows=mysqli_num_rows($ds);

		while($fetch=mysqli_fetch_array($ds)){
		
			 $rdids[]=$fetch['id'];
		}
	
	 if(count($rdids)>0){
		
	   $imprdids=implode(",",$rdids);	
	 }else{
		$imprdids=0;
	 }
//	echo "SELECT count(*) FROM `seminarbookings` where `roaster_detail_id` in ($imprdids) and `status`='1'";
	
	$ds=mysqli_fetch_row(mysqli_query($conn,"SELECT count(*) FROM `seminarbookings` where `roaster_detail_id` in ($imprdids) and `status`='1'"));
	
	 $totalSeatLeft=$totalSeatLeft-$ds[0];
		
	} 
	
	return $totalSeatLeft;
	
	
	
	
}

function getCurrentAllowedRoasters($conn){
	$rids=array();
	
	$date=date("d");
	$month=date("m");
	$year=date("Y");
	echo  $hour = date('H');

	 echo $minutes = date('i');
	
	if($date<=9){
		$date=substr($date,1,1);
	}
	
	//echo "SELECT * FROM `roasters` where `view`='1' and `rdate`='$date' and `rmonth`='$month' and `ryear`='$year' order by `id` desc limit 0,1 ";die;
	$ds=mysqli_query($conn,"SELECT * FROM `roasters` where `view`='1' and `rdate`='$date' and `rmonth`='$month' and `ryear`='$year' order by `id` desc limit 0,1 "); 
	$numrows=mysqli_num_rows($ds);
	if($numrows>0){
		$ds1=mysqli_fetch_assoc($ds);	
		$roasterid=$ds1['id'];
		//echo "SELECT * FROM `roasterdetails` where `roaster_id`='$roasterid'  and `view`='1'";
		$ds2=mysqli_query($conn,"SELECT * FROM `roasterdetails` where `roaster_id`='$roasterid'  and `view`='1'"); 
	    $numrows2=mysqli_num_rows($ds2);
	if($numrows2 >0){
		while($fetch=mysqli_fetch_array($ds2)){
		echo $slot_id = $fetch['slot_id'];
		// $rids[]=$fetch['id'];
		if($slot_id == 1 && ( ($hour == 10 &&  $minutes > 15) || ($hour == 11 &&  $minutes <= 30) ))
			$rids[]=$fetch['id'];
			if($slot_id == 2 && ( ($hour == 14 &&  $minutes > 15) || ($hour == 15 &&  $minutes <= 30) )  )
			$rids[]=$fetch['id'];
			if($slot_id == 3 && (($hour == 15 &&  $minutes > 15) || ($hour == 16 &&  $minutes <= 30)))
			$rids[]=$fetch['id'];
			if($slot_id == 4 && (($hour == 15 &&  $minutes > 0) || ($hour == 15 &&  $minutes <= 32)))
			$rids[]=$fetch['id'];
			/*if($slot_id == 4 && (($hour == 15 &&  $minutes > 15) || ($hour == 15 &&  $minutes <= 32)))
			$rids[]=$fetch['id'];*/
			if($slot_id == 5 && (($hour == 13 &&  $minutes > 0) || ($hour == 13 &&  $minutes <= 45)))
			$rids[]=$fetch['id'];
			 
		}
	}else{
	//$flag=0;	
	}
		
		
		
	}else{
		//$flag=0;	
	}

	return $rids;
	
	

	
	
}
function getBookingIdFromCode($conn,$code){
	$expCode=explode("BKSM",$code);
	$bookingId=$expCode[1]-1000;
	return $bookingId;
}
function getAssNameFromBid($conn,$bid){
	$ds=mysqli_query($conn,"SELECT `assoc_id` FROM `seminarbookings` where  `id`='$bid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	$aid= $ds1['assoc_id'];	
	$aname=associatenamefromid($conn,$aid);
	return $aname;
	
}
function getRoasterDetailIdFromBookingId($conn,$bid){
	$ds=mysqli_query($conn,"SELECT * FROM `seminarbookings` where  `id`='$bid' and `status`='1' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['roaster_detail_id'];	
}

function checkPresentStatusByBookingId($conn,$bid){
//	echo "SELECT * FROM `seminarattendence` where `bookingid`='$bid'  and `view`='1' ";
$ds=mysqli_query($conn,"SELECT * FROM `seminarattendence` where `bookingid`='$bid'  and `view`='1' "); 
	$numrows=mysqli_num_rows($ds);
	if($numrows>0){	
		return true;
		}else{
		return false;		
	}

}


function getSeminarAttended($conn,$module,$assoc){
	    $rids=array();
		$flag=0;
		//echo $module;
        $ds2=mysqli_query($conn,"SELECT * FROM `seminarbookings` where `assoc_id`='$assoc'  and `status`='1'"); 
	    $numrows2=mysqli_num_rows($ds2);

		while($fetch=mysqli_fetch_array($ds2)){
			$bid=$fetch['id'];
		    if(checkPresentStatusByBookingId($conn,$bid)){
			    
				$rid=$fetch['roaster_detail_id'];
				$roasterDetArr=getRoasterDetailsDetailById($conn,$rid);
				$moduleAtten=$roasterDetArr['module_id'];
				
				if($moduleAtten==$module){
					$flag=1;	
				}
				
			}
		}
		

	return $flag;
	
		
	
}
function changeDateTomkTime($date){
    $expDob=explode("-",$date);
	$expMonth=$expDob[1];	
	$expDate=$expDob[2];
	$expYear=$expDob[0];
	$makedate=@mktime(0,0,0,$expMonth,$expDate,$expYear);
	return 	$makedate;
	
}

function getTimestamp($date,$time){
    $expDob=explode("-",$date);
	
	$expTime=explode(":",$time);
	
	$expMonth=$expDob[1];	
	$expDate=$expDob[2];
	$expYear=$expDob[0];
	
	
	$makedate=@mktime($expTime[0],$expTime[1],0,$expMonth,$expDate,$expYear);
	return 	$makedate;
	
}

function checkisTeamHead($conn,$code){ 
	//echo "SELECT * FROM `mlm_assiciate_desigination` where `desigination_name`='$desg'";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_admin` where `login_name`='$code' and `status`='1'"); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return false;	
	}else{
		return true;	
	}
 
}


function hasChild($conn,$id){
	$fetch=mysqli_fetch_row(mysqli_query($conn,"select count(*) from mlm_tree where parent=$id"));
	
	if($fetch[0]>0){
			return true;	
	}else{
			return false;	
	}
	
}

$tree=array();
//Recursive php function
function category_tree($conn,$catid){
global $tree;
 	
  $sql1 = "select `associate_detail_id` from mlm_tree where parent ='".$catid."'";
   $result = mysqli_query($conn,$sql1);
   while($row = mysqli_fetch_array($result)){
		  $aid=$row['associate_detail_id'];
		 // $tree[]=$aid;
		   $childid=$row['associate_detail_id'];
		   $pid=$row['parent'];
		  // $tree[]=
			if ( hasChild($conn,$aid) ){ 
			    
			     $tree[]=$aid;
				 category_tree($conn,$aid);
		 
			}else{
				$tree[]=$aid;
						
			}
		 //category_tree($conn,$aid);	
	
	}
return $tree;

}




$tree2=array();
//Recursive php function
function category_tree_code($conn,$catid){
global $tree2;
 	
  $sql1 = "select `associate_detail_id`,`code` from mlm_tree where parent ='".$catid."'";
   $result = mysqli_query($conn,$sql1);
   while($row = mysqli_fetch_array($result)){
		  $aid=$row['associate_detail_id'];
		  $code=$row['code'];
		  // $tree[]=$aid;
		   $childid=$row['associate_detail_id'];
		   $pid=$row['parent'];
		  // $tree[]=
			if ( hasChild($conn,$aid) ){ 
			      $tree2[]=$code;
				 category_tree($conn,$aid);
		 
			}else{
				$tree2[]=$code;
						
			}
		 //category_tree($conn,$aid);	
	
	}
return $tree2;

}

$tree1=array();
function category_tree_joining($conn,$catid,$from,$to){
global $tree1;
 	// $sql1 = "select `associate_detail_id` from mlm_tree where parent ='".$catid."'   and `date_of_joining` between '$from' and '$to' ";
    $sql1 = "select mt.`associate_detail_id` from mlm_tree mt inner join mlm_associate_detail md  on  mt.parent=md.associate_detail_id  where  mt.parent ='".$catid."'   and md.`date_of_joining` between '$from' and '$to' ";
   $result = mysqli_query($conn,$sql1);
   while($row = mysqli_fetch_array($result)){
		  $aid=$row['associate_detail_id'];
		 // $tree[]=$aid;
		   $childid=$row['associate_detail_id'];
		   $pid=$row['parent'];
		  // $tree[]=
			if ( hasChild($conn,$aid) ){ 
			      $tree1[]=$aid;
				 category_tree($conn,$aid);
		 
			}else{
				$tree1[]=$aid;
						
			}
		 //category_tree($conn,$aid);	
	
	}
return $tree1;

}
function getFalseSales($conn){
	$error=array();
	 $ds2=mysqli_query($conn,"SELECT * FROM `total_sales` limit 0,10 "); 
	    $numrows2=mysqli_num_rows($ds2);

		while($fetch=mysqli_fetch_array($ds2)){
			$aid=$fetch['associate_detail_id'];
			echo "totalSale--".$totalSale=$fetch['total_sales'];
			$childArr=category_tree($conn,$aid);
			
			$sql1 = "select sum(total_sales) as sales from total_sales where associate_detail_id IN (".implode(',',$childArr).") ";
            $result = mysqli_fetch_assoc(mysqli_query($conn,$sql1));
          echo   "ch sale--".$childSale=$result['sales'];
			
			if($childSale>$totalSale){
			echo $aid;	
				
			}
		}
		//return $error;		
		
		
}

function getFloorIdFromCustomerDetailId($conn,$cid){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_customer_detail` where  `customer_detail_id`='$cid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['floor_id'];	
}

function checkFloorIsOnHold($conn,$fid){
	//echo "SELECT * FROM `crm_inv_project_floor` where  `id`='$fid' and `status`='hold' and `holdedbycode`='$asscode' and `holdedbyid`='$assid'  ";die;
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_project_floor` where  `floor_id`='$fid' and `status`='hold'   "); 
	$ds1=mysqli_num_rows($ds);
	if($ds1>0){
		return true;	
	}else{
		return false;
	}
}



function getHoldedInventoriesofTeamHead($conn,$assocode,$associd){
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `teamheadcode`='$assocode' and `holdstatus`='1' order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$cid=$fetch['id'];
			$floorid=$fetch['floor_id'];
			
			if(checkFloorIsOnHold($conn,$floorid)){
				$holded[]=$cid;	
			}
			
			
			
			
		}
		//return $error;		
	return 	$holded;
		
}


function getSelfHoldedInventories($conn,$assocode,$associd){
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	
	//echo "SELECT * FROM `holdedinventory` where  (`associateid`='$associd' or `teamheadcode`='$assocode' )and `holdstatus`='1' order by `id` desc  ";
	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  (`associateid`='$associd' or `teamheadcode`='$assocode' )and `holdstatus`='1' order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$cid=$fetch['id'];
			$floorid=$fetch['floor_id'];
			
			if(checkFloorIsOnHold($conn,$floorid)){
				$holded[]=$cid;	
			}
			
			
			
			
		}
		//return $error;		
	return 	$holded;
		
}



function getOprHoldedInventory($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1'  order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}

function getOprHoldedInventoryNew($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `pdate`>='2018-07-10'   order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}

function getTeamHeadHoldedInventory($conn,$tcode){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `teamheadcode`='$tcode'  order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}

function getAssocHeadHoldedInventory($conn,$acode){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	//echo "SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `associatecode`='$acode'  order by `id` desc  ";
	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `associatecode`='$acode'  order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}

function getSaleOprHoldedInventory($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `crm_sales_details_new` where  `hid`>'0' and `salestatus`='1' order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['hid'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}


function getActHoldedInventory($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	// $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `approval`='1' and `oprapproval`='1'  "); 
	 
	 

	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1'  and `oprapproval`='1' order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}
function getActHoldedInventoryNew($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	// $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `approval`='1' and `oprapproval`='1'  "); 
	 
	 

	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1'  and `oprapproval`='1' order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}
function getSalesHoldedInventory($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	// $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `approval`='1' and `oprapproval`='1'  "); 
	 
	 

	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='2'   order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}
function getHoldedCustomerDetailsById($conn,$cid){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_customer_detail` where  `customer_detail_id`='$cid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;	
}

function getHoldedInventoryDetailsById($conn,$hid){
	$ds=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `id`='$hid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;	
}
function getFloorIdByHoldedId($conn,$hid){
	$ds=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `id`='$hid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['floor_id'];	
}

function getIntPlanDetailsById($conn,$hid){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_payment_plan_master` where  `payment_plan_master_id`='$hid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;	
}

function getIntCommissionDetailsById($conn,$pid,$fid){
	//echo "SELECT `commision` FROM `crm_inv_payment_plan_master` where  `payment_plan_master_id`='$pid' and `floor_id`='$fid'  ";
	$ds=mysqli_query($conn,"SELECT `commision` FROM `crm_inv_payment_plan` where  `payment_plan_master_id`='$pid' and `floor_id`='$fid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['commision'];	
}

function getHoldedInventoryDetailsDetailById($conn,$hid){
	$ds=mysqli_query($conn,"SELECT * FROM `holdedinventorycharges` where  `holded_id`='$hid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;	
}

function getInventoryNameById($conn,$floorid){
	$str_floor="SELECT `floor_id`,`tower_id`,`project_id`,`project_floor_no`,`project_unit_no`, basic_size,status ,hold_till_date FROM `crm_inv_project_floor` where `floor_id`='$floorid' ";
	$result=mysqli_fetch_assoc(mysqli_query($conn,$str_floor));
	$project=$result['project_id'];
	$tower=$result['tower_id'];
	$floor=$result['project_floor_no'];
	$unit=$result['project_unit_no'];
    $inventory= get_project_name_byid($conn,$project)." - ".towernamebyid($conn,$tower)." - ".$floor." - ".$unit;
	 $holdeddate=$result['hold_till_date'];
	 return $inventory;
	
}


function getInventoryNameByIdForEmail($conn,$floorid){
	$str_floor="SELECT `floor_id`,`tower_id`,`project_id`,`project_floor_no`,`project_unit_no`, basic_size,status ,hold_till_date FROM `crm_inv_project_floor` where `floor_id`='$floorid' ";
	$result=mysqli_fetch_assoc(mysqli_query($conn,$str_floor));
	$project=$result['project_id'];
	$tower=$result['tower_id'];
	$floor=$result['project_floor_no'];
	$unit=$result['project_unit_no'];
    $inventory= "unit ( ".towernamebyid($conn,$tower)." - ".$floor." - ".$unit." ) in project ".get_project_name_byid($conn,$project);
	 $holdeddate=$result['hold_till_date'];
	 return $inventory;
	
}


function getUnapprovedRera($conn,$type){
	
	 $holded=array();
    if($type==2){
	 $ds2=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where  `rera_rk_approval`='0'  and `rara_number`!=''  "); 
	}
	if($type==1){
	 $ds2=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where  `rera_team_head_approval`='0'  and `rara_number`!=''  "); 
	}


	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['associate_detail_id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}

function getapprovedRera($conn,$type){
	
	 $holded=array();
    if($type==2){
	 $ds2=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where  `rera_rk_approval`='1'  and `rara_number`!=''  "); 
	}
	if($type==1){
	 $ds2=mysqli_query($conn,"SELECT * FROM `mlm_associate_detail` where  `rera_team_head_approval`='1'  and `rara_number`!=''  "); 
	}


	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['associate_detail_id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}
function getDepartmentEmailsByRole($conn,$role){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_admin` where  `roll_id`='$role'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['email'];	
	
}
function getDepartmentContactByRole($conn,$role){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_admin` where  `roll_id`='$role'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['contact'];	
	
}
function getDepartmentNameById($conn,$id){

//echo "SELECT * FROM `crm_admin` where  `id`='$id'  ";
	$ds=mysqli_query($conn,"SELECT * FROM `crm_admin` where  `id`='$id'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['login_name'];	
	
}
function getStatus($value){
	if($value==1){
		return '<span class="label label-success">Approved</span>';
	}
	if($value==0){
		return '<span class="label label-danger">Blocked</span>';
	}
}
function getReleaseStatus($value){
	if($value==1){
		return '<span class="label label-success">Stop</span>';
	}
	if($value==0){
		return '<span class="label label-danger">Release</span>';
	}
}

function getCommDetailsByPlanIdAndFloorId($conn,$pid,$floorid){
	//echo "SELECT * FROM `crm_inv_payment_plan` where  `payment_plan_master_id`='$pid' and `floor_id`='$floorid'  ";
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_payment_plan` where  `payment_plan_master_id`='$pid' and `floor_id`='$floorid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['commision'];	
}


function getCorporateDetailsByPlanIdAndFloorId($conn,$pid,$floorid){
	//echo "SELECT * FROM `crm_inv_payment_plan` where  `payment_plan_master_id`='$pid' and `floor_id`='$floorid'  ";
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_payment_plan` where  `payment_plan_master_id`='$pid' and `floor_id`='$floorid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['corporate_discount'];	
}



function getCorporateDetailsByPlanIdAndFloorIdnew($conn,$pid,$floorid){
	//echo "SELECT * FROM `crm_inv_payment_plan` where  `payment_plan_master_id`='$pid' and `floor_id`='$floorid'  ";
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_payment_plan` where  `payment_plan_master_id`='$pid' and `floor_id`='$floorid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	$cddic= $ds1['corporate_discount'];	
	//echo "SELECT * FROM `holdedinventory` where  `plan_id`='$pid' and `floor_id`='$floorid'  and `status`='1' order by `id` desc ";
	$ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `plan_id`='$pid' and `floor_id`='$floorid'  and `holdstatus`='1' order by `id` desc "); 
	$ds3=mysqli_fetch_assoc($ds2);
	$cddicnew= $ds3['corporate_discount'];
		if($cddicnew==0){
			
		return $cddic;	
		}else{
			return "0";	
		}
	
	
	
}


function getSplAndIntDiscofFloor($conn,$floorid){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_project_floor` where  `floor_id`='$floorid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['special_discount']+$ds1['back_facing_plc_discount'];
}

function getFloorPlcById($conn,$floorid){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_project_floor` where  `floor_id`='$floorid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['floor_plc'];
}
function getProjectIdByFloorId($conn,$floorid){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_project_floor` where  `floor_id`='$floorid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['project_id'];
}



function getParentsTree($conn,$id){
$arr = array();  
$parent = 1;
while($parent != 0 || $parent != '')
{
	if($i == 0)
	{
		$id = $id;
		$arr[0] = $id;
		$i++;
	}
	else
	{ 
		$id = $parent;
		$i++;
	}
	//echo "<br/>";
  $aresult ="SELECT id, parent,desigination_id FROM `mlm_tree` where id=$id" ;

	$result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_array($result2);
	$parent = $row['parent'];
	if($parent!=''){
	 $arr[$i] = $row['parent'];
	 $desigination_id=$row['desigination_id'];
	}
	 //$arr[$i] = $row['desigination_id'];
	 //$desigination_name=$row['desigination_name'];
	 
	
	
}	
	return $arr;
}




function getParentsTreeNotBlocked($conn,$id){
$arr = array();  
$parent = 1;
while($parent != 0 || $parent != '')
{
	if($i == 0)
	{
		$id = $id;
		$arr[0] = $id;
		$i++;
	}
	else
	{ 
		$id = $parent;
		$i++;
	}
	//echo "<br/>";
  $aresult ="SELECT id, parent,desigination_id ,associate_detail_id FROM `mlm_tree` where id=$id" ;

	$result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_array($result2);
	$parent = $row['parent'];
	$assid=$row['associate_detail_id'];
	
	if($parent!=''){
	 $arr[$i] = $row['parent'];
	 $desigination_id=$row['desigination_id'];
	}
	 //$arr[$i] = $row['desigination_id'];
	 //$desigination_name=$row['desigination_name'];
	 
	
	
}	
	return $arr;
}


function getParentsTreeTilTh($conn,$id,$thid){
$arr = array();  
$parent = 1;
while($parent != 0 )
{
	if($i == 0)
	{
		$id = $id;
		$arr[0] = $thid;
		$i++;
	}
	else
	{ 
		$id = $parent;
		$i++;
	}
	//echo "<br/>";
  $aresult ="SELECT id, parent,desigination_id FROM `mlm_tree` where id=$id" ;

	$result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_array($result2);
	$parent = $row['parent'];
	if($parent >= $thid){
	 $arr[$i] = $row['parent'];
	 $desigination_id=$row['desigination_id'];
	}else{
	$parent=0;	
	}
	 //$arr[$i] = $row['desigination_id'];
	 //$desigination_name=$row['desigination_name'];
	 
	
	
}	
	return $arr;
}



function getParentsTreeWithoutEmpAndBlocked($conn,$id){
$arr = array();  
$parent = 1;
while($parent != 0 || $parent != '')
{
	if($i == 0)
	{
		$id = $id;
		$arr[0] = $id;
		$i++;
	}
	else
	{ 
		$id = $parent;
		$i++;
	}
	//echo "<br/>";
  $aresult ="SELECT id, parent,desigination_id FROM `mlm_tree` where id=$id" ;

	$result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_array($result2);
	$parent = $row['parent'];
	
	$parent_assc_id=getParentAssociateId($conn,$parent);
	
	$assocblocked=getAssociateBlockedStatus($conn,$parent_assc_id);
	
	$asstype=getAssociateEmpStatusById($conn,$parent_assc_id);
	
	if($parent!='0' && $parent!=''){
	    if($assocblocked!='0' && $asstype!=2 ){
	//echo $z++;
	 		$arr[$i] = $row['parent'];
	 		$desigination_id=$row['desigination_id'];
		
		}
	 
	 
	}
	 //$arr[$i] = $row['desigination_id'];
	 //$desigination_name=$row['desigination_name'];
	 
	
	
}	
	return $arr;
}



function getCommissionPercentByAssociId($conn,$aid){
    $aresult ="SELECT id, desigination_id FROM `mlm_tree` where id=$aid" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	 $desg=$row['desigination_id'];
	$desgArr=getDesignationDetailsByDesgName($conn,$desg);
	//print_r($desgArr);
	
	 $arr[0]=$desgArr['desigination_id'];
	$arr[1]=$desgArr['percentage_designation'];
	
	return $arr;
	
}

function getAssociateDesignationIndexById($conn,$associds){
	
	$aresult ="SELECT id, desigination_id FROM `mlm_tree` where id=$associds" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	$desg=$row['desigination_id'];
	$desgArr=getDesignationDetailsByDesgName($conn,$desg);
	$index=$desgArr['desigination_id'];
	return $index;
}

function populateHoldingCommission($conn,$arr,$hid,$cdisc){
	
//die;
$bonusFlag=0;
foreach($arr as $associds){
	
	
$i++;
if($i==1){
	$commPercentandindex=getCommissionPercentByAssociId($conn,$associds);
	$commPercent=$commPercentandindex[1];
	$index=$commPercentandindex[0];
	$assoc[$associds]=$commPercent."##1";
	
}else{
	 $newIndex=getAssociateDesignationIndexById($conn,$associds);
	
	if($newIndex < $index){
		 $commPercentandindex=getCommissionPercentByAssociId($conn,$associds);
		 $necommPercent=$commPercentandindex[1];
		 $commPercent=$commPercentandindex[1]-$commPercent;
		 $index=$commPercentandindex[0];
		 $assoc[$associds]=$commPercent."##1";
		 $commPercent=$necommPercent;	
		
	}else{
		
		$check=qualifyforbonus($conn,$arr,$associds,$bonusFlag);
		if($bonusFlag==0){
			if($check){
			$assoc[$associds]='5##2';	
			$bonusFlag=1;	
			}
		}
		
	}
	
	
	
}


}
	

foreach($assoc as $ass=>$commpercent){
	$assid=$ass;
	$mlmArr=getMlmTreeDetailById($conn,$assid);
	$code=$mlmArr['code'];
	$desg_name=$mlmArr['desigination_id'];
	$desgArr=getDesignationDetailsByDesgName($conn,$desg_name);
	$desg_id=$desgArr['desigination_id'];
	$expComm=explode("##",$commpercent);
	$comm=$expComm[0];
	$type=$expComm[1];
	
	//echo "INSERT INTO `commission_on_holding` (`id`, `hold_id`, `assoc_tree_id`, `assoc_code`, `designation_id`, `designation_name`, `commpercent`) VALUES (NULL, '$hid', '$assid', '$code', '$desg_id', '$desg_name', '$commpercent');";
	$qry=mysqli_query($conn,"INSERT INTO `commission_on_holding` (`id`, `hold_id`, `assoc_tree_id`, `assoc_code`, `designation_id`, `designation_name`, `commpercent`,`type`) VALUES (NULL, '$hid', '$assid', '$code', '$desg_id', '$desg_name', '$comm','$type');"); 
	
}

//die;	
	
}

function qualifyforbonus($conn,$arr,$id,$bonusflag){
	$move=0;
	foreach($arr as $arrid){
		
			 if($arrid==$id){
				 break; 
			 }else{
				$parentIndex=getAssociateDesignationIndexById($conn,$arrid); 
				$selfIndex=getAssociateDesignationIndexById($conn,$id); 
				 if( $parentIndex < $selfIndex){
					$move=1; 
				 }
				 
				 
			 }
			
		
		
	}
	if($move==0){
		return true;	
	}else{
		return false;
	}
	
	
	
}


function cleanname($string){
	$str=preg_replace('/[^0-9a-zA-Z\.]/',"-",$string);
	$str=str_replace("--","-",$str);
	return $str;
}
function getTotalBookings($conn,$rid){
	//echo "SELECT count(*) FROM `seminarbookings` where `roaster_detail_id` ='$rid' and `status`='1'";
$ds=mysqli_fetch_row(mysqli_query($conn,"SELECT count(*) FROM `seminarbookings` where `roaster_detail_id` ='$rid' and `status`='1'"));
	
	 return $ds[0];	
}




function sendvisitingcardmail($baseurl,$conn,$assocass){ 
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:13px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; ">
                                                <h1 style="color:#606060 !important; font-family:Helvetica, Arial, sans-serif; font-size:22px; font-weight:bold; letter-spacing:-1px; line-height:115%; margin:0; padding:0; text-align:left;"><i class="fa fa-facebook-official" aria-hidden="true"></i> Visiting Card Details</h1>
                                                <br />';
                                                
												foreach($assocass as $assid){
													$name=associatenamefromid($conn,$assid);
													$contact=associateMobilefromid($conn,$assid);
													$designation=getVisitingCardDesignationNameByAssocId($conn,$assid);
													$email=associateEmailfromid($conn,$assid);
													$companyprofile=getCompanyProfile($conn);
												  $msg.='<br/><br/><p style="text-align:left">
												  <table width="70%" border="0" style="border:dotted 1px #cccccc;padding:10px">
  <tr>
    <td><b>'.$name.'</b></td>
  </tr>
  <tr>
    <td>'.$designation.'</td>
  </tr>
  <tr>
    <td>+91 '.$contact.'</td>
  </tr>
  <tr>
    <td>'.$email.'</td>
  </tr>
   <tr>
    <td><b>'.$companyprofile[1].'</b></td>
  </tr>
   <tr>
    <td>Corporate office : '.$companyprofile[2].'</td>
  </tr>
  <tr>
    <td>Head office : '.$companyprofile[3].'</td>
  </tr>
  <tr>
    <td>Ph.'.$companyprofile[4].' | '.$companyprofile[5].'</td>
  </tr>
</table>

												  
												  </p><br/><br/>';
												}
												
										        $msg.='<br/><br/><p style="text-align:left"><br/>
												 
												
									          
                                                  <tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                       
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                           The information contained in and accompanying this communication may be confidential, subject to legal privilege, or otherwise protected from disclosure, and is intended solely for the use of the intended recipient(s). 
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://www.acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}
function getCompanyProfile($conn){
	$ds=mysqli_fetch_row(mysqli_query($conn,"SELECT * FROM `companyprofile` where `id` ='1' "));
	return $ds;	
	
}
function getVisitingCardsRequestDetails($conn,$id){
	$holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	//echo "SELECT * FROM `visitingcarddetails` where  `visitingcard_id`='$id'    ";
	 $ds2=mysqli_query($conn,"SELECT * FROM `visitingcarddetails` where  `visitingcard_id`='$id'    "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=associatenamefromid($conn,$fetch['assoc_id'])." - ".associatecodefromid($conn,$fetch['assoc_id']);	
			
			
			
			
		}
		
		return implode(",",$holded);
	
}
function getAssociateEmpStatusById($conn,$pid){
	
	$aresult1 ="SELECT emp_type FROM `mlm_associate_detail` where associate_detail_id=$pid" ;
    $result21=mysqli_query($conn,$aresult1);
	$row1=mysqli_fetch_assoc($result21);
	$etype=$row1['emp_type'];
	
	
	return $etype;
}


function getParentAssociateId($conn,$pid){
	
	$aresult ="SELECT associate_detail_id FROM `mlm_tree` where id=$pid" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	$parentaid=$row['associate_detail_id'];
	return $parentaid;
}


function getTreeIdByAssociateId($conn,$pid){
	
	$aresult ="SELECT id FROM `mlm_tree` where associate_detail_id=$pid" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	$parentaid=$row['id'];
	return $parentaid;
}

/*function getAssociateIdByTreeId($conn,$pid){
	
	$aresult ="SELECT associate_detail_id FROM `mlm_tree` where associate_detail_id=$pid" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	$parentaid=$row['associate_detail_id'];
	return $parentaid;
}*/

function getAssociateIdByTreeId($conn,$pid){
	
	$aresult ="SELECT associate_detail_id FROM `mlm_tree` where id=$pid" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	$parentaid=$row['associate_detail_id'];
	return $parentaid;
}
function getAssociateBlockedStatus($conn,$id){
	$aresult1 ="SELECT blocked FROM `mlm_associate_detail` where associate_detail_id=$id" ;
    $result21=mysqli_query($conn,$aresult1);
	$row1=mysqli_fetch_assoc($result21);
	$etype=$row1['blocked'];
	return $etype;
}
function getUnitPlansByPidAndSize($conn,$pid,$size){
	//echo "SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'";
	$ds=mysqli_query($conn,"SELECT plan FROM `unitplan` where `project_id`='$pid' and `area`='$size'"); 
	$count=mysqli_num_rows($ds);
	if($count>0){
	$ds1=mysqli_fetch_assoc($ds);
	$imgPath= $ds1['plan'];
	if($imgPath=='NULL' || $imgPath==''){
		$imgPath='nofloorplan.jpg';	
	}
	}else{
		$imgPath='nofloorplan.jpg';	
	}
	return $imgPath;
	
 
}

function getSearchedResult($conn,$sid,$sessid){
	$holded=array();
	
	
	
	$ds2=mysqli_query($conn," SELECT `associate_detail_id`  FROM `mlm_associate_detail` where  ( `first_name` LIKE '%$sid%' or `middle_name` LIKE '%$sid%' or `last_name`LIKE '%$sid%' or `contact_no` LIKE '%$sid%' or `alternate_contact_no` LIKE '%$sid%' or `pan_no` LIKE '%$sid%' or `associate_code` like '%$sid%' or 
	`email_id` like '%$sid%' or CONCAT(`first_name`, ' ', `middle_name`,'',`last_name`) like '%$sid%' )  "); 

	while($fetch=mysqli_fetch_array($ds2)){
		$assid=$fetch['associate_detail_id'];
		
		
		
			
				$holded[]=$fetch['associate_detail_id'];	
			
			
			
			
		}
		
		return $holded;
	
}

function getAvailableProjects($conn){
	$projects=array();
	$ds2=mysqli_query($conn,"SELECT distinct(`project_id`) FROM `crm_inv_project_floor` WHERE 1 order by `project_id`"); 
	while($fetch=mysqli_fetch_array($ds2)){
			$projects[]=$fetch['project_id'];	
	}
	return $projects;	
}
function getProjectNameByProjectId($conn,$id){
	$aresult1 ="SELECT `project_name` FROM `crm_inv_project` where project_id=$id" ;
    $result21=mysqli_query($conn,$aresult1);
	$row1=mysqli_fetch_assoc($result21);
	$etype=$row1['project_name'];
	return $etype;
}

function getVisitedSites($conn,$sites){
	$sitesProj=explode(",",$sites);
	foreach($sitesProj as $siteId){
	$project[]=getProjectNameByProjectId($conn,$siteId);
	
	}
	
	return implode(",  ",$project);
}

function getSelfVisit($conn,$assid){
	$self=array();
	$team=array();
	$mycode=associatecodefromid($conn,$assid);
	$ds2=mysqli_query($conn,"SELECT * FROM `sitevisits` where  `status`='1' and `cancelledstatus`='0'   "); 

	while($fetch=mysqli_fetch_array($ds2)){
		$referredCode=$fetch['referredcode'];
		 $teamheadCode=$fetch['teamheadcode'];
		
		if($referredCode==$mycode){
			$self[]=$fetch['id'];	
		}elseif($teamheadCode==$mycode){
			
			$team[]=$fetch['id'];
		}
			
		}
	return count($self)."###".count($team);
}


function getSelfVisitReport($conn,$asscode){
	$today=array();
	$total=array();
	$curdate=date("Y-m-d");
	//$mycode=associatecodefromid($conn,$assid);
	$ds2=mysqli_query($conn,"SELECT * FROM `sitevisits` where  `status`='1' and `referredcode`='$asscode'   "); 

	while($fetch=mysqli_fetch_array($ds2)){
		$pickupdate=$fetch['pickupdate'];
		 //$teamheadCode=$fetch['teamheadcode'];
		
		if($pickupdate==$curdate){
			$today[]=$fetch['id'];	
		}else{
			
			$total[]=$fetch['id'];
		}
			
		}
	return count($today)."###".count($total);
}






function getTeamVisit($conn,$assid){
	
	$team=array();
	$mycode=associatecodefromid($conn,$assid);
	$ds2=mysqli_query($conn,"SELECT * FROM `sitevisits` where  `status`='1' and `cancelledstatus`='0'   "); 

	while($fetch=mysqli_fetch_array($ds2)){
	
		$teamheadCode=$fetch['teamheadcode'];
		if($teamheadCode==$mycode){
			
			$team[]=$fetch['referredcode'];
		}
		}

	$stats=array_count_values($team);
	return $stats;
	
		
}

function getfloortypeByfloorId($conn,$fid){
	
	$aresult ="SELECT project_type FROM `crm_inv_project_floor` where floor_id=$fid" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	$parentaid=$row['project_type'];
	return $parentaid;
}

function getNumberofDirectReferences($conn,$id){ 
    $code=associatecodefromid($conn,$id);
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `mlm_associate_detail` where `reffered_code`='$code' "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "None";	
	}else{
		return $ds1['count'];	
	}
 
}


function getReferrenceDetailById($conn,$id){
	$aresult ="SELECT * FROM `reference` where `id`=$id" ;
    $result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_assoc($result2);
	return $row;
}
/*function cleanname($conn,$string){
$str=preg_replace('/[^0-9a-zA-Z\.]/',"-",$string);
$str=str_replace("--","-",$str);
return $str;
}*/


function timediff($time1,$time2){
	$start = strtotime($time1);
	$end   = strtotime($time2);
	$diff  = $end - $start;
    $hours = $diff / (60 * 60);
	return floor( $hours * 60 );	
}

function getLockStatusByInvId($conn,$fid){
	$endTime=date('Y-m-d h:i a' );
	//echo "SELECT `pdate` ,`ptime` FROM `reference` where `fid`='$fid' order by `id` desc";
	$ds=mysqli_query($conn,"SELECT `posteddate` ,`ptime` ,`aid` FROM `reference` where `fid`='$fid' order by `id` desc"); 
	$count=mysqli_num_rows($ds);
	if($count>0){
	$ds1=mysqli_fetch_assoc($ds);
	    $startTime= $ds1['posteddate']." ".$ds1['ptime'];
	    $diff=timediff($startTime,$endTime);
	  //die;
	   if($diff<=45){
		    return $ds1['aid']; 	
	   }else{
		  return '0'; 	 
	   }
	   
	}else{
	 return '0'; 	
	}
	
 }



function getReleaseLockStatusByInvId($conn,$fid){
	$endTime=date('Y-m-d h:i a' );
	//echo "SELECT `pdate` ,`ptime` FROM `reference` where `fid`='$fid' order by `id` desc";
	$ds=mysqli_query($conn,"SELECT `lockedby` ,`lockedtill`  FROM `crm_inv_project_floor` where `floor_id`='$fid' and `lockedby` > 0  "); 
	$count=mysqli_num_rows($ds);
	if($count>0){
	$ds1=mysqli_fetch_assoc($ds);
	    $startTime= $ds1['lockedtill'];
	    $diff=timediff($startTime,$endTime);
	  //die;
	   if($diff<=45){
		    return $ds1['lockedby']; 	
	   }else{
		  return '0'; 	 
	   }
	   
	}else{
	 return '0'; 	
	}
	
 }


function getCdApprovalInventory($conn,$associd){
	$teamheadcode=associatecodefromid($conn,$associd);

	$curDate=date("Y-m-d");
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `reference` where  `teamheadcode`='$teamheadcode' and `corporatestatus`='0' and `posteddate` ='$curDate'   order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
		}
		//return $error;		
	return 	$holded;
}

function getCdApprovalInventoryByAdmin($conn){
	$teamheadcode=getTeamHeads($conn);
	$impTh=implode(",",$teamheadcode);

	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `reference` where  `aid` IN ($impTh) and `corporatestatus`='0'  order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
		}
		//return $error;		
	return 	$holded;
}
function  date_range($first, $last, $step = '+1 day', $output_format = 'Y-m-d' ) {

    $dates = array();
    $current = strtotime($first);
    $last = strtotime($last);

    while( $current <= $last ) {

        $dates[] = date($output_format, $current);
        $current = strtotime($step, $current);
    }

    return $dates;
}


function addDaysToDate($Date,$day) {
	return  date('Y-m-d', strtotime($Date. " + ".$day." day"));
}

function subtractDaysToDate($Date,$day) {
	
return  date('Y-m-d', strtotime($Date. " - ".$day." day"));
}


function getDirectSalesByAscode($conn,$code){ 
  //  $code=associatecodefromid($conn,$id);
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `salesstatus`='1'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "0";	
	}else{
		return $ds1['count'];	
	}
 
}

function getDirectNonExSalesByAscode($conn,$code){ 
  //  $code=associatecodefromid($conn,$id);
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `costsheet` where `assoc_code`='$code' and `approval`='1' and `salestatus`='1'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "0";	
	}else{
		return $ds1['count'];	
	}
 
}

function getDirectCancelSalesByAscode($conn,$code){ 
  //  $code=associatecodefromid($conn,$id);
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `salesstatus`='0'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "0";	
	}else{
		return $ds1['count'];	
	}
 
}

function getDirectJoiningByAscode($conn,$code){ 
  //  $code=associatecodefromid($conn,$id);
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `mlm_associate_detail` where `reffered_code`='$code'   "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "0";	
	}else{
		return $ds1['count'];	
	}
 
}
function getDirectVisitByAscode($conn,$code){ 
  //  $code=associatecodefromid($conn,$id);
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `sitevisits` where `referredcode`='$code'  and `status`='1' and `cancelledstatus`='0' "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "0";	
	}else{
		return $ds1['count'];	
	}
 
}

function getDirectSalesByAscodeAndDate($conn,$code,$sdate,$edate){ 
  //  $code=associatecodefromid($conn,$id);
 // echo "SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `date-of-sale` between '$sdate' and '$edate'  ";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `date-of-sale` between '$sdate' and '$edate'  and `salesstatus` ='1' "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "0";	
	}else{
		return $ds1['count'];	
	}
 
}

function getDirectCancelSalesByAscodeAndDate($conn,$code,$sdate,$edate){ 
  //  $code=associatecodefromid($conn,$id);
 // echo "SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `date-of-sale` between '$sdate' and '$edate'  ";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `date-of-sale` between '$sdate' and '$edate'  and `salesstatus` ='0' "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return "0";	
	}else{
		return $ds1['count'];	
	}
 
}
function getTeamSalesByAscode($conn,$id){ 
  //  $code=associatecodefromid($conn,$id);
    $treeID=getTreeIdByAssociateId($conn,$id);
    $mytree=mychilds($conn,$treeID);
	
	//print_r($mytree);
	if(count($mytree)>0){
	foreach($mytree as $childid){
		$childid=getAssociateIdByTreeId($conn,$childid);
		
		$code=associatecodefromid($conn,$childid);
		//echo "<pre>";
	//	echo  "SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' ";
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `salesstatus` ='1'  "); 
	    $ds1=mysqli_fetch_assoc($ds);
//echo "SELECT count(*) as count FROM `costsheet` where `assoc_code`='$code' and `approval`='1' ";
		$ds2=mysqli_query($conn,"SELECT count(*) as count FROM `costsheet` where `assoc_code`='$code' and `approval`='1' and `salestatus`='1' "); 
	    $ds3=mysqli_fetch_assoc($ds2);


		$counts[]=$ds1['count'];
		
		$ncounts[]=$ds3['count'];
	}
	 $total="Exclusive: ".array_sum($counts);
	}else{
	 $total=0;	
	}
	
	return $total;
	
 
}


function getTeamNonSalesByAscode($conn,$id){ 
  //  $code=associatecodefromid($conn,$id);
    $treeID=getTreeIdByAssociateId($conn,$id);
    $mytree=mychilds($conn,$treeID);
	
	//print_r($mytree);
	if(count($mytree)>0){
	foreach($mytree as $childid){
		$childid=getAssociateIdByTreeId($conn,$childid);
		
		$code=associatecodefromid($conn,$childid);
		//echo "<pre>";
	//	echo  "SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' ";
		
//echo "SELECT count(*) as count FROM `costsheet` where `assoc_code`='$code' and `approval`='1' ";
		$ds2=mysqli_query($conn,"SELECT count(*) as count FROM `costsheet` where `assoc_code`='$code' and `approval`='1' and `salestatus`='1' "); 
	    $ds3=mysqli_fetch_assoc($ds2);


		//$counts[]=$ds1['count'];
		
		$ncounts[]=$ds3['count'];
	}
	 $total="Non Exclusive: ".(array_sum($ncounts))."";
	}else{
	 $total=0;	
	}
	
	return $total;
	
 
}

function getTeamCancelSalesByAscode($conn,$id){ 
  //  $code=associatecodefromid($conn,$id);
    $treeID=getTreeIdByAssociateId($conn,$id);
    $mytree=mychilds($conn,$treeID);
	
	//print_r($mytree);
	if(count($mytree)>0){
	foreach($mytree as $childid){
		$childid=getAssociateIdByTreeId($conn,$childid);
		
		$code=associatecodefromid($conn,$childid);
		//echo "<pre>";
	//	echo  "SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' ";
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `salesstatus` ='0'  "); 
	    $ds1=mysqli_fetch_assoc($ds);

		$ds2=mysqli_query($conn,"SELECT count(*) as count FROM `costsheet` where `assoc_code`='$code' and `approval`='1' and `salestatus`='2' "); 
	    $ds3=mysqli_fetch_assoc($ds2);


		$counts[]=$ds1['count'];
		
		$ncounts[]=$ds3['count'];
	}
	 $total="Exclusive: ".array_sum($counts).", Non Exclusive: ".(array_sum($ncounts)/2)." - Total : ".(array_sum($counts)+(array_sum($ncounts)/2));
	}else{
	 $total=0;	
	}
	
	return $total;
	
 
}

function getDirectSalesByAscodeAndMonth($conn,$code,$month){ 
  //  $code=associatecodefromid($conn,$id);
 
  
 
	$date=explode("-",$month);
	$sdate=$date[1]."-".$date[0]."-01";
	$edate=date("Y-m-t",strtotime($sdate));
	
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `date-of-sale` Between '$sdate' and '$edate' and `salesstatus`='1' "); 
	$ds1=mysqli_fetch_assoc($ds);
	$direct=$ds1['count'];
	return $direct;
 
}

function getTeamSalesByAscodeAndMonth($conn,$code,$month){ 
  //  $code=associatecodefromid($conn,$id);
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `after30marchsales` where `sale_code`='$code' and `sale_type`='2' and `sale_month`='$month' "); 
	$ds1=mysqli_fetch_assoc($ds);
	$direct=$ds1['count'];
	return $direct;
 
}


function cancelSiteVisit($conn){ 
  
    $curDate=date("Y-m-d");
	$curTime=date("H:i");
	$curDateTime=$curDate." ".$curTime;
	//echo "SELECT * FROM `sitevisits` where  `pickupdate`='$curDate' and `status`='1' and `cancelledstatus`='0'  order by `id` desc  ";
//	echo "SELECT * FROM `sitevisits` where  `pickupdate`='$curDate' and `status`='1' and `cancelledstatus`='0'  order by `id` desc  ";
	$ds2=mysqli_query($conn,"SELECT * FROM `sitevisits` where  `pickupdate`='$curDate' and `status`='1' and `cancelledstatus`='0' and `selfcar`='0'  order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$siteId=$fetch['id'];
				$cabno=$fetch['cabno'];
				$pickuptime=$fetch['pickuptime'];
				$pickupdate=$fetch['pickupdate'];
				$start=$pickupdate." ".$pickuptime;
				$cdate= date('Y-m-d H:i',strtotime('+45 minutes',strtotime($start)));
				
				$strextradate=strtotime($cdate);
				$strcheckdate=strtotime($curDateTime);
				$startkm=$fetch['startkm'];
				if( ($startkm=='') || ($cabno=='') ){
					
					if($strcheckdate > $strextradate ){
					//	echo "Update `sitevisits` set `cancelledstatus`='1' where `id`='$siteId'  order by `id` desc  ";
						
						$ds2=mysqli_query($conn,"Update `sitevisits` set `cancelledstatus`='1' where `id`='$siteId'  order by `id` desc  "); 	
						
					}
					
				}
					
			
		}
	
	
 }

function getMonthYearWiseIndirectAndDirectSales($conn,$associd,$year,$month){
	$sdate=$year."-".$month."-01";
	$edate=$year."-".$month."-31";
    $myasscode=associatecodefromid($conn,$associd);
	$myid=getTreeIdByAssociateId($conn,$associd);
	$direct=0;
	$indirect=0;
//	echo "SELECT * FROM `crm_sales_details_new` WHERE `date-of-sale` BETWEEN '$sdate' AND '$edate' ORDER BY `date-of-sale` DESC  ";
	$ds2=mysqli_query($conn,"SELECT * FROM `crm_sales_details_new` WHERE `date-of-sale` BETWEEN '$sdate' AND '$edate' and `salesstatus`='1' ORDER BY `date-of-sale` DESC  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			    $asscode=$fetch['associatecode'];
				$assid=associateidfromcode($conn,$asscode);
				if($asscode==$myasscode){
					$direct=$direct+1;	
					
				}else{
					$id=getTreeIdByAssociateId($conn,$assid);
					$parentTree=getParentsTree($conn,$id);
					if(in_array($myid,$parentTree)){
						$indirect=$indirect+1;
					}
					
				}
				
				
			
		}
		//return $error;		
	return 	$direct."##".$indirect;
}

function monthanddateCorrection($val){
	if($val<=9){
		return "0".$val;	
	}else{
	return $val;	
	}
	
}

function updateTotalSaleBYAssId($conn,$aid){
	
	$search ="select * from total_sales   WHERE associate_detail_id=$aid" ;
    $num=mysqli_num_rows(mysqli_query($conn,$search));
	if($num==0){
	$acode=associatecodefromid($conn,$aid);
	$aresult ="INSERT INTO `total_sales` (`total_sale_id`, `associate_detail_id`, `associate_code`, `total_sales`, `individual_sale`, `designation`) VALUES (NULL, '$aid', '$acode', '1', '0', NULL)" ;
	$result2=mysqli_query($conn,$aresult);
	}else{
	  $aresult ="UPDATE total_sales SET total_sales = total_sales +1 WHERE associate_detail_id=$aid" ;
  	  $result2=mysqli_query($conn,$aresult);
	}
	if($result2){
		return true;	
	}else{
		return false;	
	}
 }

function updateIndividualSaleBYAssId($conn,$aid){
	
	$aresult ="UPDATE total_sales SET individual_sale = individual_sale +1 WHERE associate_detail_id=$aid" ;
    $result2=mysqli_query($conn,$aresult);
	if($result2){
		return true;	
	}else{
		return false;	
	}
}

function updateIndividualDesignationByAssId($conn,$aid,$dateofsale,$saleid){
	$date=explode("-",$dateofsale);
	$asscode=associatecodefromid($conn,$aid);
	$salemonth=$date[1]."-".$date[0];
	
	$ds=mysqli_query($conn,"SELECT * FROM `mlm_tree` where `associate_detail_id`='$aid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	$desg=$ds1['desigination_id'];
	$total=getTotalSaleByAid($conn,$aid);
	
	if(   ($total>=5) && ($total<25) && ( $desg =="BDE" )   )
	{
		$dvm="UPDATE `mlm_tree` SET `desigination_id`='BDM' WHERE `associate_detail_id`=$aid";
		mysqli_query($conn,$dvm);
		$did="BDM";
		
		$sq11="INSERT INTO `totalsaleeffectpromotion` (`id`, `sale_month`, `asscode`, `sale`,`did`) VALUES (NULL, '$salemonth', '$asscode', '$saleid','$did');"; 
        $re=mysqli_query($conn,$sq11);
		
	 }
	
	if( ($total>=25) && ($total<80) && (   $desg =="BDM" )   )
	{
		$dvg="UPDATE `mlm_tree` SET `desigination_id`='GM' WHERE `associate_detail_id`=$aid";
		mysqli_query($conn,$dvg);
		$did="GM";
		$sq11="INSERT INTO `totalsaleeffectpromotion` (`id`, `sale_month`, `asscode`, `sale`,`did`) VALUES (NULL, '$salemonth', '$asscode', '$saleid','$did');"; 
        $re=mysqli_query($conn,$sq11);
	}
	
	if( ($total>=80) && ( $desg =="GM" )  )
	{
		$dvc="UPDATE `mlm_tree` SET `desigination_id`='AVP' WHERE `associate_detail_id`=$aid";
		mysqli_query($conn,$dvc);
		$did="AVP";
		$sq11="INSERT INTO `totalsaleeffectpromotion` (`id`, `sale_month`, `asscode`, `sale`,`did`) VALUES (NULL, '$salemonth', '$asscode', '$saleid','$did');"; 
        $re=mysqli_query($conn,$sq11);
	}
	
 
	
	
}
function updateTotalSaleEffectByAssId($conn,$assid,$dateofsale,$saleid,$bdesg,$adesg){
	$date=explode("-",$dateofsale);
	$asscode=associatecodefromid($conn,$assid);
	$salemonth=$date[1]."-".$date[0];
	$ds2=mysqli_query($conn,"INSERT INTO `totalsaleeffect` (`id`, `sale_month`, `asscode`, `sale`,`bdesg`,`adesg`) VALUES (NULL, '$salemonth', '$asscode', '$saleid','$bdesg','$adesg') "); 
	if($ds2){
		return true;	
	}else{
		return false;
	}
	
}
function getTeamHeads($conn){
	

	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `crm_admin` where  `roll_id`='5' and `status`='1'  order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=associateidfromcode($conn,$fetch['login_name']);	
			
		}
		//return $error;		
	return 	$holded;
}

function getTotalSaleByAid($conn,$aid){
	$ds=mysqli_query($conn,"SELECT `total_sales`  FROM `total_sales` where `associate_detail_id`='$aid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	$direct=$ds1['total_sales'];
	return $direct;
	
}
function html2text($html)
{
    $tags = array (
    0 => '~<h[123][^>]+>~si',
    1 => '~<h[456][^>]+>~si',
    2 => '~<table[^>]+>~si',
    3 => '~<tr[^>]+>~si',
    4 => '~<li[^>]+>~si',
    5 => '~<br[^>]+>~si',
    6 => '~<p[^>]+>~si',
    7 => '~<div[^>]+>~si',
    );
    $html = preg_replace($tags,"\n",$html);
    $html = preg_replace('~</t(d|h)>\s*<t(d|h)[^>]+>~si',' - ',$html);
    $html = preg_replace('~<[^>]+>~s','',$html);
    // reducing spaces
    $html = preg_replace('~ +~s',' ',$html);
    $html = preg_replace('~^\s+~m','',$html);
    $html = preg_replace('~\s+$~m','',$html);
    // reducing newlines
    $html = preg_replace('~\n+~s',"\n",$html);
    return $html;
}


function getMonthYearWiseIndirectAndDirectSalesTeamWise($conn,$associd,$year,$month){
	$sdate=$year."-".$month."-01";
	$edate=$year."-".$month."-31";
    $myasscode=associatecodefromid($conn,$associd);
	$myid=getTreeIdByAssociateId($conn,$associd);
	$direct=0;
	$indirect=0;
//	echo "SELECT * FROM `crm_sales_details_new` WHERE `date-of-sale` BETWEEN '$sdate' AND '$edate' ORDER BY `date-of-sale` DESC  ";
	$ds2=mysqli_query($conn,"SELECT * FROM `crm_sales_details_new` WHERE `date-of-sale` BETWEEN '$sdate' AND '$edate' and `salesstatus`='1' ORDER BY `date-of-sale` DESC  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			    $asscode=$fetch['associatecode'];
				$assid=associateidfromcode($conn,$asscode);
				if($asscode==$myasscode){
					$direct=$direct+1;	
					
				}else{
					$id=getTreeIdByAssociateId($conn,$assid);
					$parentTree=getParentsTree($conn,$id);
					if(in_array($myid,$parentTree)){
						$indirect=$indirect+1;
					}
					
				}
				
				
			
		}
		//return $error;		
	return 	$indirect;
}
function populateParents($conn,$aid){
	 $ds2=mysqli_query($conn,"SELECT `associate_detail_id` FROM `mlm_associate_detail`  where `associate_detail_id`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$aid=$fetch['associate_detail_id'];
			    $treeid=getTreeIdByAssociateId($conn,$aid);
				$parent=getParentsTree($conn,$treeid);
				array_shift($parent);
				array_pop($parent);
				if(count($parent)>0){
				foreach($parent as $pid){
					 $ds3=mysqli_query($conn,"INSERT INTO `parents` (`id`, `self`, `parent`) VALUES (NULL, '$treeid', '$pid');"); 
				}
				}
				unset($parent);
			
			
		}
}

function mychilds($conn,$aid){
	$childs=array();
	 $ds2=mysqli_query($conn,"SELECT `self` FROM `parents`  where `parent`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$childs[]=$fetch['self'];
		}
		return $childs;
}


function mydirectchildmobile($conn,$code){
	$childs=array();
	 $ds2=mysqli_query($conn,"SELECT `contact_no` FROM `mlm_associate_detail`  where `reffered_code`='$code' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$childs[]=$fetch['contact_no'];
		}
		return $childs;
}




function mychildsCodes($conn,$aid){
	$childs=array();
	 $ds2=mysqli_query($conn,"SELECT `self` FROM `parents`  where `parent`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$self=$fetch['self'];
			$aid=getAssociateIdByTreeId($conn,$self);
			 $code=associatecodefromid($conn,$aid);
			
				$childs[]=$code;
		}
		return $childs;
}

function checkmychildsCodeswithdesg($conn,$aid){
	$childs=array();
	$scode=associatecodefromid($conn,$aid);
	 $ds2=mysqli_query($conn,"SELECT `self` FROM `parents`  where `parent`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$self=$fetch['self'];
			$caid=getAssociateIdByTreeId($conn,$self);
			//$code=associatecodefromid($conn,$aid);
			$gm=getconcernedheadGmandAbove($conn,$self);
			if($gm==$scode){
				$childs[]=$caid;
				
			}
		}
		return $childs;
}


function mychildsAssocIds($conn,$aid){
	$childs=array();
	 $ds2=mysqli_query($conn,"SELECT `self` FROM `parents`  where `parent`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$self=$fetch['self'];
			$aid=getAssociateIdByTreeId($conn,$self);
			
			
				$childs[]=$aid;
		}
		return $childs;
}



function mychildsAssocIdsNew($conn,$aid){
	$childs=array();
	 $ds2=mysqli_query($conn,"SELECT p.`self` ,md.associate_detail_id  FROM `parents` p inner join `mlm_tree` mt on mt.id=p.self inner join mlm_associate_detail md on md.associate_detail_id=mt.associate_detail_id where p.`parent`='$aid' and md.blocked='1'  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$aids=$fetch['associate_detail_id'];
			
			
				$childs[]=$aids;
		}
		return $childs;
}





function mychildsMobileNos($conn,$aid){
	$childs=array();
	 $ds2=mysqli_query($conn,"SELECT `self` FROM `parents`  where `parent`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$self=$fetch['self'];
			

			$mobileinput=associateMobilefromid($conn,getAssociateIdByTreeId($conn,$self));
			$rmobile=preg_replace("/[^0-9]+/", "", $mobileinput);
			$mobile="91".$rmobile."";
				$childs[]=$mobile;
		}
		return $childs;
}
function mychildsCodeswithdesg($conn,$aid,$desg){
		$childs=array();
	 $ds2=mysqli_query($conn,"SELECT `self` FROM `parents`  where `parent`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$desgold=getDesignationByTreeId($conn,$fetch['self']);
			if($desg==$desgold){
				$childs[]=$fetch['self'];
				
			}
		}
		return $childs;
}



function mychildCount($conn,$aid){
	$childs=array();
	$myid=getTreeIdByAssociateId($conn,$aid);
	 $ds2=mysqli_query($conn,"SELECT `self` FROM `parents`  where `parent`='$myid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$childs[]=$fetch['self'];
			
			
		}
		
		return count($childs);
}
function getReportByAssId($conn,$id,$sjoin){ 
  //  $code=associatecodefromid($conn,$id);
    $treeID=getTreeIdByAssociateId($conn,$id);
    $mytree=mychildsCodesNew($conn,$treeID);
	
	//print_r($mytree);
	if(count($mytree)>0){
		$totalAssoc=count($mytree)-$sjoin;
	foreach($mytree as $code){
	/*	$childid=getAssociateIdByTreeId($conn,$childid);
		
		$code=associatecodefromid($conn,$childid);*/
		//echo "<pre>";
	//	echo  "SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' ";
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `crm_sales_details_new` where `associatecode`='$code' and `salesstatus`='1'  "); 
	    $ds1=mysqli_fetch_assoc($ds);
		$counts[]=$ds1['count'];
		
		$dss=mysqli_query($conn,"SELECT count(*) as count FROM `sitevisits` where `referredcode`='$code' and `status`='1' and `cancelledstatus` ='0'  "); 
	    $dss1=mysqli_fetch_assoc($dss);
		$visits[]=$dss1['count'];
		
	}
		$total=array_sum($counts);
		$totalVisits=array_sum($visits);
	}else{
		 $total=0;	
		 $totalVisits=0;
		 $totalAssoc=0;
	}
	
	return $total."###".$totalVisits."###".$totalAssoc;
	
 
}


function getConsolidatedReportByAssId($conn,$id,$sjoin,$year){ 
  //  $code=associatecodefromid($conn,$id);
    $treeID=getTreeIdByAssociateId($conn,$id);
    $mytree=mychildsCodes($conn,$treeID);
	
	
	for($month=1;$month<=12;$month++){ 
	   if($month<=9){$month="0".$month;}
	   
	 //  $sdate="01/".$month."/".$year;
	   $sdate=$year."-".$month."-01";
	   $edate=date("Y-m-t",strtotime($sdate));
	   $assocArr[]=getAssociateDetailsBetweenDates($conn,$sdate,$edate,$id,$mytree);
		}
	
}
function getAssociateDetailsBetweenDates($conn,$sdate,$edate,$id,$mytreecodes){ 
     $mycode=associatecodefromid($conn,$id);
	 $ds2=mysqli_query($conn,"SELECT `reffered_code` FROM `mlm_associate_detail`  where `date_of_joining` BETWEEN '$sdate' and '$edate' "); 

		while($fetch=mysqli_fetch_array($ds2)){
				$refcode=$fetch['reffered_code'];
				if($mycode==$refcode){
					$myassoc=$myassoc+1;
				}
				if(in_array($refcode,$mytreecodes)){
					$mychildassoc=$mychildassoc+1;
				}
		}
		
		$ds2=mysqli_query($conn,"SELECT `refferedcode` FROM `sitevisits`  where `pickupdate` BETWEEN '$sdate' and '$edate' and `status`='1' and `cancelledstatus`='0' "); 

		while($fetch=mysqli_fetch_array($ds2)){
				$refcode=$fetch['refferedcode'];
				if($mycode==$refcode){
					$myvisit=$myvisit+1;
				}
				if(in_array($refcode,$mytreecodes)){
					$mychildvisit=$mychildvisit+1;
				}
		}
		
		
		$ds2=mysqli_query($conn,"SELECT * FROM `crm_sales_details_new` WHERE `date-of-sale` BETWEEN '$sdate' AND '$edate' and `salesstatus`='1' ORDER BY `date-of-sale` DESC  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			    $asscode=$fetch['associatecode'];
				
				if($asscode==$mycode){
					$direct=$direct+1;	
					
				}else{
				
					if(in_array($asscode,$mytreecodes)){
						$indirect=$indirect+1;
					}
					
				}
				
				
			
		}
		
	$text=$myassoc."-".$mychildassoc."###".$myvisit."-".$mychildvisit."###".$direct."-".$indirect;
	return 	$text;
		
		
}

function getApplicableTeamHead($conn,$aid){
$code=associatecodefromid($conn,$aid);
if(checkisTeamHead($conn,$code)){
	$tcode=$code;
}else{
	$tcode=team_headcode_fromassociatecode($conn,$aid);
	
}
	
	return $tcode;
	
}

function getApplicableTeamHeadNew($conn,$aid){
$code=associatecodefromid($conn,$aid);
if(checkisTeamHead($conn,$code)){
	$tcode=$code;
}else{
	$tcode=getNewTeamHeadCode($conn,$aid);
	
}
	
	return $tcode;
	
}

function getAssCodeFromSaleDetails($conn,$sid){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `associatecode` FROM `crm_sales_details_new` where  `sales_details_id`='$sid'   ")); 

	
	return 	$ds2['associatecode'];
}




function getSaleDetailsbySalesId($conn,$sid){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `crm_sales_details_new` where  `sales_details_id`='$sid'   ")); 

	
	return 	$ds2;
}



function getTowerNameById($conn,$id){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `tower_name` FROM `crm_inv_project_tower` where  `tower_id`='$id'   ")); 

	
	return 	$ds2['tower_name'];
}

function getTotalPlc($conn,$id){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(plc_rate) as sum FROM `crm_inv_project_plc` where  `floor_id`='$id'   ")); 

	
	return 	$ds2['sum'];
}

function getPlanNameByPlanId($conn,$id){
	
	 $holded=array();
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT payment_plan_master_name FROM `crm_inv_payment_plan_master` where  `payment_plan_master_id`='$id'   ")); 
	 return 	$ds2['payment_plan_master_name'];
}

function check45mindelay($ptime,$ctime){
	
	$diff=($ptime-$ctime)/60;
	if($diff<0){
		return false;	
	}else{
	if($diff>45){
		return true;	
	}else{
		return false;
	}
		
	}
	
	
	
}

function getDataFromTable($conn,$id,$table){
	$ds=mysqli_query($conn,"SELECT `name` FROM `$table` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	return $ds1['name'];
 
} 

function getLeadDetailById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `leads` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
} 
function getLeadNameANdMobileById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `name`,`contact_no`  as mobile ,`postedby` as aid FROM `leads` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
} 

function getLeadAssociateById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `postedby` FROM `leads` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['postedby'];
 
}

function getLeadNameById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `title`,`name` FROM `leads` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return  getDataFromTable($conn,$ds1['title'],"title")." ".$ds1['name'];
 
} 
function getFollowCount($conn,$type,$associd){
   $curDate=date("Y-m-d");
   if($type==1){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='1' and `followdate`='$curDate' and  `followdate`!='' "); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='1' and  `followdate`!=''  "); 
	}
	if($type==3){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='1' and `followdate`<'$curDate' and  `followdate`!='' "); 
	}
	
	if($type==4){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='1' and `followdate`>='$curDate' and  `followdate`!=''  "); 
	}
	
	
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
 
}

function getFollowCountbetweendates($conn,$associd,$sdate,$edate){
   $curDate=date("Y-m-d");
   $ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='1' and `followdate` Between '$sdate' and '$edate'  "); 	
   $ds1=mysqli_fetch_assoc($ds);
   return $ds1['count'];
 
}

 

function getMeetingCount($conn,$type,$associd){
   $curDate=date("Y-m-d");
   if($type==1){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='4' and `meetingdate`='$curDate'"); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='4' "); 
	}
	if($type==3){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='4' and `meetingdate`<'$curDate'"); 
	}
	
	if($type==4){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='4' and `meetingdate`>='$curDate'"); 
	}
	
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
 
} 


function getMeetingCountbetweendates($conn,$associd,$sdate,$edate){
   $curDate=date("Y-m-d");
   $ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='4' and `meetingdate` Between '$sdate' and '$edate' "); 
   $ds1=mysqli_fetch_assoc($ds);
   return $ds1['count'];
 
} 



function getSiteVisitCount($conn,$type,$associd){
   $curDate=date("Y-m-d");
   if($type==1){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='5' and `expsitevisitdate`='$curDate'"); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='5' "); 
	}
	if($type==3){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='5' and `expsitevisitdate`<'$curDate'"); 
	}
	
	
	if($type==4){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='5' and `expsitevisitdate`>='$curDate'"); 
	}
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
 
} 

function getSiteVisitCountbetweendates($conn,$associd,$sdate,$edate){
   $curDate=date("Y-m-d");
  
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `leadtype`='5' and `expsitevisitdate` Between '$sdate' and '$edate' "); 
	
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
 
} 



function getCabVendorNameById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `cabvendors` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
 
} 
function getCabTypeNameById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `cabtype` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
 
} 
function getSeminarDateByRoasterId($conn,$rid){
	//echo "SELECT count(*) FROM `seminarbookings` where `roaster_detail_id` ='$rid' and `status`='1'";
	//echo "SELECT * FROM `roaster` where `id` ='$rid' ";
$ds=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `roasters` where `id` ='$rid' "));
	
	 return $ds['rdate']."-".$ds['rmonth']."-".$ds['ryear'];	
}

function getSeminarDateByRoasterIdforattendence($conn,$rid){
	//echo "SELECT count(*) FROM `seminarbookings` where `roaster_detail_id` ='$rid' and `status`='1'";
	//echo "SELECT * FROM `roaster` where `id` ='$rid' ";
$ds=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `roasters` where `id` ='$rid' "));
	if($ds['rdate']<=9){
		$ds['rdate']="0".$ds['rdate'];
	}
	 return $ds['ryear']."-".$ds['rmonth']."-".$ds['rdate'];	
}
function getNoOfBookingByMonthByAssCode($conn,$ass,$sdate,$edate){
	$attendedinMonth=getAttendedBidsBetweenDates($conn,$sdate,$edate);
	$bookingsbyass=getBookingsMadeByAss($conn,$ass);
	$diff=array_intersect($bookingsbyass,$attendedinMonth);
	return $diff;	
}
function getBookingsMadeByAss($conn,$ass){
	$childs=array();
	$aid=associateidfromcode($conn,$ass);
	 $ds2=mysqli_query($conn,"SELECT `id` FROM `seminarbookings`  where `assoc_id`='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
			
				$childs[]=$fetch['id'];
		}
		return $childs;
}


function getAttendedBidsBetweenDates($conn,$sdate,$edate){
	$childs=array();
	$aid=associateidfromcode($conn,$ass);
	 $ds2=mysqli_query($conn,"SELECT `bookingid` FROM `seminarattendence`  where `pdate`Between '$sdate' and '$edate' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
			
				$childs[]=$fetch['bookingid'];
		}
	return $childs;	
}
function getSiteVisistDetailsById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `sitevisits` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getSiteVisistNameMobileById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `customersname` ,`contactno` FROM `sitevisits` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}


function getNoOfVisitsByMonthByAssCode($conn,$ass,$sdate,$edate){
	$childs=array();
	$aid=associateidfromcode($conn,$ass);
	 $ds2=mysqli_query($conn,"SELECT `id` FROM `sitevisits`  where `pickupdate` BETWEEN '$sdate' and '$edate' and `status`='1' and `cancelledstatus`='0' and `referredcode`='$ass'"); 

	while($fetch=mysqli_fetch_array($ds2)){
			
			
				$childs[]=$fetch['id'];
		}
	return $childs;	
}
function getNoOfJoinedsByMonthByAssCode($conn,$ass,$sdate,$edate){
	$childs=array();
	$aid=associateidfromcode($conn,$ass);
	 $ds2=mysqli_query($conn,"SELECT `associate_detail_id` FROM `mlm_associate_detail`  where `date_of_joining` BETWEEN '$sdate' and '$edate' and `blocked`='1' and `reffered_code`='$ass' "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
			
				$childs[]=$fetch['associate_detail_id'];
		}
	return $childs;	
}
function getDesignationByTreeId($conn,$id){
	$ds=mysqli_query($conn,"SELECT `desigination_id` FROM `mlm_tree` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['desigination_id'];
	
}
function getMyImmediateChilds($conn,$treeid){
	$childs=array();
	//echo "SELECT `id` FROM `mlm_tree`  where `parent` ='$treeid'";
	 $ds2=mysqli_query($conn,"SELECT `id` FROM `mlm_tree`  where `parent` ='$treeid'"); 

	while($fetch=mysqli_fetch_array($ds2)){
			
			  $aid=getAssociateIdByTreeId($conn,$fetch['id']);
			  $empStatus=getAssociateBlockedStatus($conn,$aid);
			  if($empStatus==1){
				$childs[]=$fetch['id'];
				
			  }
				
		}
	return $childs;	
}


function getMyImmediateChildsWithBlocked($conn,$treeid){
	$childs=array();
	//echo "SELECT `id` FROM `mlm_tree`  where `parent` ='$treeid'";
	 $ds2=mysqli_query($conn,"SELECT `id` FROM `mlm_tree`  where `parent` ='$treeid'"); 

	while($fetch=mysqli_fetch_array($ds2)){
			
			  $aid=getAssociateIdByTreeId($conn,$fetch['id']);
			
				$childs[]=$fetch['id'];
				
			 
				
		}
	return $childs;	
}

function getFMSLDetails($conn,$mytreeid){
	$fc=array();
	$mc=array();
	$sv=array();
	$lf=array();
	$lm=array();
	if(count($mytreeid)>0){
		
		foreach($mytreeid as $tid){
			$aid=getAssociateIdByTreeId($conn,$tid);
			$fc[]=getFollowCount($conn,4,$aid);
			$mc[]= getMeetingCount($conn,4,$aid);	
			$sv[]= getSiteVisitCount($conn,4,$aid);	
			$lf[]= getFollowCount($conn,3,$aid);
			$lm[]= getMeetingCount($conn,3,$aid);
			
						
		}
		$text=array_sum($fc)."##".array_sum($mc)."##".array_sum($sv)."##".array_sum($lf)."##".array_sum($lm);
		unset($fc);unset($mc);unset($sv);unset($lf);unset($lm);
		return $text;
		
	}else{
		return "0##0##0##0##0";	
	}
	
	
}
function getTreeCrumb($conn,$id,$tid){
$arr = array();  
$parent = 1;
while($parent != 0 || $parent != '')
{
	if($i == 0)
	{
		$id = $id;
		$arr[0] = $id;
		$i++;
	}
	else
	{ 
		$id = $parent;
		$i++;
	}
	//echo "<br/>";
  $aresult ="SELECT id, parent,desigination_id FROM `mlm_tree` where id=$id and `id` >='$tid'"   ;

	$result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_array($result2);
	$parent = $row['parent'];
	if($parent!=''){
	 $arr[$i] = $row['parent'];
	 $desigination_id=$row['desigination_id'];
	}
	 //$arr[$i] = $row['desigination_id'];
	 //$desigination_name=$row['desigination_name'];
	 
	
	
}	
	return $arr;
}


function getFmsType($type){
	if($type==1)return "Follow Ups";
	if($type==2)return "Meetings";
	if($type==3)return "Site Visits";
	if($type==4)return "Lapsed Followups";
	if($type==5)return "Lapsed Meetings";	
}


function getListType($type){
	if($type==1)return "Follow Ups";
	if($type==4)return "Meetings";
	if($type==5)return "Site Visits";
		
}





function geteLeadDetailById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `eleads` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
} 
function geteFollowCount($conn,$type,$associd){
   $curDate=date("Y-m-d");
   if($type==1){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='1' and `followdate`='$curDate' and  `followdate`!='' "); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='1' and  `followdate`!=''  "); 
	}
	if($type==3){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='1' and `followdate`<'$curDate' and  `followdate`!='' "); 
	}
	
	if($type==4){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='1' and `followdate`>='$curDate' and  `followdate`!=''  "); 
	}
	
	
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
 
} 

function geteMeetingCount($conn,$type,$associd){
   $curDate=date("Y-m-d");
   if($type==1){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='4' and `meetingdate`='$curDate'"); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='4' "); 
	}
	if($type==3){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='4' and `meetingdate`<'$curDate'"); 
	}
	
	if($type==4){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='4' and `meetingdate`>='$curDate'"); 
	}
	
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
 
} 
function geteSiteVisitCount($conn,$type,$associd){
   $curDate=date("Y-m-d");
   if($type==1){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='5' and `expsitevisitdate`='$curDate'"); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='5' "); 
	}
	if($type==3){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='5' and `expsitevisitdate`<'$curDate'"); 
	}
	
	
	if($type==4){
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `eleads` where   `postedby`='$associd' and `leadtype`='5' and `expsitevisitdate`>='$curDate'"); 
	}
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
 
} 

function addleadremarks($conn,$lid,$remarks,$stage,$fmsdate,$pdate){
	// echo "SELECT * FROM `mlm_associate_calculate` where `sales_details_id`='$saleid' and `associate_detail_id` ='$aid'";
	$ds=mysqli_query($conn,"INSERT INTO `leadremarks` (`id`, `lid`, `remarks`, `stage`, `fmsdate`, `posteddate`) VALUES (NULL, '$lid', '$remarks', '$stage', '$fmsdate', '$pdate')"); 
	return true;
 
}
function addeleadremarks($conn,$lid,$remarks,$stage,$fmsdate,$pdate){
	// echo "SELECT * FROM `mlm_associate_calculate` where `sales_details_id`='$saleid' and `associate_detail_id` ='$aid'";
	$ds=mysqli_query($conn,"INSERT INTO `eleadremarks` (`id`, `lid`, `remarks`, `stage`, `fmsdate`, `posteddate`) VALUES (NULL, '$lid', '$remarks', '$stage', '$fmsdate', '$pdate')"); 
	return true;
 
}
function getNiProjDetails($conn,$proj){
	
	if($proj=='NULL' || $proj==''){
		
	return '';	
	}else{
	$expProj=explode(",",$proj);
	foreach($expProj as $projId){
		
	$projName[]=getNonExcSubProjName($conn,$projId)	;
		
	}
	return 'Non Ex : '.implode(",",$projName);	
		
	}
	
		
}


function getNonExcSubProjName($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `nonexsubprojects` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
	
}
function getNonExcSubProjDetailsById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `nonexsubprojects` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
	
}
/*Exclusive project details*/
function getExcSubProjDetailsById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_project` where `project_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
	
}

/*End Exclusive prject details*/

function getNonExcProjUrlById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `url` FROM `nonexsubprojects` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['url'];
}
function getNonExcPrimaryMobileById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `primarymobile` as mobile FROM `nonexsubprojects` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['mobile'];
}
function getExcProjUrlById($conn,$id){
	
	$ds=mysqli_query($conn,"SELECT `url` FROM `crm_inv_project` where `project_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['url'];
	
}

function getAbove100List($conn){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT count(*) as count, `postedby` FROM `leads` group by `postedby` having count >100"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=getTreeIdByAssociateId($conn,$fetch['postedby']);
				
		}
	return $childs;	
	
	
}
function getUnsubscribedAray($conn){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `contact_no`  FROM `leads` where `unsubscribe`='1' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['contact_no'];
				
		}
		$childs=array_unique($childs);
	    return $childs;	
	
	
}
function getListAray($conn,$aid){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `contact_no` FROM `leads` where `postedby` ='$aid'"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['contact_no'];
				
		}
	return $childs;	
	
	
}
function getListString($conn,$aid){
	
	
	$childs=array();
	$ds2=mysqli_fetch_array(mysqli_query($conn,"SELECT GROUP_CONCAT(CONCAT('91',contact_no)) as mobile FROM `leads` where `postedby` ='$aid'")); 


	return $ds2['mobile'];	
	
	
}
function getList91($conn,$aid){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `contact_no` FROM `leads` where `postedby` ='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $rmobile=preg_replace("/[^0-9]+/", "", $fetch['contact_no']);
		
		
		      $childs[]="91".$rmobile;
				
		}
	return $childs;	
	
	
}

function getList91W($conn,$aid){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `contact_no` FROM `leads` where `postedby` ='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $rmobile=preg_replace("/[^0-9]+/", "", $fetch['contact_no']);
		
		
		      $childs[]=$rmobile;
				
		}
	return $childs;	
	
	
}


function getTeamList91($conn,$assocArr){
	
	if(count($assocArr)>0){
		$impIds=implode(",",$assocArr);	
	}else{
		$impIds=0;
	}
	$childs=array();
	//echo "SELECT `contact_no` FROM `leads` where `postedby` in ($impIds) ";
	$ds2=mysqli_query($conn,"SELECT `contact_no` FROM `leads` where `postedby` in ($impIds) "); 

	while($fetch=mysqli_fetch_array($ds2)){
		//$rmobile=preg_replace("/[^0-9]+/", "", $fetch['contact_no']);
		
		/* $rmobile=preg_replace("/[^0-9]+/", "", $fetch['contact_no']);
		
		
		      $childs[]="'"."91".$rmobile."'";*/
		
		
		      $childs[]="'"."91".$fetch['contact_no']."'";
				
		}
	return $childs;	
	
	
}

function getTeamListIds($conn,$assocArr){
	
	if(count($assocArr)>0){
		$impIds=implode(",",$assocArr);	
	}else{
		$impIds=0;
	}
	$childs=array();
	//echo "SELECT `contact_no` FROM `leads` where `postedby` in ($impIds) ";
	$ds2=mysqli_query($conn,"SELECT `id` FROM `leads` where `postedby` in ($impIds) "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['id'];
				
		}
	return $childs;	
	
	
}


function getTeamClient91($conn,$assocArr){
	
	if(count($assocArr)>0){
		$impIds=implode(",",$assocArr);	
	}else{
		$impIds=0;
	}
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `mobile` FROM `clientsnew` where `aid`in ($impIds) "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]="'"."91".$fetch['mobile']."'";
				
		}
	return $childs;	
	
	
}
function getTeamClientIds($conn,$assocArr){
	
	if(count($assocArr)>0){
		$impIds=implode(",",$assocArr);	
	}else{
		$impIds=0;
	}
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `id` FROM `clientsnew` where `aid`in ($impIds) "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['id'];
				
		}
	return $childs;	
	
	
}
function getList91BeforeDate($conn,$aid,$pdate){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `contact_no` FROM `leads` where `postedby` ='$aid' and `pdate`<= '$pdate' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		 //   $contactno=$fetch['contact_no'];
			  $rmobile=preg_replace("/[^0-9]+/", "", $fetch['contact_no']);
		      $childs[]="91".$rmobile;
				
		}
	return $childs;	
	
	
}


function getTeamList91BeforeDate($conn,$assocArr,$pdate){
	
	if(count($assocArr)>0){
		$impIds=implode(",",$assocArr);	
	}else{
		$impIds=0;
	}
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `contact_no` FROM `leads` where `postedby` in ($impIds) and `pdate`<= '$pdate' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		 //   $contactno=$fetch['contact_no'];
			$rmobile=preg_replace("/[^0-9]+/", "", $fetch['contact_no']);
		      $childs[]="91".$rmobile;
				
		}
	return $childs;	
	
	
}


function getQualifiedCount($conn,$aid){
		
	$ds=mysqli_query($conn,"SELECT count(*) as count from `leads` where `postedby` ='$aid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];

}

function getVisitShortCodes($conn,$project){
	$shcodes=array();
	 $expProj=explode(",",$project);
	
	foreach($expProj as $pid){
	//	echo getProjectShortCodesNew($conn,$pid);
	$shcodes[]=	getProjectShortCodesNew($conn,$pid);
		
	}
//	print_r($shcodes);
	return implode(",",$shcodes); 
	
}

function getProjectShortCodesNew($conn,$pid){
	//	echo "SELECT *  from `crm_inv_project` where `project_id` ='$pid'";
	$ds=mysqli_query($conn,"SELECT *  from `crm_inv_project` where `project_id` ='$pid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['project_code'];

}

function welcomeemailtouser($baseurl,$name,$anicode,$conn){
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:left;">
                                               
												<p>Hello <b>'.$name.',</b></p>
<p>Welcome to Acres N Inches (ANI). We have received your application for a provisional code/ID. Your
provisional ID is <b>'.$anicode.'</b></p>
<p>To know more about our organization and its values, you may attend our informational seminars
which will explain to you about the manner in which we work and all details associated with how
you can benefit by getting associated with Acres N Inches. We shall address any specific queries that
you may have during these seminars.</p>
<p>It is mandatory for you to at least attend the following informational sessions in order to be aware of
the details of our systems of operations and the responsibilities and requirements associated with
the same if you wish to enrol with us as our associate.</p>

<p>Details/ Name of sessions required as as follow : </p>';

$ds=mysqli_query($conn,"SELECT * FROM `seminars` where `mandatory`='1' and `status`='1' and `view` ='1' order by position asc"); 
			$numrows=mysqli_num_rows($ds);
			if($numrows >0){
			while($fetch=mysqli_fetch_array($ds)){
				$i++;
				
			
				 $msg.='<b><p> '.$i.'. <span>'.$fetch["code"].'</span>  <span style="text-align:left;">'.$fetch["title"].'</span> <p></b>';
			 }
			}


$msg.='<p>Note 1* - The provisional ID will remain valid only for a period of 90 days from today and this
validity shall be subject to your attending the aforementioned informational sessions and have
referred at least 4 individuals for the same, failing which you shall not be eligible for any promotions
going forward.</p>All matters in relation to the term or extension of the provisional
code or engagement thereunder may be changed and shall be subject to the sole discretion of ANI.

<p>Note 2* - You shall comply with all applicable laws and regulations including but not limited to The
Real Estate (Regulation and Development) Act, 2016 (RERA) prior to your enrolment as our
associate. You shall not solicit or advise any sale of property without fully complying with all
applicable laws and regulations.</p>
												 
                                            </td>
                                        </tr>
                                        <tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <td align="center" valign="middle" style="padding-right:40px; padding-bottom:40px; padding-left:40px;">
                                                <table border="0" cellpadding="0" cellspacing="0" class="emailButton" style="border-collapse:separate !important; border-radius:3px;">
												Follow us on : <a href="https://www.facebook.com/AcresNInches.ANI/"><img src="'.$baseurl.'/images/fbb.png"></a>  <a href="https://twitter.com/acres_ninches"><img src="'.$baseurl.'/images/twtn.png"></a>  <a href="https://www.instagram.com/acres_n_inches/"><img src="'.$baseurl.'/images/ins.png"></a>  <a href="https://www.youtube.com/channel/UCHj3hnIPlHPPDx6UM51Ubfg"><img src="'.$baseurl.'/images/you.png"></a>  <a href="https://www.instagram.com/acres_n_inches/"><img src="'.$baseurl.'/images/lnk.png"></a>
                                                  
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                          This e-mail and any files transmitted with it may contain confidential and privileged information are for the sole use of the intended recipient(s). If you are not the intended recipient please appraise the sender by reply e-mail and destroy all copies and the original message. The information contained in this e-mail including the attachment/of the content is being provided to you for the specific purpose of evaluation. No legal consequences can be derived of this e-mail. Any unauthorized disclosure, dissemination, forwarding, printing or copying of this email or any action taken on this e-mail is strictly prohibited and may be unlawful. The recipient acknowledges that Acres N Inches or its subsidiaries and associated companies, are unable to exercise control or ensure or guarantee the integrity of the contents of the information contained in e-mail transmissions and further acknowledges that any views expressed in this message are those of the individual senders and no binding nature of the message shall be implied or assumed unless the sender does so expressly with due authority of Acres N Inches.
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}


function emailtoassoconinventoryheld($baseurl,$name,$project,$pdate,$customer,$conn){
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:left;">
                                               
												<p>Greeting <b>'.$name.',</b></p>
<p>This is to hereby inform you that  <b>'.$project.'</b>  has been temporarily held by you for '.$customer.' and will be valid till date '.$pdate.' </p>
<p>Kindly ensure that following requirements from Customer are submitted to concerned Builder failing which the said unit no. in the said project shall be released.</p>
<p>a. Duly Filled Application Form of concerned Builder for the said property.</p>
<p>b. KYC documents(Pan Card+Adhar card Or voter id card+passport size photo)</p>
<p>c. Current date cheque or RTGS of Rs 100000/-in favour of concerned Builder.</p>
<p>d. PDC Cheque to complete 10% booking amount(maximum 15 days from the date of booking )</p>
<p>Best Regards</p>
<b>TEAM ANI</b></p>
												 
                                            </td>
                                        </tr>
                                       
                                       
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                          This e-mail and any files transmitted with it may contain confidential and privileged information are for the sole use of the intended recipient(s). If you are not the intended recipient please appraise the sender by reply e-mail and destroy all copies and the original message. The information contained in this e-mail including the attachment/of the content is being provided to you for the specific purpose of evaluation. No legal consequences can be derived of this e-mail. Any unauthorized disclosure, dissemination, forwarding, printing or copying of this email or any action taken on this e-mail is strictly prohibited and may be unlawful. The recipient acknowledges that Acres N Inches or its subsidiaries and associated companies, are unable to exercise control or ensure or guarantee the integrity of the contents of the information contained in e-mail transmissions and further acknowledges that any views expressed in this message are those of the individual senders and no binding nature of the message shall be implied or assumed unless the sender does so expressly with due authority of Acres N Inches.
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}

function emailtoassoconinventoryrelease($baseurl,$name,$project,$customer,$conn){
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:left;">
                                               
												<p>Greeting <b>'.$name.',</b></p>
<p>This is to hereby inform you that  <b>'.$project.'</b>   held by you for '.$customer.' has been released as required documents were not submitted</p>
<p>Best Regards</p>
<b>TEAM ANI</b></p>
												 
                                            </td>
                                        </tr>
                                       
                                       
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                          This e-mail and any files transmitted with it may contain confidential and privileged information are for the sole use of the intended recipient(s). If you are not the intended recipient please appraise the sender by reply e-mail and destroy all copies and the original message. The information contained in this e-mail including the attachment/of the content is being provided to you for the specific purpose of evaluation. No legal consequences can be derived of this e-mail. Any unauthorized disclosure, dissemination, forwarding, printing or copying of this email or any action taken on this e-mail is strictly prohibited and may be unlawful. The recipient acknowledges that Acres N Inches or its subsidiaries and associated companies, are unable to exercise control or ensure or guarantee the integrity of the contents of the information contained in e-mail transmissions and further acknowledges that any views expressed in this message are those of the individual senders and no binding nature of the message shall be implied or assumed unless the sender does so expressly with due authority of Acres N Inches.
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}

function getSitevisitList($conn){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT  `referredcode` FROM `sitevisits` where `status`='1' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=strtoupper($fetch['referredcode']);
				
		}
	return $childs;	
	
	
}

function getSitevisitListbetweendates($conn,$sdate,$edate){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT  `referredcode` FROM `sitevisits` where `status`='1' and `pickupdate` between '$sdate' and '$edate' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=strtoupper($fetch['referredcode']);
				
		}
	return $childs;	
	
	
}

function getSiteVisitCountReport($conn,$mycodes){
	$total=0;
	$today=0;
	$curDate=date("Y-m-d");
	//echo count($mycodes);
	if(count($mycodes)>0){
		foreach($mycodes as $code){
			$anicodes[]='"'.$code.'"';	
		}
			$impCode=implode(",",$anicodes);
			$ds2=mysqli_query($conn,"SELECT  `pickupdate`  FROM `sitevisits` where `status`='1' and `referredcode` in ($impCode) "); 
	}else{
			$ds2=mysqli_query($conn,"SELECT  `pickupdate`  FROM `sitevisits` where `status`='1' and `referredcode` ='0' "); 
	}
//echo "SELECT  `pickupdate`  FROM `sitevisits` where `status`='1' and `referredcode` in ($impCode) ";
	//$ds2=mysqli_query($conn,"SELECT  `pickupdate`  FROM `sitevisits` where `status`='1' and `referredcode` in ($impCode) "); 

	while($fetch=mysqli_fetch_array($ds2)){
		$total++;
		      $pickupdate=$fetch['pickupdate'];
			  if($pickupdate==$curDate){
				 $today=$today+1;  
			  }
				
		}
	return $today."###".$total;	
	
	
}
function checkmychildcode($conn,$aid,$self){
	$childs=array();
	 $ds2=mysqli_fetch_row(mysqli_query($conn,"SELECT count(*)  FROM `parents`  where `parent`='$aid' and  `self`='$self' ")); 

	if($ds2[0]>0){
		return true;	
	}else{
		return false;		
	}
}
function checkbookingstatus($conn,$bid){
	$childs=array();
	 $ds2=mysqli_fetch_row(mysqli_query($conn,"SELECT count(*)  FROM `seminarattendence`  where `bookingid`='$bid' and  `view`='1' ")); 

	if($ds2[0]>0){
		return true;	
	}else{
		return false;		
	}
}
function isQualified($conn,$aid){
	
	 $ds2=mysqli_fetch_row(mysqli_query($conn,"SELECT `qualified`  FROM `mlm_associate_detail`  where `associate_detail_id`='$aid'  ")); 

	if($ds2[0]==1){
		return true;	
	}else{
		return false;		
	}
}
function gettitleDetailById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `title` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getFirstSmsText($conn,$lid){
	$leadsDetail=getLeadDetailById($conn,$lid);
	$title=gettitleDetailById($conn,$leadsDetail['title']);
	$Name=$leadsDetail['name'];
	$assocName=associatenamefromid($conn,$leadsDetail['postedby']);
	$text="Hello ".$title." ".$Name.", I am glad to inform you that I am associated with Acres N Inches, a brand known for best properties at fair prices.Will meet you soon. To know more click http://www.acresninches.com . Best Regards ".$assocName." ";
return $text;	
}
function updateSmsStatusofLead($conn,$lid){
	$pdate=date("Y-m-d");
	$ds=mysqli_query($conn,"Update `leads` set `smsstatus`='1' ,`firstsms`='$pdate' where `id`='$lid'"); 
	}
	
function updateSmsStatusofLeadwithrequestid($conn,$lid,$rid){
	$pdate=date("Y-m-d");
	$ds=mysqli_query($conn,"Update `leads` set `smsstatus`='1' ,`firstsms`='$pdate' ,`smsrequestid`='$rid'  where `id`='$lid'"); 
	}	
	
function getSitevisitCountByAsscode($conn,$ass){
	
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `sitevisits` where `referredcode`='$ass' and `status`='1' and `cancelledstatus`='0'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}

function getSitevisitCountByAsscodebetweendates($conn,$ass,$sdate,$edate){
	
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `sitevisits` where `referredcode`='$ass' and `status`='1' and `cancelledstatus`='0' and `pickupdate` between '$sdate' and '$edate'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}

function getTodayTeamCountByCodeANdType($conn,$code,$type){
	
	 $aid=associateidfromcode($conn,$code);
	$curDate=date("Y-m-d");
	if($type==1){
		$date='followdate';	
	}
	if($type==4){
		$date='meetingdate';	
	}
	if($type==5){
		$date='expsitevisitdate';	
	}
	
//	echo "SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date ='$curDate'";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date ='$curDate'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
	
}
function getTodayTeamCountByCodeANdTypeAndDates($conn,$code,$type,$sdate,$edate){
	
	 $aid=associateidfromcode($conn,$code);
	$curDate=date("Y-m-d");
	if($type==1){
		$date='followdate';	
	}
	if($type==4){
		$date='meetingdate';	
	}
	if($type==5){
		$date='expsitevisitdate';	
	}
	
//	echo "SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date ='$curDate'";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and `$date` between '$sdate' and '$edate'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
	
}

function getSecondSmsText($conn,$lid){
	$leadsDetail=getLeadDetailById($conn,$lid);
	$title=gettitleDetailById($conn,$leadsDetail['title']);
	$Name=$leadsDetail['name'];
	$assocName=associatenamefromid($conn,$leadsDetail['postedby']); 
	 $msg1="Hello ".$title." ".$Name."! This side ".$assocName.". I have recommended your name to receive free of cost updates from Acres N inches about best properties at fair prices. Best Regards";

	$msg2="Dear ".$title." ".$Name.". Your name has been recommended by ".$assocName." for you to receive free of cost updates about best properties at fair prices.To unsubscribe click http://www.ani.acresninches.com/us.php?lid=".base64_encode($lid)." .Best Regards Team ANI";
return $msg1."###".$msg2;	
}

function updateQualifiedCount($conn,$aid){
	$curDate=date("Y-m-d");
	$ds=mysqli_query($conn,"Update `mlm_associate_detail` set `qualified`='1' ,`qualifiedon`='$curDate' where `associate_detail_id` ='$aid' and `qualified`='0' "); 
}

function getMovedDepartment($conn,$id){
	//echo "SELECT *  FROM `querydepartments` where `query_id`='$id' ";
		$ds=mysqli_query($conn,"SELECT *  FROM `querydepartments` where `query_id`='$id' "); 
		$numrows=mysqli_num_rows($ds);
	   
	    if($numrows==0){
			return "None";	
		}else{
			$ds=mysqli_query($conn,"SELECT *  FROM `querydepartments` where `query_id`='$id' "); 
			//$ds1=mysqli_fetch_assoc($ds);
			while($fetch=mysqli_fetch_array($ds)){
			//echo "Testing";
		//	echo getDepartmentNameById($conn,$fetch['department_id']);
			$data[]=getDepartmentNameById($conn,$fetch['department_id']);
			
			}	
			//print_r($data); 
		return implode(",",$data);	
		}
		
	
}

function getMovedDepartmentIds($conn,$id){
	
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `querydepartments` where `query_id`='$id' "); 
	    $ds1=mysqli_fetch_assoc($ds);
	    if($ds1['count']==0){
			return "0";	
		}else{
			$ds=mysqli_query($conn,"SELECT * FROM `querydepartments` where `query_id`='$id'"); 
			$numrows=mysqli_num_rows($ds);
			
			while($fetch=mysqli_fetch_array($ds)){
			
			$data[]=$fetch['department_id'];
			
			}	
		return implode(",",$data);	
		}
		
	
}
function getMovedDepartmentIdsArr($conn,$id){
	
		$ds=mysqli_query($conn,"SELECT count(*) as count FROM `querydepartments` where `query_id`='$id' "); 
	    $ds1=mysqli_fetch_assoc($ds);
	    if($ds1['count']==0){
			return "0";	
		}else{
			$ds=mysqli_query($conn,"SELECT * FROM `querydepartments` where `query_id`='$id'"); 
			$numrows=mysqli_num_rows($ds);
			
			while($fetch=mysqli_fetch_array($ds)){
			
			$data[]=$fetch['department_id'];
			
			}	
		return $data;	
		}
		
	
}
function getProvisionalHoldedInventoriesofTeamHead($conn,$assocode,$associd){
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `teamheadcode`='$assocode' and `holdstatus`='1' and `phold`='1' order by `id` desc  "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$cid=$fetch['id'];
			$floorid=$fetch['floor_id'];
			
			if(checkFloorIsOnHold($conn,$floorid)){
				$holded[]=$cid;	
			}
			
			
			
			
		}
		//return $error;		
	return 	$holded;
		
}

function getPickupPoint($conn,$vid){
	$curDate=date("Y-m-d");
	$ds=mysqli_query($conn,"SELECT * FROM `sitevisits` where  `id`='$vid' ");
	$ds1=mysqli_fetch_assoc($ds);
    if($ds1==4){
		$pickuppoint=$ds1['onroute_pickpoint']; 	
	}else{
		$pickuppoint=getPickupName($conn,$ds1['pickuppoint']);
	}
	
	return $pickuppoint;
}
function getPickupName($conn,$id){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT pickup_pointname FROM `pickuppoint` where  `id`='$id'   ")); 
	 return 	$ds2['pickup_pointname'];
}


function getcommissionvaluebyProjectPlanFloor($conn,$pid,$fid,$plan){
	//echo "SELECT `commision` FROM `crm_inv_payment_plan` WHERE `project_id`='$pid' and `payment_plan_master_id` ='$plan' and `floor_id`='$fid'  ";
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `commision` FROM `crm_inv_payment_plan` WHERE `project_id`='$pid' and `payment_plan_master_id` ='$plan' and `floor_id`='$fid'  ")); 
	 return 	$ds2['commision'];
}


function getCommissionrateByPlanANdSizeANdTower($conn,$plan,$size,$pid,$tid){
	 $holded=array();
	// echo "SELECT `floor_id` FROM `crm_inv_project_floor` WHERE `project_id`='$pid' and `basic_size`='$size' order by `id` limit 0,1  ";
	 $ds2=mysqli_query($conn,"SELECT `floor_id` FROM `crm_inv_project_floor` WHERE `project_id`='$pid' and `basic_size`='$size' and `tower_id`='$tid' order by `floor_id` limit 0,1  "); 

	 while($fetch=mysqli_fetch_array($ds2)){
			
			$floorid=$fetch['floor_id'];
			
			
			$comm=getcommissionvaluebyProjectPlanFloor($conn,$pid,$floorid,$plan);
			
			
			
			
			
		}
		//return $error;		
	return 	$comm;
		
}
function getFloorAvailableStatus($conn,$fid){
	//echo "SELECT `commision` FROM `crm_inv_payment_plan` WHERE `project_id`='$pid' and `payment_plan_master_id` ='$plan' and `floor_id`='$fid'  ";
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `status` FROM `crm_inv_project_floor` WHERE  `floor_id`='$fid'  ")); 
	 if($ds2['status']=='Available'){
		return true; 
	 }else{
		 return false;
	 }
}






function getconcernedheadGmandAbove($conn,$id){
	$arr = array();  
	$parent = 1;
while($parent != 0 || $parent != '')
{
	if($i == 0)
	{
		$id = $id;
		$arr[0] = $id;
		$i++;
	}
	else
	{ 
		$id = $parent;
		$i++;
	}
	//echo "<br/>";
  $aresult ="SELECT mt.id, mt.parent,mt.desigination_id,mt.code ,md.blocked as blocked FROM `mlm_tree` mt inner join `mlm_associate_detail` md on md.associate_code=mt.code where id=$id" ;

	$result2=mysqli_query($conn,$aresult);
	$row=mysqli_fetch_array($result2);
	$parent = $row['parent'];
	$blocked = $row['blocked'];
	if($parent!=''){
	 $arr[$i] = $row['parent'];
	 $desigination_id=$row['desigination_id'];
	 if (  ( ($desigination_id=='GM') || ($desigination_id=='AVP') || ($desigination_id=='VP') || ($desigination_id=='SVP')) && ($blocked==1)){
		$gm= $row['code'];
		 return $gm;
		 exit();
	 }
	 
	}
	 //$arr[$i] = $row['desigination_id'];
	 //$desigination_name=$row['desigination_name'];
	 
	
	
}	
	//return $arr;
	
}


function checkSmsStatus($conn,$id){
	
	 $contact=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `contact_no` FROM `leads` WHERE  `id`='$id'  ")); 
	 $mobile="91".$contact['contact_no'];
	 
	 $numrows=mysqli_num_rows(mysqli_query($conn,"SELECT *  FROM `smsstatus` WHERE  `sender_id`='$mobile' order by `id` desc  "));
	 if($numrows>0){
	 
	  
     $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `status`,`description` FROM `smsstatus` WHERE  `sender_id`='$mobile' order by `id` desc  ")); 
	 
	 if($ds2['status']=='1'){
		return "<img src='images/delivered.png'>"; 
	 }else{
		 return "<a href='resendsms.php?lid=".base64_encode($id)."'>".$ds2['description']." [ Resend ]</a>";
	 }
	 
	 
	 }else{
		 return "<img src='images/na.png'>"; 
	 }
	
}

function viewpage($conn,$id){
	  $aresult =mysqli_query($conn,"UPDATE viewpages SET view = view +1 WHERE pageid=$id") ;
	
}
function countUnapprovedMessages($conn){
	 $contact=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(*) as count FROM `postforteam` WHERE  `status`='0'  ")); 
	return $contact['count'];
}

function getTotalList($conn,$associd){
		$ds=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' ")); 
		return $ds['count'];
	}
	
function getNewTeamHeadCode($conn,$aid){
	    $trid=getTreeIdByAssociateId($conn,$aid);
		$parents=getParentsTree($conn,$trid);
		array_pop($parents);
		$flag=0;
		foreach($parents as $pid){
			if($flag!=1){
		$associd=getAssociateIdByTreeId($conn,$pid);
		$code=associatecodefromid($conn,$associd);
		if(checkisTeamHead($conn,$code)){
			$flag=1;
			$thead=$code;
			
		}
			
			}
		}
		
	return $thead;
}


function getProjectByTypeANdId($conn,$pid,$type){
   $curDate=date("Y-m-d");
   if($type==1){
		$ds=mysqli_query($conn,"SELECT `project_name` as name FROM `crm_inv_project` where   `project_id`='$pid'  "); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT `name` as name  FROM `nonexsubprojects` where   `id`='$pid'   "); 
	}
	
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
 
} 
function getidByMobileAndType($conn,$type,$mobile){
	 if($type==1){
		$ds=mysqli_query($conn,"SELECT `id` as id  FROM `clients` where   `mobile`='$mobile' order by id asc limit 0,1  "); 
	}
	if($type==2){
		$ds=mysqli_query($conn,"SELECT `id` as id  FROM `leads` where   `contact_no`='$mobile' order by id asc limit 0,1   "); 
	}
	
	if($type==3){
		$ds=mysqli_query($conn,"SELECT `associate_detail_id` as id  FROM `mlm_associate_detail` where   `contact_no`='$mobile' order by id asc limit 0,1   "); 
	}
	
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['id'];
	
}

function getRedirectUrlBYsmsid($conn,$smsid){
	$url="http://www.acresninches.com/";
	$ds=mysqli_query($conn,"SELECT *    FROM `smstoshoot` where   `id`='$smsid'   ");
	$ds1=mysqli_fetch_assoc($ds);
	 $type=$ds1['type'];

	$projectid=$ds1['urlid'];
	if($type==2){
		$url= getNonExcProjUrlById($conn,$projectid);
	}
	
	if($type==1){
		$url= getExcProjUrlById($conn,$projectid);
	}
	
	return $url;
	 
	
}

function getReraTextByAid($conn,$aid){
	
	$ds=mysqli_query($conn,"SELECT `first_name`,`contact_no` FROM `mlm_associate_detail` where `associate_detail_id`='$aid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	return "Call ".$ds1['first_name']." @ ".$ds1['contact_no'];
}

function getSMSHistory($conn){
	
	$ds=mysqli_query($conn,"SELECT count(*) as count from `smstoshoot` "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}

function getSMSClick($conn){
	
	$ds=mysqli_query($conn,"SELECT count(*) as count from `smsclicks` "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}

function getTotalSMSClick($conn,$sid){
	
	$ds=mysqli_query($conn,"SELECT count(*) as count from `smsclicks` where `smsid`='$sid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}

function getTotalSMSClickProjectWise($conn,$pid){
	$clients=0;
	$worksheet=0;
	$assoc=0;
			$ds=mysqli_query($conn,"SELECT `id` FROM `smstoshoot` where `urlid`='$pid'"); 
			$numrows=mysqli_num_rows($ds);
			while($fetch=mysqli_fetch_array($ds)){
				$smsid=$fetch['id'];
				
				$ds1=mysqli_query($conn,"SELECT `type` FROM `smsclicks` where `smsid`='$smsid'"); 
				$numrows1=mysqli_num_rows($ds1);
				while($fetch1=mysqli_fetch_array($ds1)){
				$type=$fetch1['type'];
				if($type==1){
					$clients=$clients+1;	
				}
				if($type==2){
					$worksheet=$worksheet+1;	
				}
				if($type==3){
					$assoc=$assoc+1;	
				}
				
				
				}	
				
				
			}	
	
	$grand=$clients."##".$worksheet."##".$assoc;
	return $grand;
	
	
}

function getClickHistoryByType($conn,$smsid,$type){
	
	$ds=mysqli_query($conn,"SELECT count(*) as count from `smsclicks` where `smsid`='$smsid' and `type`='$type' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}

function getnoofclickreport($conn,$smsid,$aid,$type){
	$ds=mysqli_query($conn,"SELECT count(*) as count from `smsclicks` sc inner join `leads` ld on ld.id=sc.userid where sc.`smsid`='$smsid' and sc.`type`='$type' and ld.`postedby`='$aid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}

function getnoofclicks($conn,$smsid,$lid){
	$ds=mysqli_query($conn,"SELECT count(*) as count from `smsclicks` where `type`='2' and `userid`='$lid' AND smsid='$smsid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
}


function getSeminaratendedbyass($conn,$aid){
	$modules=array();
	$childs=array();
	$bookings=array();
	$mandatorySeminar=array();
	$nm=1;
	
	$ds2=mysqli_query($conn,"SELECT `id` FROM `seminarbookings`  where `assoc_id`='$aid' "); 
	while($fetch=mysqli_fetch_array($ds2)){
   		$childs[]=$fetch['id'];
	}
	
	if(count($childs)>0){
		$impids=implode(",",$childs);
	}else{
		$impids=0;	
	}
	
	$ds23=mysqli_query($conn,"SELECT `bookingid` FROM `seminarattendence`  where bookingid in($impids)   "); 
	
	while($fetch3=mysqli_fetch_array($ds23)){
		$bookings[]=$fetch3['bookingid'];
	}
	
	if(count($bookings)>0){
		$impbids=implode(",",$bookings);
	}else{
		$impbids=0;	
	}
//	echo "SELECT `roaster_detail_id` FROM `seminarbookings`  where id in($impbids)   ";
	
	
		$ds234=mysqli_query($conn,"SELECT `roaster_detail_id` FROM `seminarbookings`  where id in($impbids)   "); 
	
	while($fetch34=mysqli_fetch_array($ds234)){
		$rid=$fetch34['roaster_detail_id'];
		$roasterArr=getRoasterDetailsDetailById($conn,$rid);
		$moduleid=$roasterArr['module_id'];
		$moduleArr[]=$moduleid;	
		if(checkMandatoryStatus($conn,$moduleid)){
			$mandatorySeminar[]=$moduleid;	
		}
		
		
	}
	
	$allseminar=array_unique($moduleArr);
	$mandatoryseminar=array_unique($mandatorySeminar);
		
	return count($allseminar)."##".count($mandatoryseminar);
		
}

function getLapseTeamCountByCodeANdType($conn,$code,$type){
	
	 $aid=associateidfromcode($conn,$code);
	$curDate=date("Y-m-d");
	if($type==1){
		$date='followdate';	
	}
	if($type==4){
		$date='meetingdate';	
	}
	if($type==5){
		$date='expsitevisitdate';	
	}
	
//	echo "SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date ='$curDate'";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date <'$curDate'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
	
}
function getLapseTeamCountByIdANdType($conn,$aid,$type){
	
	// $aid=associateidfromcode($conn,$code);
	$curDate=date("Y-m-d");
	if($type==1){
		$date='followdate';	
	}
	if($type==4){
		$date='meetingdate';	
	}
	if($type==5){
		$date='expsitevisitdate';	
	}
	
//	echo "SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date ='$curDate'";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date <'$curDate'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
	
}


function getTodaysTeamCountByIdANdType($conn,$aid,$type,$sdate,$edate){
	
	// $aid=associateidfromcode($conn,$code);
	$curDate=date("Y-m-d");
	if($type==1){
		$date='followdate';	
	}
	if($type==4){
		$date='meetingdate';	
	}
	if($type==5){
		$date='expsitevisitdate';	
	}
	
//	echo "SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and $date ='$curDate'";
//echo "SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and `$date` between '$sdate' and '$edate' ";
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `leads` where `postedby`='$aid' and `leadtype`='$type'  and `$date` between '$sdate' and '$edate' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['count'];
	
}



function checkMandatoryStatus($conn,$aid){
			$ds=mysqli_query($conn,"SELECT * FROM `seminars` where `id`='$aid'"); 
			$fetch=mysqli_fetch_assoc($ds);
			$mandatory=$fetch['mandatory'];
			
			if($mandatory==1){
			return true;	
			}else{
			return false;	
			}
	
}

function getAppropriateRera($conn,$id){
	
	$ds=mysqli_query($conn,"SELECT * FROM `nonexsubprojects` where `id`='$id'"); 
			$fetch=mysqli_fetch_assoc($ds);
			$mandatory=$fetch['rera'];
			return $mandatory;
	
}
function getAppropriateImg($conn,$id){
	
	$ds=mysqli_query($conn,"SELECT * FROM `nonexsubprojects` where `id`='$id'"); 
			$fetch=mysqli_fetch_assoc($ds);
			$mandatory=$fetch['image'];
			return "<img src='images/logo/$mandatory'>";
	
}


function welcomeemailtotempuser($baseurl,$name,$referee,$tid,$conn){
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:left;">
                                               
												<p>Dear <b>'.$name.',</b></p>
<p>You have been referred by <b>'.$referee.'</b> to be associated with Acres N Inches Private Limited.</p><p>
In order to associate with us, you have to click on the inserted link to understand the terms and conditions of angagement and thereafter, enrol yourself.
<p> <a  href="'.$baseurl.'/amc.php?tid='.$tid.'">Click Here for Terms & condition of Engagement</p>
<p>Regards,
<p>Acresninches Private Limited </p>

												 
                                            </td>
                                        </tr>
                                        <tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <td align="center" valign="middle" style="padding-right:40px; padding-bottom:40px; padding-left:40px;">
                                                <table border="0" cellpadding="0" cellspacing="0" class="emailButton" style="background-color:#6DC6DD; border-collapse:separate !important; border-radius:3px;">
                                                  
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                          This e-mail and any files transmitted with it may contain confidential and privileged information are for the sole use of the intended recipient(s). If you are not the intended recipient please appraise the sender by reply e-mail and destroy all copies and the original message. The information contained in this e-mail including the attachment/of the content is being provided to you for the specific purpose of evaluation. No legal consequences can be derived of this e-mail. Any unauthorized disclosure, dissemination, forwarding, printing or copying of this email or any action taken on this e-mail is strictly prohibited and may be unlawful. The recipient acknowledges that Acres N Inches or its subsidiaries and associated companies, are unable to exercise control or ensure or guarantee the integrity of the contents of the information contained in e-mail transmissions and further acknowledges that any views expressed in this message are those of the individual senders and no binding nature of the message shall be implied or assumed unless the sender does so expressly with due authority of Acres N Inches.
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}


function birthdaymail($name,$baseurl){
$msg='<body>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        <tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="Acresninches"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style=" border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px;">
                                	<a  href="" target="_blank" title="Acresninches"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;background: url('.$baseurl.'/img/party.png);"><img src="'.$baseurl.'/img/happybday.png" alt="Happy Birthday" height=""  class="logoImage" style=" border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:left;">
                                               
												<p>Dear <b style="color:#06C;font-weight:bold;">'.$name.' !</b></p>
<p>Wish you a very happy birthday and a great journey ahead!<p>
Our prayers to the ALMIGHTLY to bless you with lots of happiness,good health and prosperity! Keep Shining ! 

<p>Best Regards,
<p style="font-weight:bold;">Team Acres N Inches</p>

												 
                                            </td>
                                        </tr>
                                        <tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <td align="center" valign="middle" style="padding-right:40px; padding-bottom:40px; padding-left:40px;">
                                                <table border="0" cellpadding="0" cellspacing="0" class="emailButton" style="background-color:#6DC6DD; border-collapse:separate !important; border-radius:3px;">
                                                  
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                          This e-mail and any files transmitted with it may contain confidential and privileged information are for the sole use of the intended recipient(s). If you are not the intended recipient please appraise the sender by reply e-mail and destroy all copies and the original message. The information contained in this e-mail including the attachment/of the content is being provided to you for the specific purpose of evaluation. No legal consequences can be derived of this e-mail. Any unauthorized disclosure, dissemination, forwarding, printing or copying of this email or any action taken on this e-mail is strictly prohibited and may be unlawful. The recipient acknowledges that Acres N Inches or its subsidiaries and associated companies, are unable to exercise control or ensure or guarantee the integrity of the contents of the information contained in e-mail transmissions and further acknowledges that any views expressed in this message are those of the individual senders and no binding nature of the message shall be implied or assumed unless the sender does so expressly with due authority of Acres N Inches.
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body>';	
						return $msg;
}

function getTempAssocDetails($conn,$tid){
	//echo "SELECT `commision` FROM `crm_inv_payment_plan` WHERE `project_id`='$pid' and `payment_plan_master_id` ='$plan' and `floor_id`='$fid'  ";
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `mlm_associate_detail_temp` WHERE  `associate_detail_id`='$tid'  ")); 
	return $ds2;
}


function checkTermofengagementdone($conn,$tid){
	
	//echo "SELECT count(*) as count FROM `mlm_associate_detail_new` where `tempid`='$tid'";
	//die;
	
	$tempArr=getTempAssocDetails($conn,$tid);
	$cnt=$tempArr['contact_no'];
	$pan=$tempArr['pan_no'];
	
	
			$ds=mysqli_query($conn,"SELECT count(*) as count FROM `mlm_associate_detail` where (`tempid`='$tid' or  `contact_no`='$cnt' or `pan_no`='$pan' ) and `blocked`='1'"); 
			$fetch=mysqli_fetch_assoc($ds);
			$mandatory=$fetch['count'];
			
			if($mandatory>0){
				return true;	
			}else{
				return false;	
			}	
}

function getassociatefewdetailsbyid($conn,$id){
	$ds=mysqli_query($conn,"SELECT mt.id as treeid, CONCAT(`first_name`,' ' , `middle_name`,' ' , `last_name`) AS name ,contact_no as mobileno,associate_code as code ,mad.rera_rk_approval as reraapproval FROM `mlm_associate_detail` mad inner join mlm_tree mt on mad.associate_detail_id=mt.associate_detail_id  where mad.`associate_detail_id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	return $ds1;
 
} 


function getassociatetreeidassccodebyid($conn,$id){
	$ds=mysqli_query($conn,"SELECT mt.id as treeid, CONCAT(`first_name`,' ' , `middle_name`,' ' , `last_name`) AS name ,mad.associate_code as code ,mad.associate_detail_id as mid FROM `mlm_associate_detail` mad inner join mlm_tree mt on mad.associate_detail_id=mt.associate_detail_id  where mt.`id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	return $ds1;
 
}
function checkIntrusion($sesid,$baseurl){
if($sesid=='' || $sesid=='NULL' || $sesid=='0' ){
header("location:".$baseurl."/index.php");	
}
	
}

function getBuilderSMSByQid($conn,$qid,$baseurl){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `checknonavailability` WHERE  `id`='$qid'  ")); 
	 
	 
	$Query[]="Size between : ".$ds2['sizefrom']."-".$ds2['sizeto'];
	$Query[]="Floor between : ".$ds2['floorfrom']."-".$ds2['floorto'];
	$Query[]="Budget between : ".$ds2['budgetfrom']."-".$ds2['budgetto'];
	
	if($ds2['tower']==''){
		$Query[]="Any Tower";	
	}else{
		$Query[]="Tower: ".$tower;	
	}
	
	if($ds2['plan']==''){
		$Query[]="Any Plan";	
	}else{
		$Query[]="Plan ".$plan;	
	}
	$pid=$ds2['projectid'];
	$client=$ds2['client'];
	$qp=base64_encode($qid."-".$pid);
	
	 $approvalLink=$baseurl."/bqlogin.php?qid=".$qp."";
	  
	 $message="Query for : (".getProjectByTypeANdId($conn,$pid,2).") , -  ".implode(", ",$Query).", for Client : ". getLeadNameById($conn,$client)." Click To Reply ".$approvalLink."";
	  
	
	
	return $message;
}


function checkbuilderqueryreplyexists($conn,$qid){
	
	//echo "SELECT count(*) as count FROM `mlm_associate_detail_new` where `tempid`='$tid'";
	//die;
	//echo "SELECT count(*) as count FROM `builderqueryreply` where `qid`='$qid'";
			$ds=mysqli_query($conn,"SELECT count(*) as count FROM `builderqueryreply` where `qid`='$qid'"); 
			$fetch=mysqli_fetch_assoc($ds);
			$mandatory=$fetch['count'];
			
			if($mandatory>0){
				return true;	
			}else{
				return false;	
			}	
}

function getReplyToQuery($conn,$qid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `builderqueryreply` WHERE  `qid`='$qid'  ")); 
	 return $ds2['reply']; 
	 
	 
	 
}

function getQueryDetailsByQid($conn,$qid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `checknonavailability` WHERE  `id`='$qid'  ")); 
	 
	 
	$Query[]="Size between : ".$ds2['sizefrom']."-".$ds2['sizeto'];
	$Query[]="Floor between : ".$ds2['floorfrom']."-".$ds2['floorto'];
	$Query[]="Budget between : ".$ds2['budgetfrom']."-".$ds2['budgetto'];
	
	if($ds2['tower']==''){
		$Query[]="Any Tower";	
	}else{
		$Query[]="Tower: ".$tower;	
	}
	
	if($ds2['plan']==''){
		$Query[]="Any Plan";	
	}else{
		$Query[]="Plan ".$plan;	
	}
	$pid=$ds2['projectid'];
	$client=$ds2['client'];
	$qp=base64_encode($qid."-".$pid);
	
	// $approvalLink=$baseurl."/bqlogin.php?qid=".$qp."";
	  
	 $message="Query for : (".getProjectByTypeANdId($conn,$pid,2).") , -  ".implode(", ",$Query).", for Client : ". getLeadNameById($conn,$client)."";
	  
	
	
	return $message;
}

function getNonExcQueryDetailsByid($conn,$qid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `checknonavailability` WHERE  `id`='$qid'  ")); 
	 return $ds2;

}

function getProjectIdBYCsid($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `costsheet` WHERE  `id`='$cid'  ")); 
	 $qid= $ds2['qid']; 
	 $nonExAr=getNonExcQueryDetailsByid($conn,$qid);
	 $pid=$nonExAr['projectid'];
	 return $pid;
	 
}


function getNonHoldingCommission($conn,$arr,$hid,$cdisc){
	
//die;
$bonusFlag=0;
foreach($arr as $associds){
	
	
$i++;

if($i==1){

	$commPercentandindex=getCommissionPercentByAssociId($conn,$associds);
	$commPercent=$commPercentandindex[1];
	$index=$commPercentandindex[0];
	$assoc[$associds]=$commPercent."##1";
	
}else{
	 $newIndex=getAssociateDesignationIndexById($conn,$associds);
	
	if($newIndex < $index){
		 $commPercentandindex=getCommissionPercentByAssociId($conn,$associds);
		 $necommPercent=$commPercentandindex[1];
		 $commPercent=$commPercentandindex[1]-$commPercent;
		 $index=$commPercentandindex[0];
		 $assoc[$associds]=$commPercent."##1";
		 $commPercent=$necommPercent;	
		
	}else{
		
		$check=qualifyforbonus($conn,$arr,$associds,$bonusFlag);
		if($bonusFlag==0){
			if($check){
			$assoc[$associds]='5##2';	
			$bonusFlag=1;	
			}
		}
		
	}
	
	
	
}


}
	
//array_pop($assoc);
foreach($assoc as $ass=>$commpercent){
	$assid=$ass;
	$mlmArr=getMlmTreeDetailById($conn,$assid);
	$code=$mlmArr['code'];
	$desg_name=$mlmArr['desigination_id'];
	$desgArr=getDesignationDetailsByDesgName($conn,$desg_name);
	$desg_id=$desgArr['desigination_id'];
	$expComm=explode("##",$commpercent);
	$comm=$expComm[0];
	$type=$expComm[1];
	//echo "<br/>";
	mysqli_query($conn, "INSERT INTO `commission_on_nonholding` (`id`, `hold_id`, `assoc_tree_id`, `assoc_code`, `designation_id`, `designation_name`, `commpercent`,`type`) VALUES (NULL, '$hid', '$assid', '$code', '$desg_id', '$desg_name', '$comm','$type');");
	
}

//die;	
	
}	



function updateNonExcSale($conn,$arr,$saleid,$saledate){
	
	$wt=getWeightageBySaleId($conn,$saleid);
	
foreach($arr as $ets)
{
		$et=getAssociateIdByTreeId($conn,$ets);
	//	$asscidxxx=getAssociateIdByTreeId($conn,$ets);
		$cd=associatecodefromid($conn,$et);
	 
	 
	 $expnewsaledate=explode("-",$saledate);
	 $saleyear=$expnewsaledate[0]."-".$expnewsaledate[1];
	 
	 $ret ="SELECT * FROM total_sales WHERE `associate_detail_id` =$et";
	 $ret1=mysqli_query($conn,$ret);
if ($ret && mysqli_num_rows($ret1) > 0)

    {
		
	   	$update = "UPDATE total_sales SET total_sales = total_sales + ".$wt."  WHERE associate_detail_id=$et";	 
          
		$update1=mysqli_query($conn,$update);
		
		
		
    }
else
    {
		
        $sq="INSERT INTO `total_sales`(`associate_detail_id`,`associate_code`, `total_sales`, `individual_sale_nonex`) VALUES ($et,'$cd','$wt',0)";
        $re=mysqli_query($conn,$sq);
 
    }

 		$sq11="INSERT INTO `totalsaleeffect` (`id`, `sale_month`, `asscode`, `sale`,`saletype`) VALUES (NULL, '$saleyear', '$cd', '$saleid','2');";
        $re=mysqli_query($conn,$sq11);


	 $updates =mysqli_query($conn,"UPDATE total_sales SET individual_sale_nonex = individual_sale_nonex +1 WHERE associate_detail_id='$et'");	


}


	unset($arr);	

}

function MyListCount($conn,$aid){
	
	
	$childs=array();
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(*) as count FROM `leads` where `postedby` ='$aid'")); 

	
	return $ds2['count'];	
	
	
}

function checktotalsaleexists($conn,$code){
	
			$ds=mysqli_query($conn,"SELECT count(*) as count FROM `total_sales` where `associate_code`='$code'"); 
			$fetch=mysqli_fetch_assoc($ds);
			$mandatory=$fetch['count'];
			
			if($mandatory>0){
				return true;	
			}else{
				return false;	
			}	
}

function getCoshsheetDetailsById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `costsheet` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}

function getNonExcDocumentDetailsById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `nonexcdetail` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}
function getExcDocumentDetailsById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `excdetail` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}
function getYouTubeVideo($url){

parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
return $my_array_of_vars['v'];    
  // Output: C4kxS1ksqtw
	
}


function builderforgotpwd($baseurl,$name,$password){
	
$msg='<head>
	<title>New mail</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:700px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
                                	<a  href="" target="_blank" title="life apple"  style="text-decoration: none; padding: 16px 20px; border-radius: 0px; margin: 20px 20px 0px; background: #FFF none repeat scroll 0px 0px; display: block;"><img src="'.$baseurl.'/img/logo.png" alt="Acreninches" height=""  class="logoImage" style="width:220px; border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="left" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:left;">
                                               
												<p>Greeting <b>'.$name.',</b></p>
<p>Your Password  is '.$password.'</p>
<p>Best Regards</p>
<b>TEAM ANI</b></p>
												 
                                            </td>
                                        </tr>
                                       
                                       
                                    </table>
                                </td>
                            </tr>
                            

                           
                                        
										
                                    </table>
                                </td>
                            </tr>

                            
                             <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;"> <br>
                                          This e-mail and any files transmitted with it may contain confidential and privileged information are for the sole use of the intended recipient(s). If you are not the intended recipient please appraise the sender by reply e-mail and destroy all copies and the original message. The information contained in this e-mail including the attachment/of the content is being provided to you for the specific purpose of evaluation. No legal consequences can be derived of this e-mail. Any unauthorized disclosure, dissemination, forwarding, printing or copying of this email or any action taken on this e-mail is strictly prohibited and may be unlawful. The recipient acknowledges that Acres N Inches or its subsidiaries and associated companies, are unable to exercise control or ensure or guarantee the integrity of the contents of the information contained in e-mail transmissions and further acknowledges that any views expressed in this message are those of the individual senders and no binding nature of the message shall be implied or assumed unless the sender does so expressly with due authority of Acres N Inches.
                                                <br />
                                               
                                            </td>
                                        </tr>
                            <tr>
                                            <td style="padding-top:30px" valign="top" align="center">
                                                <a style="color:#0073e6;text-decoration:none" href="http://acresninches.com/" target="_blank" >acresninches.com</a>
                                            </td>
                                        </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';
						return $msg;	
}


function getPlc($conn,$fid){
	//echo "SELECT * FROM `crm_inv_project_floor` where  `id`='$fid' and `status`='hold' and `holdedbycode`='$asscode' and `holdedbyid`='$assid'  ";die;
	$ds=mysqli_query($conn,"SELECT `plc_id` ,`short` FROM `crm_inv_project_plc` p inner join crm_inv_project_plc_master m on m.project_plc_master_id=p.plc_id where p.`floor_id`='$fid' and p.`plc_rate`!='0'"); 
	$ds1=mysqli_num_rows($ds);
	if($ds1>0){
		
		
		
	
	while($fetch34=mysqli_fetch_assoc($ds)){
		$rid[]=$fetch34['short'];
	
		
		
		
	}
		
		
	return implode(",",$rid);	
		
		
		
		
		
	}else{
		return "";
	}
}

function getNoOfTimesHeld($conn,$assoc,$floorid){
		 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  count(*) as count FROM `holdedinventory` WHERE  `associatecode`='$assoc' and `floor_id`='$floorid'  ")); 
	 return $ds2['count'];
	
}

function getProjectLoayoutByTypeAndId($conn,$type,$pid){
if($type==1){
	return "noimage.jpg";	
}else{
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  content ,contenttype FROM `nonexcdetail` WHERE  `projid`='$pid' and `whichcontent`='4'  ")); 
	 return $ds2['content']."##".$ds2['contenttype'];
}
	
	
}
function createThumbNailold($oldname,$width,$height,$baseurl){

if($oldname==''){



$oldname='noimage.jpg';



}



if(!file_exists($baseurl."/docs/".$oldname)){


  $oldname='noimage.jpg';



 }else{

 }

 

 

 



$imgName=$width."_".$height."_".$oldname;



 







$newname = $baseurl."/thumb/". $imgName;





  if(!file_exists($newname)){



$thumbw = $width;



$thumbh = $height;



$nh = $thumbh;



$nw = $thumbw;



$size = getImageSize($baseurl."/docs/".$oldname);



$w = $size[0];



$h = $size[1];



$img_type=$size[2];



$ratio = $h / $w;



$nratio = $nh / $nw;







 if($ratio > $nratio)



 {



   $x = intval($w * $nh / $h);



   if ($x < $nw)



   {



     $nh = intval($h * $nw / $w);



   }



   else



   {



     $nw = $x;



   }



 }



 else



 {



   $x = intval($h * $nw / $w);



   if ($x < $nh)



   {



     $nw = intval($w * $nh / $h);



   }



   else



   {



     $nh = $x;



   }



 }  











//die($img_type);



switch($img_type) {



         case '1':



         $resimage = imagecreatefromgif($baseurl."/docs/".$oldname);



         break;



         case '2':



         $resimage = imagecreatefromjpeg($baseurl."/docs/".$oldname);



         break;



         case '3':



         $resimage = imagecreatefrompng($baseurl."/docs/".$oldname);



         break;



     }







 //$resimage = imagecreatefromjpeg($oldname);



 $newimage = imagecreatetruecolor($nw, $nh);  



 // use alternate function if not installed



 imageCopyResampled($newimage, $resimage,0,0,0,0,$nw, $nh, $w, $h);



 



 // Making the final cropped thumbnail



 



 $viewimage = imagecreatetruecolor($thumbw, $thumbh);



 imagecopy($viewimage, $newimage, 0, 0, 0, 0, $nw, $nh);



 



 // saving



 imagejpeg($viewimage, $newname, 85);







return $imgName;

  }else{

return $imgName;  

}

}


function getProjectAddressByTypeAndId($conn,$type,$pid){
if($type==1){
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  address   FROM `crm_inv_project` WHERE  `project_id`='$pid'   ")); 
	 return $ds2['address'];
	
}else{
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  address  FROM `nonexsubprojects` WHERE  `id`='$pid'  ")); 
	 return $ds2['address'];
}
	
	
}


function getProjectLocationByTypeAndId($conn,$type,$pid){
if($type==1){
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  map   FROM `crm_inv_project` WHERE  `project_id`='$pid'   ")); 
	 $map=str_replace("width=600","width=200",$ds2['map']);
	 $map=str_replace("width=450","height=250",$map);
	
}else{
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  map  FROM `nonexsubprojects` WHERE  `id`='$pid'  ")); 
	  $map=str_replace("width=600","width=200",$ds2['map']);
	 $map=str_replace("width=450","height=250",$map);
}
	
	return $map;
}
function getProjectDetailsByTypeAndId($conn,$type,$pid){
if($type==1){
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  *   FROM `crm_inv_project` WHERE  `project_id`='$pid'   ")); 
}else{
	$ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  *  FROM `nonexsubprojects` WHERE  `id`='$pid'  ")); 
}
	 return $ds2;
}


function inventoryviewed($conn,$fid,$aid){
	$pdate=date("Y-m-d");
	$ptime=date("h:i a");
mysqli_query($conn,"INSERT INTO `inventoryviewed` (`id`, `fid`, `assoc_id`, `pdate`, `ptime`) VALUES (NULL, '$fid', '$aid', '$pdate', '$ptime'); ")	;
	
}

function projectviewed($conn,$type,$pid){
	$pdate=date("Y-m-d");
	$ptime=date("h:i a");
	
	$assoc=mysqli_fetch_assoc(mysqli_query($conn,"select count(*) as count from `microinterested` where `type`='$type' and `pid`='$pid' "));
	return $assoc['count'];
	
}
/*function getHoldedCustomerDetailsById($conn,$cid){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_customer_detail` where  `customer_detail_id`='$cid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;	
}
*/
function getHoldedInventoryStatusById($conn,$cid){
	$ds=mysqli_query($conn,"SELECT `holdstatus` FROM `holdedinventory` where  `id`='$cid'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['holdstatus'];	
}
function getSaleDateFromHid($conn,$id){
	$ds=mysqli_query($conn,"SELECT `date-of-sale` as date FROM `crm_sales_details_new` where `hid`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	
	return $ds1['date'];
 
} 

function myworksheets($conn,$aid){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `id` FROM `leads` where `postedby` ='$aid'"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['id'];
				
		}
	return $childs;	
	
	
}

function myTeamworksheets($conn,$associds){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT `id` FROM `leads` where `postedby` in (".implode(',',$associds).")"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['id'];
				
		}
	return $childs;	
	
	
}


function myclientlist($conn,$aid){
	$childs=array();
	$code=associatecodefromid($conn,$aid);
	$ds2=mysqli_query($conn,"SELECT `id` FROM `clientsnew` where `associtecode` ='$code'"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['id'];
		}
	return $childs;	
}

function myTeamclientlist($conn,$associds){
	$childs=array();
	//$code=associatecodefromid($conn,$aid);
	$ds2=mysqli_query($conn,"SELECT `id` FROM `clientsnew` where `aid` IN (".implode(',',$associds).")"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['id'];
		}
	return $childs;	
}

function myclientMobilelist($conn,$aid){
	
	
	$childs=array();
	$code=associatecodefromid($conn,$aid);
	//echo "SELECT `mobile` FROM `clientsnew` where `associatecode` ='$code'";
	$ds2=mysqli_query($conn,"SELECT `mobile` FROM `clientsnew` where `associtecode` ='$code'"); 

	while($fetch=mysqli_fetch_array($ds2)){
		
		      $rmobile=preg_replace("/[^0-9]+/", "", $fetch['mobile']);
		      $childs[]="91".$rmobile;
		
		
		
		     // $childs[]="'".'91'.$fetch['mobile']."'";
				
		}
	return $childs;	
	
	
}


function myTeamclientMobilelist($conn,$assocArr){
	
	
	$childs=array();
	
	if(count($assocArr)>0){
		$impIds=implode(",",$assocArr);	
	}else{
		$impIds=0;
	}
	
	//$code=associatecodefromid($conn,$aid);
	//echo "SELECT `mobile` FROM `clientsnew` where `associatecode` ='$code'";
	$ds2=mysqli_query($conn,"SELECT `mobile` FROM `clientsnew` where `aid` IN ($impIds)"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]='91'.$fetch['mobile'];
				
		}
	return $childs;	
	
	
}


function myclientlistcount($conn,$aid){
	
	
	$childs=array();
	$code=associatecodefromid($conn,$aid);
	$ds2=mysqli_query($conn,"SELECT sc.`smsid` as smsid FROM `clientsnew` cn inner join `smsclicks` sc on cn.id=sc.userid where `cn`.aid='$aid'  and sc.type=1"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['smsid'];
				
		}
	return $childs;	
	
	
}

function myworksheetssmscount($conn,$aid){
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT sc.`smsid` as smsid FROM `leads` ld inner join `smsclicks` sc on ld.id=sc.userid where `ld`.postedby='$aid'  and sc.type=2"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['smsid'];
				
		}
	return $childs;	
	
	
}

function myteamworksheetssmscount($conn,$impids){
	
	
	$childs=array();
	
	//echo "SELECT sc.`smsid` as smsid FROM `leads` ld inner join `smsclicks` sc on ld.id=sc.userid where `ld`.postedby in ($impids)  and sc.type=2";
	$ds2=mysqli_query($conn,"SELECT sc.`smsid` as smsid FROM `leads` ld inner join `smsclicks` sc on ld.id=sc.userid where `ld`.id in ($impids)  and sc.type=2"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['smsid'];
				
		}
	return $childs;	
	
	
}


function myteamworksheetssmsclickreport($conn,$impids,$smsid){
	
	
	$childs=array();
	
	//echo "SELECT sc.`smsid` as smsid FROM `leads` ld inner join `smsclicks` sc on ld.id=sc.userid where `ld`.postedby in ($impids)  and sc.type=2";
	$ds2=mysqli_query($conn,"SELECT ld.`name` as name FROM `leads` ld inner join `smsclicks` sc on ld.id=sc.userid where `ld`.id in ($impids)  and sc.type=2 and sc.smsid='$smsid'"); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['name'];
				
		}
	return $childs;	
	
	
}


function myworksheetsdeliverycount($conn,$aid){
	
	
	$childs=array();
	$ds2=mysqli_query($conn,"SELECT sc.`smsid` as smsid FROM `leads` ld inner join `smsdelivered` sc on ld.'91'.contact_no=sc.mobile where `ld`.postedby='$aid' "); 

	while($fetch=mysqli_fetch_array($ds2)){
		      $childs[]=$fetch['smsid'];
				
		}
	return $childs;	
	
	
}

function getLeadCountBeforeDate($conn,$date,$associd){
   $curDate=date("Y-m-d");
  
	$ds=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(*) as count FROM `leads` where   `postedby`='$associd' and `pdate` <= '$date'  "));
	return $ds['count'];
		
   }

function getSMSPostedDate($conn,$smsid){
	
	$ds=mysqli_query($conn,"SELECT `pdate` as date from `smstoshoot` where `id`='$smsid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['date'];
}


function getSMSDetailById($conn,$smsid){
	
	$ds=mysqli_query($conn,"SELECT `sms`  from `smstoshoot` where `id`='$smsid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['sms'];
}

function getLeadNameFromMobile($conn,$id,$mobile){
	//echo "SELECT `name` FROM `leads` where `postedby`='$id' and `contact_no`='$mobile'";
	$mobile=substr($mobile,2);
	$ds=mysqli_query($conn,"SELECT `name` FROM `leads` where `postedby`='$id' and `contact_no`='$mobile'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
 
} 

function getTeamLeadNameFromMobile($conn,$mobile){
	//echo "SELECT `name` FROM `leads` where `postedby`='$id' and `contact_no`='$mobile'";
	$mobile=substr($mobile,2);
	$ds=mysqli_query($conn,"SELECT `name` FROM `leads` where 1 and `contact_no`='$mobile'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
 
}
function getNonExcSlugById($conn,$id){
	
	$ds=mysqli_query($conn,"SELECT `slug` as name from `nonexprojects` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getNonExcProjectNameById($conn,$id){
	
	$ds=mysqli_query($conn,"SELECT `name` as name from `nonexprojects` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getNonExcProjectDetailById($conn,$id){
	
	$ds=mysqli_query($conn,"SELECT *  from `nonexprojects` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function updatelogs($conn,$pageid,$buid,$pid,$btype,$ptype=2){
	$pdate=date("Y-m-d");
	$ptime=date("h:i a");
	$ds=mysqli_query($conn,"INSERT INTO `builderlogs` (`id`, `pageid`, `updatedby`, `projectid`, `pdate`, `ptime`, `status`, `updatetype`,`projecttype`) VALUES (NULL, '$pageid', '$buid', '$pid', '$pdate', '$ptime', '1', '$btype','$ptype') "); 
	
	
	
			if($btype==1){
				$updatedtext="Builder";	
			}else{
				$updatedtext="Operations (ANI)";	
			}
		    $project=getProjectByTypeANdId($conn,$buid,$ptype);
			$text=$project." - ".getPageNameById($conn,$pageid)." has been updated by $updatedtext";
			postdata('9953964123',$text);
			postdata('8860813845',$text);
}

function getPageNameById($conn,$id){
	
	$ds=mysqli_query($conn,"SELECT `page` as name from `builderpages` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}

function getgstratesdetailbyid($conn,$id){
	
	/*$ds=mysqli_query($conn,"SELECT *  from `gstrates` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;*/
}

function getBuilderRedirectPage($conn,$pid){
	$ds=mysqli_query($conn,"SELECT `redirect`  from `builderpages` where `id`='$pid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['redirect'];
}




function sendBuilderAppMsg($conn,$baseurl,$pid,$pageid){
 
	
	  $pageName=getPageNameById($conn,$pageid);
	  $qid=base64_encode($pageid."-".$pid);
	  $link= $baseurl."/ablog.php?qid=".$qid."";
	  $sms= $pageName." has been updated by Operations Team(ANI). Click ".$link."  to view details."; 
  return $sms;
	 // postdata($mobile,$sms); // this is sms to customer 
}

function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise ;
}


function getUnitDescriptionNameById($conn,$pid){
	$ds=mysqli_query($conn,"SELECT `name`  from `unitdescmaster` where `id`='$pid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];

}


function getPropertyTypeNameById($conn,$pid){
	$ds=mysqli_query($conn,"SELECT `name`  from `propertytype` where `id`='$pid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getLeadStatusById($conn,$type){
   $curDate=date("Y-m-d");
   if($type==1){
		return "Followup";
	}
	if($type==2){
		return "Finalized";
	}
	if($type==3){
		return "Not Interested";
	}
	
	if($type==4){
		return "Meeting";
	}
	if($type==5){
		return "Site Visit";
	}
	if($type==6){
		return "Post Site Visit Followup";
	}
	if($type==7){
		return "Refer";
	}
	
	
 
} 

function getWeightageByProjectId($conn,$pid){
	$ds=mysqli_query($conn,"SELECT `weightage`  from `nonexsubprojects` where `id`='$pid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return  $ds1['weightage'];
}


function getWeightageBySaleId($conn,$saleid){
	$ds=mysqli_query($conn,"SELECT `projectid`  from `costsheet` where `id`='$saleid' "); 
	$ds1=mysqli_fetch_assoc($ds);
	$pid= $ds1['projectid'];
	$wt=getWeightageByProjectId($conn,$pid);
	return $wt;
	
}

function getProjectCLickedBySMSIdANdType($conn,$userid,$smsid,$type){
	
	$childs=array();
	$project=array();
//echo "SELECT  `pid`,`ptype` from microinterested where `smsid`='$smsid' ,`type`='$type',`userid`='$userid'";
	$ds2=mysqli_query($conn,"SELECT  `pid`,`ptype` from microinterested where `smsid`='$smsid' and `type`='$type' and `userid`='$userid'"); 

	while($fetch=mysqli_fetch_array($ds2)){
		//echo $fetch['pid']."#".$fetch['ptype'];
		     if($fetch['pid']!=''){
		      $childs[]=$fetch['pid']."#".$fetch['ptype'];
			 }
				
		}
	if(count($childs)>0){
		foreach($childs as $child){
			$expArr=explode("#",$child);
			$pid=$expArr[0];
			$type=$expArr[1];	
			$project[]=getProjectByTypeANdId($conn,$pid,$type);
		}
		$projectNew=array_unique($project);
		
		return "<b style='color:red'>".implode(", ",$projectNew)."<b>";
	}else{
	 return "- - -";	
	}
		
		
}
function getClientsDetailById($conn,$id){
	$ds=mysqli_query($conn,"SELECT *  from `clientsnew` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return  $ds1;
}

function getClientsNameANdMobileById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `name`,`mobile`,`aid` as aid  from `clientsnew` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return  $ds1;
}


function getClientsAssocaiteById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `aid`  from `clientsnew` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return  $ds1['aid'];
}



function getClientsNameById($conn,$id){
	$ds=mysqli_query($conn,"SELECT `name`  from `clientsnew` where `id`='$id' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return  $ds1['name'];
}

function getClientNameBYIdANdType($conn,$uid,$type){
if($type==1){
	$name=getClientsNameANdMobileById($conn,$uid);	
}
if($type==2){
	$name=getLeadNameANdMobileById($conn,$uid);	
}

if($type==3){
	$name=associatenameandmobilefromid($conn,$uid);	
}
	return $name;
}


function getAssociateIdBYIdANdType($conn,$uid,$type){
if($type==1){
	$name=getClientsAssocaiteById($conn,$uid);	
}
if($type==2){
	$name=getLeadAssociateById($conn,$uid);	
}

if($type==3){
	$name=$uid;	
}
	return $name;
}



function getFeedBackDetailById($conn,$loc,$bud,$unit){
	if($loc!=''){
		$exploc=explode(",",$loc);	
	}
	
	if($bud!=''){
		$expbud=explode(",",$bud);	
	}
	
	if($unit!=''){
		$expunit=explode(",",$unit);	
		
	}
	
}

function getClientAssocWrkType($type){
	if($type==1){
		return "Client";	
	}
	if($type==2){
		return "Worksheet";	
	}
	if($type==3){
		return "Associate";	
	}
	
	
}

function getProjectViewedByIdANdType($conn,$userid,$type){
	
	$childs=array();
	$project=array();
//echo "SELECT  `pid`,`ptype` from microinterested where `smsid`='$smsid' ,`type`='$type',`userid`='$userid'";
	$ds2=mysqli_query($conn,"SELECT  `pid`,`ptype` from microinterested where  `type`='$type' and `userid`='$userid'"); 

	while($fetch=mysqli_fetch_array($ds2)){
		//echo $fetch['pid']."#".$fetch['ptype'];
		     if($fetch['pid']!=''){
		      $childs[]=$fetch['pid']."#".$fetch['ptype'];
			 }
				
		}
	if(count($childs)>0){
		foreach($childs as $child){
			$expArr=explode("#",$child);
			$pid=$expArr[0];
			$type=$expArr[1];	
			$project[]=getProjectByTypeANdId($conn,$pid,$type);
		}
		$projectNew=array_unique($project);
		
		return "<b style='color:green'>".implode(", ",$projectNew)."<b>";
	}else{
	 return "- - -";	
	}
}


function getUserPreferenceByIdANdType($conn,$userid,$type){
	
	$childs=array();
	$project=array();
//echo "SELECT  `pid`,`ptype` from microinterested where `smsid`='$smsid' ,`type`='$type',`userid`='$userid'";
	$ds2=mysqli_query($conn,"SELECT  `ploc`,`pbud`,`punit` from anifeedback where  `type`='$type' and `userid`='$userid' order by `id` desc limit 0,1 "); 

	while($fetch=mysqli_fetch_array($ds2)){
		//echo $fetch['pid']."#".$fetch['ptype'];
		     
				$plocs=$fetch['ploc'];
				$pbud=$fetch['pbud'];
				$punit=$fetch['punit'];
			
		}
		
		
	return $plocs."#".$pbud."#".$punit;
}

function getBudgetMaster($conn){
	$ds2=mysqli_query($conn,"SELECT  * from `budgetmaster` where `status`='1'"); 

	while($fetch=mysqli_fetch_array($ds2)){
	  		$id=$fetch['id'];
			$name=$fetch['name'];
			$budget[$id]=$name;
		     
		}
		
		return $budget;
}
function getUnitMaster($conn){
	$ds2=mysqli_query($conn,"SELECT  * from `unitdescmaster` where `status`='1'"); 

	while($fetch=mysqli_fetch_array($ds2)){
	  		$id=$fetch['id'];
			$name=$fetch['name'];
			$budget[$id]=$name;
		     
		}
		
		return $budget;
}
function getLocationtMaster($conn){
	$ds2=mysqli_query($conn,"SELECT  * from `locationmaster` where `status`='1'"); 

	while($fetch=mysqli_fetch_array($ds2)){
	  		$id=$fetch['id'];
			$name=$fetch['name'];
			$budget[$id]=$name;
		     
		}
		
		return $budget;
}

function getExclusiveandnonexclusiveprojectlist($conn){
	$projects=array();
	$ds2=mysqli_query($conn,"SELECT  * from `nonexsubprojects` where `status`='1'"); 

	while($fetch=mysqli_fetch_array($ds2)){
	  		
			$projects[]='"'.$fetch['name'].'"';
			
		     
		}
		
		$ds2=mysqli_query($conn,"SELECT  * from `crm_inv_project` where `status`='1'"); 

	while($fetch=mysqli_fetch_array($ds2)){
	  		
			$projects[]='"'.$fetch['project_name'].'"';
			
		     
		}
		
		return implode(",",$projects);
}
function getExclusiveandnonexclusiveprojectlistAr($conn){
	$projects=array();
	
		
		$ds2=mysqli_query($conn,"SELECT  * from `crm_inv_project` where `status`='1' order by  `project_name` asc"); 

	while($fetch=mysqli_fetch_array($ds2)){
	  		
			$projects[]=$fetch['project_name'];
			
		     
		}
		
		$ds21=mysqli_query($conn,"SELECT  * from `nonexsubprojects` where `status`='1' order by  `name` asc"); 

	while($fetch=mysqli_fetch_array($ds21)){
	  		
			$projects[]=$fetch['name'];
			
		     
		}
		
		return $projects;
}

function hoursRange( $lower = 0, $upper = 86400, $step = 1800, $format = '' ) {
    $times = array();

    if ( empty( $format ) ) {
        $format = 'g:i a';
    }

    foreach ( range( $lower, $upper, $step ) as $increment ) {
        $increment = gmdate( 'H:i', $increment );

        list( $hour, $minutes ) = explode( ':', $increment );

        $date = new DateTime( $hour . ':' . $minutes );

        $times[(string) $increment] = $date->format( $format );
    }

    return $times;
}

function getCancelledSaleStatus($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	// $ds2=mysqli_query($conn,"SELECT * FROM `holdedinventory` where  `holdstatus`='1' and `approval`='1' and `oprapproval`='1'  "); 
	 
	 

	 $ds2=mysqli_query($conn,"SELECT `hid` FROM `crm_sales_details_new` where  `salesstatus`='0'  and `date-of-sale` > '2018-01-01' and `hid`!='0'  order by `sales_details_id` desc   "); 

	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['id'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}


function updateSaleonconversation($conn,$saleid){
		  $result=mysqli_query($conn,"SELECT * FROM `crm_sales_details_new` WHERE  `sales_details_id` = '$saleid' ORDER BY `date-of-sale` ");
		while ($row = mysqli_fetch_assoc($result))
			 { 
				$ids=associateidfromcode($conn,$row['associatecode']);
				$saleid=$row['sales_details_id'];
				$date0fsale=explode("-",$row['date-of-sale']);
				$month=$date0fsale[1]."-".$date0fsale[0];
				$arr = array();  
				$parent = 1;
				$i=0;
			
		while($parent != 0 || $parent != '')
			{
				if($i == 0)
				{
				
				$tid = associateidfromcode($conn,$row['associatecode']);
				 $id=getTreeIdByAssociateId($conn,$tid);
				
				$arr[0] =$id;
				$i++;
				}
				else
				{ 
				$id = $parent;
				$i++;
				}
				
				
			
			
			 $aresult ="SELECT id,parent,desigination_id FROM `mlm_tree` where id=$id" ;
			
			$result2=mysqli_query($conn,$aresult);
			$row1=mysqli_fetch_array($result2);
				$parent = $row1['parent'];
				if($parent == 0)
				break;
				 $arr[$i] = $row1['parent'];
				 $desigination_id=$row1['desigination_id'];
				
			}
		foreach($arr as $ets)
		{
				$et=getAssociateIdByTreeId($conn,$ets);
			 $ret ="SELECT * FROM total_sales WHERE `associate_detail_id` =$et";
			$ret1=mysqli_query($conn,$ret);
		if ($ret && mysqli_num_rows($ret1) > 0)
		
			{ 
				
					$update = "UPDATE total_sales SET total_sales = total_sales +1 WHERE associate_detail_id=$et";	 
				
				$update1=mysqli_query($conn,$update);
				$asscidxxx=getAssociateIdByTreeId($conn,$ets);
				$cd=associatecodefromid($conn,$asscidxxx);
			}
		else
			{
				$asscid=getAssociateIdByTreeId($conn,$ets);
				$cd=associatecodefromid($conn,$asscid);
				 $sq="INSERT INTO `total_sales`(`associate_detail_id`,`associate_code`, `total_sales`, `individual_sale`) VALUES ($et,'$cd',1,0)";
				$re=mysqli_query($conn,$sq);
			}
				 $sq11="INSERT INTO `totalsaleeffect` (`id`, `sale_month`, `asscode`, `sale`) VALUES (NULL, '$month', '$cd', '$saleid');";
				$re=mysqli_query($conn,$sq11);
		}
		
	   $updates =mysqli_query($conn,"UPDATE total_sales SET individual_sale = individual_sale +1 WHERE associate_detail_id='$ids'");	
		
		unset($arr);	
		}
			
			
}

function getQualifiedArray($conn){
	$holded=array();
	$ds2=mysqli_query($conn,"SELECT `associate_detail_id` FROM `mlm_associate_detail` where  `qualified`='1'  and `qsmssent`='0'  "); 
	while($fetch=mysqli_fetch_array($ds2)){
			
				$holded[]=$fetch['associate_detail_id'];	
		}
	return 	$holded;
}

function mychildsCodesNew($conn,$aid){
	$childs=array();
	 $ds2=mysqli_query($conn,"SELECT p.`self` ,md.associate_code  FROM `parents` p inner join `mlm_tree` mt on mt.id=p.self inner join mlm_associate_detail md on md.associate_detail_id=mt.associate_detail_id where p.`parent`='$aid'   "); 

	while($fetch=mysqli_fetch_array($ds2)){
			$aids=$fetch['associate_code'];
			
			
				$childs[]=$aids;
		}
		return $childs;
}

function checkNonexExistsGstRates($conn,$pid){
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `gstrates` where `subprojectid`='$pid' and `subprojecttype`='2' "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return false;	
	}else{
		return true;	
	}
}

function getlocationmasterbyid($conn,$id){
	//echo "SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'";
	$ds=mysqli_query($conn,"SELECT `name` FROM `locationmaster` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
 
} 


function getpropertytypemasterbyid($conn,$id){
	//echo "SELECT * FROM `mlm_associate_detail` where `associate_code`='$code'";
	$ds=mysqli_query($conn,"SELECT `name` FROM `propertytype` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
 
} 

/*Start skypark function*/


function getSkyParkTowerNameById($conn,$id){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  `name` FROM `skyparktower` WHERE  `id`='$id'  ")); 
	 return $ds2['name']; 
}

function updateSkyParkInvStage($conn,$invid,$stage,$by,$clientname){
	$pdate=date("Y-m-d");
	$ptime=date("h:i a");
	
mysqli_query($conn,"INSERT INTO `skyparkinventorylog` (`id`, `inv_id`, `stage`, `pdate`, `ptime`, `postedby`,`clientname`) VALUES (NULL, '$invid', '$stage', '$pdate', '$ptime', '$by' , '$clientname');");	
}

function updateSkyParkInvStageall($conn,$invid,$stage,$by,$clientname,$clientpan,$chequeno,$chequeamt, $chequedate,$bankname){
	$pdate=date("Y-m-d");
	$ptime=date("h:i a");
	
mysqli_query($conn,"INSERT INTO `skyparkinventorylog` (`id`, `inv_id`, `stage`, `pdate`, `ptime`, `postedby`,`clientname`,`clientpan`, `chequeno`, `chequeamt`, `chequedate`, `bankname`) VALUES (NULL, '$invid', '$stage', '$pdate', '$ptime', '$by' , '$clientname' , '$clientpan' , '$chequeno' , '$chequeamt' , '$chequedate' , '$bankname');");	
}

function skypark_holddata($conn){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(`id`) as hold FROM `non_invskypark_new` WHERE `invstatus`=2")); 
	 return $ds2['hold'];
}

function skypark_solddata($conn){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(`id`) as sold FROM `non_invskypark_new` WHERE `invstatus`=3")); 
	 return $ds2['sold']; 
}

function getstatusskyparkinventory($conn,$id){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `non_invskypark_new` WHERE  `id`='$id'")); 
	 return $ds2; 
}

/*end skypark function*/


function getParkingChargeByPid($conn,$pid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  `price` FROM `projectcarparkings` WHERE  `pid`='$pid' and `active`='1' and `selectedparking`='1'  ")); 
	 return $ds2['price']; 
}
function getSkyParkUnitAddressById($conn,$id){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  `unitaddress` FROM `non_invskypark_new` WHERE  `id`='$id'  ")); 
	 return $ds2['unitaddress']; 
}

function updatecancellbooking($conn,$bid,$aid){
	$pdate=date("Y-m-d");
	$ptime=date("h:i a");
	
	 mysqli_query($conn,"INSERT INTO `updatecancelbooking` (`id`, `bid`, `cancelledby`, `cancelleddate`, `cancelledtime`) VALUES (NULL, '$bid', '$aid', '$pdate', '$ptime'); "); 
}

function getTypeDetail($type){
	if($type==1) return "Client";
	if($type==2) return "Worksheet";
	if($type==3) return "Associate";	
}


function getExclNonexclusiveprojectlist($conn,$val){
	$projects=array();

	if($val==2){
			$ds2=mysqli_query($conn,"SELECT  * from `nonexsubprojects` where `status`='1'"); 
	while($fetch=mysqli_fetch_array($ds2)){
	  		$id=$fetch['id'];
			$projects[$id]=$fetch['name'];
		}
	}
	
	if($val==1){
		$ds2=mysqli_query($conn,"SELECT  * from `crm_inv_project` where `status`='1'"); 

	while($fetch=mysqli_fetch_array($ds2)){
	  		$id=$fetch['project_id'];
			$projects[$id]=$fetch['project_name'];
			
		     
		}
	}
		
		return $projects;
}


function getNonExPaymentPlanMaster($conn){
	$projects=array();

	
			$ds2=mysqli_query($conn,"SELECT  * from `non_paymentplan_master` where `status`='1' "); 
	while($fetch=mysqli_fetch_array($ds2)){
	  		$id=$fetch['id'];
			$projects[$id]=$fetch['name'];
		}
	
	
	
		
		return $projects;
}

function getBBARoasterDetailById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `bbaroaster` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getNonPaymentPlanRoasterDetailById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `nonpaymentplanroaster` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function getNonexPaymentPlanNameBYId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `non_paymentplan_master` where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getNonextowermasterbyId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `nonex_tower_master` WHERE `id`=$id And `status`=1 And `view`=1"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getremarkconstruction_towerbyId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `construction_tower` WHERE `id`=$id And `status`=1 And `view`=1"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1["remark"];
}

function getSaleIdByHid($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	
//	echo "SELECT `id` FROM `crm_sales_details_new` WHERE `hid`='$id' and `salestatus`='1' ";die;
	$ds=mysqli_query($conn,"SELECT `sales_details_id` FROM `crm_sales_details_new` WHERE `hid`='$id' and `salesstatus`='1' "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1["sales_details_id"];
}

function getBuilderReceiptDetailsById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `builderreceipts` WHERE `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getConstructionRemarkById($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT `remark` FROM `construction_tower` WHERE `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['remark'];
}

/*check payment plan*/

function check_paymentplan($conn,$name){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `non_paymentplan_master` WHERE `name`='".strtoupper($name)."'"); 
	if(mysqli_num_rows($ds) > 0)
	{
		return false;
	}
	else
	{
		return true;
	}
}

/*after update*/
function checkupdate_paymentplan($conn,$id,$name){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `non_paymentplan_master` WHERE `name`='".strtoupper($name)."' AND `id`!=$id"); 
	if(mysqli_num_rows($ds) > 0)
	{
		return false;
	}
	else
	{
		return true;
	}
}


/*end check payment plan*/
/*get payment plan id using nonpaymentroster*/

function getpaymentplanidBYId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `nonpaymentplanroaster` WHERE `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

/*check add_struct*/

function check_addstruct_id($conn,$name,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `addplanstruct_nonexc` WHERE `attach_plan_struct`='".ucwords($name)."' AND `attach_roster_id`=$id"); 
	if(mysqli_num_rows($ds) > 0)
	{
		return false;
	}
	else
	{
		return true;
	}
}

/*after update*/
function checkupdate_addstruct_id($conn,$id,$name,$rid){
	//echo "SELECT * FROM `seminars` where `id`='$id'";

	 
	$ds=mysqli_query($conn,"SELECT * FROM `addplanstruct_nonexc` WHERE `attach_plan_struct`='".ucwords($name)."' AND `attach_roster_id`=$rid AND `id`!=$id"); 
	if(mysqli_num_rows($ds) > 0)
	{
		return false;
	}
	else
	{
		return true;
	}
}


/*end check add_stuct*/
function getaddstructdetailsId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `addplanstruct_nonexc` WHERE `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
/*get project name behalf of towerid*/

function getprojectnamebytowerId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT `nonexsubprojects`.`name` as projectName,`nonex_tower_master`.`name` as towerName FROM `nonexsubprojects` JOIN `nonex_tower_master` ON `nonex_tower_master`.`pid`=`nonexsubprojects`.`id` WHERE `nonex_tower_master`.`id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

/*get paymentplan structure*/

function getprojectplandefbyId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `addplanstruct_nonexc` WHERE `status`=1 AND `view`=1 AND `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

/*get imagedata contruction*/

/*get imagedata contruction*/

function getimageconstructionbyId($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `construction_tower_update` WHERE `status`=1 AND `view`=1 AND `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function getExclusiveProjectDetailById($conn,$id){
	$ds=mysqli_query($conn,"SELECT * FROM `crm_inv_project` where  `project_id`='$id'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

function checkNonexExistsGstRatesNew($conn,$pid,$type){
	$ds=mysqli_query($conn,"SELECT count(*) as count FROM `gstrates` where `subprojectid`='$pid' and `subprojecttype`='$type' "); 
	$ds1=mysqli_fetch_assoc($ds);
	if(  ($ds1['count']=='0') || ($ds1['count']=='NULL')){
		return false;	
	}else{
		return true;	
	}
}

function updatelogex($conn,$pageid,$buid,$pid,$btype){
	$pdate=date("Y-m-d");
	$ptime=date("h:i a");
	$ds=mysqli_query($conn,"INSERT INTO `builderlogs` (`id`, `pageid`, `updatedby`, `projectid`, `pdate`, `ptime`, `status`, `updatetype`,`projecttype`) VALUES (NULL, '$pageid', '$buid', '$pid', '$pdate', '$ptime', '1', '$btype','1') "); 
	
	
	
			if($btype==1){
				$updatedtext="Builder";	
			}else{
				$updatedtext="Operations (ANI)";	
			}
		    $project=getProjectByTypeANdId($conn,$buid,1);
			$text=$project." - ".getPageNameById($conn,$pageid)." has been updated by $updatedtext";
			postdata('9953964123',$text);
			postdata('8860813845',$text);
}

function getDescriptionByRoasterSlotModuleId($conn,$rid,$sid){

	$ds=mysqli_query($conn,"SELECT `description` FROM `roasterdetails` where  `roaster_id`='$rid' and `slot_id`='$sid' 
		 and `view`='1'  "); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['description'];
}

/*added date 2018-12-01*/

/*get sale details by id*/
function getsaledetailsByid($conn,$id)
{

	$ds=mysqli_query($conn,"SELECT * FROM `costsheet` where `salestatus` !='0' AND `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

/* creation date-20181130*/
/*get bank master details*/
function getBankmaster($conn)
{
	$ds1=array();
	$ds=mysqli_query($conn,"SELECT * FROM `bank_master` WHERE `status`=1 ORDER BY `name` ASC"); 
	if($ds->num_rows>0)
	{
		while ($row=$ds->fetch_assoc()) {
		    
		    $ds1[]=$row;
		}
	}
	return $ds1;
}
function getBankmasterById($conn,$id)
{

	$ds=mysqli_query($conn,"SELECT * FROM `bank_master` WHERE `status`=1 AND `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
/*get checque type*/

function getChequetypeMaster($conn)
{
	$ds1=array();
	$ds=mysqli_query($conn,"SELECT * FROM `chequetypes` WHERE  `status`=1 ORDER BY `name` ASC"); 
	if($ds->num_rows>0)
	{
		while ($row=$ds->fetch_assoc()) {
		    
		    $ds1[]=$row;
		}
	}
	return $ds1;
}
function getChequetypeMasterById($conn,$id)
{

	$ds=mysqli_query($conn,"SELECT * FROM `chequetypes` WHERE `status`=1 AND `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
/*get check status master*/
function getChequestatusMaster($conn)
{
	$ds1=array();
	$ds=mysqli_query($conn,"SELECT * FROM `chequestatusmaster` WHERE  `status`=1 ORDER BY `name` ASC");
	if($ds->num_rows>0)
	{
		while ($row=$ds->fetch_assoc()) {
		    
		    $ds1[]=$row;
		}
	}
	return $ds1;
}
function getChequestatusMasterId($conn,$id)
{

	$ds=mysqli_query($conn,"SELECT * FROM `chequestatusmaster` WHERE `status`=1 AND `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
/*log update non cheque details*/

function UpdateNonExchequeLogs($conn,$cossheetid,$chkstatusId,$submisiondate,$remark,$submittedby)
{
	$ds=mysqli_query($conn,"INSERT INTO `nonexchequelogs`(`costsheet_id`, `chequestatus_id`, `submission_date`, `remarks`, `submittedby`) VALUES ('$cossheetid','$chkstatusId','$submisiondate','$remark',$submittedby)"); 
	if($ds)
	{
		return true;
	}
	else
	{
		return false;
	}
	
}

function UpdateexchequeLogs($conn,$saleid,$chkstatusId,$submisiondate,$remark)
{
	$ds=mysqli_query($conn,"INSERT INTO `exchequelogs`(`id`, `sale_id`, `chequestatus_id`, `submission_date`, `remarks`, `submittedby`) VALUES ('$saleid','$chkstatusId','$submisiondate','$remark')"); 
	if($ds)
	{
		return true;
	}
	else
	{
		return false;
	}
	
}


function getChequeIdsByRceiptId($conn,$rid){
	$cheques=array();
	$ds2=mysqli_query($conn,"SELECT  * from `chequereceiptdetails` where `receipt_id`='$rid' and  `view`='1' "); 
	while($fetch=mysqli_fetch_array($ds2)){
		$id=$fetch['id'];
		$projects[]=$fetch['cheque_id'];
	}
	return $cheques;
}

function getReceiptDetailsById($conn,$id)
{

	$ds=mysqli_query($conn,"SELECT * FROM `chequereceipts` where  `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

/*get details addpartpayment by id*/

function getaddpartPaymentById($conn,$id)
{

	$ds=mysqli_query($conn,"SELECT * FROM `nonsales_booking_cheques` where  `status`=1 AND `view`=1 AND `id`=$id"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getIncludedChequesByRceiptId($conn,$rid){
	$cheques=array();
//	echo "SELECT  * from `chequereceiptdetails` where `receipt_id`='$rid' and  `view`='1' ";
	$ds2=mysqli_query($conn,"SELECT  * from `chequereceiptsdetails` where `receipt_id`='$rid' and  `view`='1' "); 
	while($fetch=mysqli_fetch_array($ds2)){
		$id=$fetch['id'];
		$cheques[]=getNonChequeNoById($conn,$fetch['cheque_id']);
	}
	
	//print_r($cheques);die;
	return implode(",",$cheques);
}
function getNonChequeDetailById($conn,$cid)
{

	$ds=mysqli_query($conn,"SELECT * FROM `nonsales_booking_cheques` where  `id`='$cid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getNonChequeNoById($conn,$cid)
{
//echo "SELECT `cheque_no` FROM `nonsales_booking_cheques` where  `id`='$cid'";die;
	$ds=mysqli_query($conn,"SELECT `cheque_no` FROM `nonsales_booking_cheques` where  `id`='$cid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['cheque_no'];
}

function getSlotsNameArray($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `slots`   "); 

	while($fetch=mysqli_fetch_array($ds2)){
				$id=$fetch['id'];
				$holded[$id]=$fetch['name'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}
function getSlotsTimingArray($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `slots`   "); 

	while($fetch=mysqli_fetch_array($ds2)){
				$id=$fetch['id'];
				$holded[$id]=$fetch['startsfrom'];	
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}




function getModuleNameCodeArr($conn){
	
	 $holded=array();
	// echo "SELECT * FROM `crm_inv_customer_detail` where  `team_head_code`='$assocode'";
	 $ds2=mysqli_query($conn,"SELECT * FROM `seminars`   "); 

	while($fetch=mysqli_fetch_array($ds2)){
				$id=$fetch['id'];
				$holded[$id]=$fetch['code']." - ".$fetch['title']." ( ".$fetch['duration']." mins ) ";
			
			
			
			
		}
		//return $error;		
	return 	$holded;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function getCategoriesDetailById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `categories` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}
function checkSlugInCategories($conn,$slug){
	$ds=mysqli_query($conn,"SELECT * FROM `categories` where `status`='1' and `view`='1' and `slug`='$slug'  "); 
	$numrows=mysqli_num_rows($ds);
	if($numrows>0){
		return true;	
	}else{
		return false;	
	}
	
	
}


function getCategoryIdBySlug($conn,$slug)
{
//echo "SELECT `cheque_no` FROM `nonsales_booking_cheques` where  `id`='$cid'";die;
	$ds=mysqli_query($conn,"SELECT `id` FROM `categories` where  `slug`='$slug'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['id'];
}
function getCategoryDetailsById($conn,$cid)
{
	//echo "SELECT `cheque_no` FROM `nonsales_booking_cheques` where  `id`='$cid'";die;
	$ds=mysqli_query($conn,"SELECT * FROM `categories` where  `id`='$cid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}
function getCategoryNameById($conn,$cid)
{
	//echo "SELECT `cheque_no` FROM `nonsales_booking_cheques` where  `id`='$cid'";die;
	$ds=mysqli_query($conn,"SELECT * FROM `categories` where  `id`='$cid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['name'];
}
function getBannerImage($conn,$image)
{
	if($image==''){
	$image="nobanner.jpg";
	}
	return $image;

}
function getLogoImage($conn,$image)
{
	if($image==''){
	$image="noimage.jpg";
	}
	return $image;

}

function createThumbNail($oldname, $width, $height, $baseurl) {
    if ($oldname == '') {
	$oldname = 'nophoto.jpg';
    }
    if (!file_exists($baseurl . "/photos/" . $oldname)) {
	$oldname = 'nophoto.jpg';
    }
    $imgName = $width . "_" . $height . "_" . $oldname;
    $newname = $baseurl . "/thumb/" . $imgName;
    if (!file_exists($newname)) {
	$thumbw = $width;
	$thumbh = $height;
	$nh = $thumbh;
	$nw = $thumbw;
	$size = getImageSize($baseurl . "/photos/" . $oldname);
	$w = $size[0];
	$h = $size[1];
	$img_type = $size[2];
	$ratio = $h / $w;
	$nratio = $nh / $nw;
	if ($ratio > $nratio) {
	    $x = intval($w * $nh / $h);
	    if ($x < $nw) {
		$nh = intval($h * $nw / $w);
	    } else {
		$nw = $x;
	    }
	} else {
	    $x = intval($h * $nw / $w);
	    if ($x < $nh) {
		$nw = intval($w * $nh / $h);
	    } else {
		$nh = $x;
	    }
	}
//die($img_type);
	switch ($img_type) {
	    case '1':
		$resimage = imagecreatefromgif($baseurl . "/photos/" . $oldname);
		break;
	    case '2':
		$resimage = imagecreatefromjpeg($baseurl . "/photos/" . $oldname);
		break;
	    case '3':
		$resimage = imagecreatefrompng($baseurl . "/photos/" . $oldname);
		break;
	}
	//$resimage = imagecreatefromjpeg($oldname);
	$newimage = imagecreatetruecolor($nw, $nh);
	// use alternate function if not installed
	imageCopyResampled($newimage, $resimage, 0, 0, 0, 0, $nw, $nh, $w, $h);
	// Making the final cropped thumbnail
	$viewimage = imagecreatetruecolor($thumbw, $thumbh);
	imagecopy($viewimage, $newimage, 0, 0, 0, 0, $nw, $nh);
	// saving
	imagejpeg($viewimage, $newname, 85);
	return $imgName;
    } else {
	return $imgName;
    }
}


function newpasswordlink($email,$id,$baseurl)
{

$unText=" <a style='color:#FFFFFF;text-decoration:none' href ='".$baseurl."/changepassword.php?id=".base64_encode($id)."'>Change Password</a> ";
$msg='<head>
	<title>Change password</title>
	</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">
            	<tr>
                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">
                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:600px;">
                        	<tr>
                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">
      <a href="" target="_blank" title="life apple" style="text-decoration:none;"><img src=http://78.46.117.226/education/img/logo.png alt="Bosh Education" height=""  class="logoImage" style="border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" style="padding-top:0px; padding-bottom:20px;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">
                                        <tr>
                                            <td align="center" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:center;">
                                                <h1 style="color:#606060 !important; font-family:Helvetica, Arial, sans-serif; font-size:40px; font-weight:bold; letter-spacing:-1px; line-height:115%; margin:0; padding:0; text-align:center;">Just one more step...</h1>
                                                <br />
                                               
                                                Click the big button below to change your password.
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="center" valign="middle" style="padding-right:40px; padding-bottom:40px; padding-left:40px;">
                                                <table border="0" cellpadding="0" cellspacing="0" class="emailButton" style="background-color:#6DC6DD; border-collapse:separate !important; border-radius:3px;">
                                                    <tr>
                                                        <td align="center" valign="middle" class="emailButtonContent" style="color:#FFFFFF; font-family:Helvetica, Arial, sans-serif; font-size:15px; font-weight:bold; line-height:100%; padding-top:18px; padding-right:15px; padding-bottom:15px; padding-left:15px;">'.$unText.'</td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                            	<td align="center" valign="top">
                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
                                    	<tr>
                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;">
                                           The information contained in and accompanying this communication may be confidential, subject to legal privilege, or otherwise protected from disclosure, and is intended solely for the use of the intended recipient(s). 
                                                <br />
                                               
                                            </td>
                                        </tr>
                                           
										 <tr>
                                        	<td align="center" valign="top" style="padding-top:30px;color:#f2f2f2;">'.date("h:m:i").'</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                        
                        </td>
                        </tr>
                        </table></body><html>';

return $msg;

	
	
}
function  resetpasslink($conn,$id,$baseurl,$pass){

//$memName=getUserNameById($conn,$id);








$msg='<head>



	<title>New mail</title>



	</head>



<body>



<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable" style="background-color:#F2F2F2;">



            	<tr>



                	<td align="center" valign="top" id="bodyCell" style="padding:20px 20px;">



                    	<table border="0" cellpadding="0" cellspacing="0" id="emailContainer" style="width:600px;">



                        	<tr>



                            	<td align="center" valign="top" bgcolor="#FFFFFF" style="padding-top:10px">



                                	<a href="" target="_blank" title="life apple" style="text-decoration:none;"><img src="'.$baseurl.'/images/logo.png" alt="LifePositive" height=""  class="logoImage" style="border:0; color:#6DC6DD !important; font-family:Helvetica, Arial, sans-serif; font-size:60px; font-weight:bold; height:auto !important; letter-spacing:-4px; line-height:100%; outline:none; text-align:center; text-decoration:none;" /></a>



                                </td>



                            </tr>



                            <tr>



                                <td align="center" valign="top" style="padding-top:0px; padding-bottom:20px;">



                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailBody" style="background-color:#FFFFFF; border-collapse:separate !important; border-radius:4px;">



                                        <tr>



                                            <td align="center" valign="top" class="bodyContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:15px; line-height:150%; padding-top:40px; padding-right:40px; padding-bottom:30px; padding-left:40px; text-align:center;">



                                                <h1 style="color:#606060 !important; font-family:Helvetica, Arial, sans-serif; font-size:40px; font-weight:bold; letter-spacing:-1px; line-height:115%; margin:0; padding:0; text-align:center;">New Password</h1>



                                                <br />



                                                <h3 style="color:#2b95ff !important; font-family:Helvetica, Arial, sans-serif; font-size:18px; letter-spacing:-.5px; line-height:115%; margin:0; padding:0; text-align:center;">'.$memName.'</h3>



                                                <br />



                                               Your new password is '." ".$pass.'.



                                            </td>



                                        </tr>



                                        <tr>



                                            <td align="center" valign="middle" style="padding-right:40px; padding-bottom:40px; padding-left:40px;">



                                                <table border="0" cellpadding="0" cellspacing="0" class="emailButton" style="background-color:#6DC6DD; border-collapse:separate !important; border-radius:3px;">



                                                    



                                                </table>



                                            </td>



                                        </tr>



                                    </table>



                                </td>



                            </tr>



                            <tr>



                            	<td align="center" valign="top">



                                 	<table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">



                                    	<tr>



                                        	<td align="center" valign="top" class="footerContent" style="color:#606060; font-family:Helvetica, Arial, sans-serif; font-size:10px; line-height:125%;">



                                           The information contained in and accompanying this communication may be confidential, subject to legal privilege, or otherwise protected from disclosure, and is intended solely for the use of the intended recipient(s). 



                                                <br />



                                               



                                            </td>



                                        </tr>



                                        <tr>



                                        	<td align="center" valign="top" style="padding-top:30px;">



                                            	<a style="color:#0073e6;text-decoration:none" href="'.$baseurl.'">'.$baseurl.'</a>



                                            </td>



                                        </tr>



										 <tr>



                                        	<td align="center" valign="top" style="padding-top:30px;color:#f2f2f2;">'.date("h:m:i").'</td>



                                        </tr>



                                    </table>



                                </td>



                            </tr>



                        </table>



                        



                        </td>



                        </tr>



                        </table></body><html>';



return $msg;



}

function randomPassword($conn) {



    $alphabet = "0123456789";



    $pass = array(); //remember to declare $pass as an array



    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache



    for ($i = 0; $i < 6; $i++) {



        $n = rand(0, $alphaLength);



        $pass[] = $alphabet[$n];



    }



    return implode($pass); //turn the array into a string



}

function getAdminDetailById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `admin` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}
function getPackageDetailById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `packages` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}
function getAdminNameById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `admin` WHERE  `id`='$cid'  ")); 
	 return $ds2['name'];
	 
}
function sendBasicMail($to,$from,$fromname,$subject,$msg){

	$headers = 'MIME-Version: 1.0 \r\n'.
		'Content-type: text/html \r\n'.
		'X-Mailer: PHP/' . phpversion();
		$mail = new PHPMailer();
		$mail->IsSMTP();                                      // Set mailer to use SMTP
		$mail->IsHTML(true);
		$mail->From = $from;
		$mail->FromName =$fromname;
		$mail->SMTPAuth = false;
		$mail->AddAddress($to);
		$mail->Subject = $subject;
		$mail->Body    = $msg;
		$mail=$mail->Send();
		if($mail){
		return true;
		}else{
		return false;
		}   
}

function getLocationsByCountry($conn,$cid){
$location=array();
//echo "SELECT * FROM `locations` where `countryid`='$cid' and `view` ='1'";
$ds=mysqli_query($conn,"SELECT * FROM `location` where `countryid`='$cid' and `view` ='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $location[]=$fetch['id'];
		}
	}
	
return $location;	
}

function getcontentpagesbyid($conn,$code){
	$ds=mysqli_query($conn,"SELECT * FROM `contentpages` where `type`='$code'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getTableDetailsById($conn,$table,$id){
	//echo "SELECT * FROM $table where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM $table where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
}
function getYesNoByValue($conn,$value){
	 
	if($value==1){
		return "<span style='color:#6C9100'>Yes</span>";	
	}
	if($value==0){
		return "<span style='color:#A9454A'>No</span>";	
	}
 
}
function getSiteName($conn){
   $curDate=date("Y-m-d");
   $ds=mysqli_query($conn,"SELECT `name`  FROM `generalsettings` where   `id`='1' "); 
   $ds1=mysqli_fetch_assoc($ds);
   return $ds1['name'];
 
} 
function getColoumnNameById($conn,$col,$table,$id){
	
	$ds=mysqli_query($conn,"SELECT $col FROM  $table where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1[$col];
}
function getNQfeaturessById($conn,$cid){
$location=array();
//echo "SELECT * FROM `locations` where `countryid`='$cid' and `view` ='1'";
$ds=mysqli_query($conn,"SELECT * FROM `edu_pricingnonqfeatures` where `pricingid`='$cid' and `view` ='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $location[]=$fetch['nqfeatureid'];
		}
	}
	
return $location;	
}

function getQfeaturessById($conn,$cid){
$location=array();
$ds=mysqli_query($conn,"SELECT * FROM `edu_pricingqfeatures` where `pricingid`='$cid' and `view` ='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		     $qfid=$fetch['qfeatureid'];
			 $location[$qfid]=$fetch['sets'];
		}
	}
	
return $location;	
}

function getQfeaturessByIdnew($conn,$cid){
$location=array();
$ds=mysqli_query($conn,"SELECT * FROM `edu_pricingqfeatures` where `pricingid`='$cid' and `view` ='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		     $qfid=$fetch['qfeatureid'];
			 $location[]=$fetch['qfeatureid'];
		}
	}
	
return $location;	
}
function getSchoolsDetailById($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `schools` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}
function getSubjectdetails($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `subjects` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}

function getsubtypedetails($conn,$cid){
	 $ds2=mysqli_fetch_assoc(mysqli_query($conn,"SELECT  * FROM `subtype` WHERE  `id`='$cid'  ")); 
	 return $ds2;
	 
}
function getattachedtopicsids($conn,$cid){
	 $ds2=mysqli_query($conn,"SELECT  * FROM `attachedtopics` WHERE  `subtype_id`='$cid' and `status`='1' and `view`='1'"); 

while($resultset=mysqli_fetch_array($ds2))
{
	
	$resultarr[]=$resultset['id'];
	
		 
}
return $resultarr; 
}

function getallAttachedIdwithSubId($conn,$cid,$level){
	 $ds2=mysqli_query($conn,"SELECT  * FROM `attachedtopics` WHERE  `subject_id`='$cid' and `status`='1' and `view`='1'"); 

while($resultset=mysqli_fetch_array($ds2))
{
	$amtid=$resultset['attachedid'];
		 $ds=mysqli_query($conn,"SELECT  * FROM `levelsubjects` WHERE  `id`='$amtid' and `level_id`='$level' and `status`='1' and `view`='1'"); 
if($num=mysqli_num_rows($ds)>0)
{
	
	
	$resultarr[]=$resultset['id'];
	
}
}
return $resultarr; 
}
function getattachedtopiccount($conn,$cid){
	 $ds2=mysqli_num_rows(mysqli_query($conn,"SELECT  * FROM `attachedtopics` WHERE  `subtype_id`='$cid' and `view`='1'"));
		 return $ds2;
 
}

function getattachedtopiccountwithsubid($conn,$name,$hidsubid1)
{
	
	$ds2=mysqli_num_rows(mysqli_query($conn,"SELECT  * FROM `attachedtopics` WHERE  `subtype_id`='$cid' and `topics`='$name'"));
		 return $ds2;
	
	
	
}

function getColoumnNameByIdtableval($conn,$col,$table,$id){
	$ds=mysqli_query($conn,"SELECT $col FROM  $table where `id`='$id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1[$col];
}

    
function getQuestionCountfromTopicId($conn,$hidsubid1)
{
	
	$ds2=mysqli_num_rows(mysqli_query($conn,"SELECT  * FROM `questions` WHERE  `topic_id`='$hidsubid1'"));
		 return $ds2;
	
	
	
}

function getLocationIdfromCountryId($conn,$countryid)
{
	
	
	  $query="SELECT location.id FROM location INNER JOIN country ON country.id = location.countryid where country.id=$countryid;";
		$ds=mysqli_query($conn,$query); 
		while($result=mysqli_fetch_array($ds))
		{
$ds1[]=$result[0];
		}
	return $ds1;
	
}
function getschoolsfromLocationId($conn,$lid)
{
	
	
	
	
	  $query="SELECT schools.id FROM schools INNER JOIN location ON location.id = schools.locationid where location.id=$lid and schools.status=1";
		$ds=mysqli_query($conn,$query); 
		while($result=mysqli_fetch_array($ds))
		{
$ds1[]=$result[0];
		}
	return $ds1;
	

	
	
	
}

function getSchoollocationcount($conn,$lid)
{
	$ds2=mysqli_num_rows(mysqli_query($conn,"SELECT  * FROM `schools` WHERE  `locationid`='$lid'"));
		 return $ds2;
	
	
}

function getlevelIdfromslug($conn,$slug)
{	
	$ds=mysqli_query($conn,"SELECT `id` FROM  `edu_levels` where `slug`='$slug'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['id'];
	
	
}

function getsubjectIdfromAttachedId($conn,$aid)
{
	$ds=mysqli_query($conn,"SELECT `subject_id` FROM  `levelsubjects` where `id`='$aid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['subject_id'];
	
	
	
	
}


function checkemailExistence($conn,$email)
{
$ds2=mysqli_num_rows(mysqli_query($conn,"SELECT  * FROM `register` WHERE  `email`='$email'"));
		 return $ds2;
	


}

function gettest_statusfromTestId($conn,$tid,$userid,$sid,$lid,$tids)
{ 
	//echo "SELECT * FROM  `testgiven` where `userid`='$userid' and `subject_id`='$sid' and `levelid`='$lid' and `testname`='$tids' order by `id` desc";
	$ds=mysqli_query($conn,"SELECT * FROM  `testgiven` where `userid`='$userid' and `subject_id`='$sid' and `levelid`='$lid' and `testname`='$tids' order by `id` desc"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows>0)
	{
	$ds1=mysqli_fetch_assoc($ds);
	}
	else
	{
		$ds1='';
		
	}
	return $ds1;
	
	
}
function getminitest_statusfromTestId($conn,$lid,$userid,$sid)
{ 
	//echo "SELECT * FROM  `minitestgiven` where `userid`='$userid' and `subject_id`='$sid' and `levelid`='$lid' and `testname`='$tids' order by `id` desc";
	$ds=mysqli_query($conn,"SELECT * FROM  `minitestgiven` where `userid`='$userid' and `subject_id`='$sid' and `levelid`='$lid'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows>0)
	{
	$ds1=mysqli_fetch_assoc($ds);
	}
	else
	{
		$ds1='';
		
	}
	return $ds1;
	
	
}	function getdifficultyfromQId($conn,$question_id)
	{
		
	
	
	
	$ds=mysqli_query($conn,"SELECT `difficulty` FROM  `questions` where `id`='$question_id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['difficulty'];
	
	
	
		
		
	}
	
	function getAdminanswerfromquestionid($conn,$question_id)
	{
		
	
	
	$ds=mysqli_query($conn,"SELECT `correct` FROM  `questions` where `id`='$question_id'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['correct'];
	
	
	
		
		
	}
	function checkCartproductexist($conn,$lid,$pid){
	$count=-1;
	$status=0;
	foreach($_SESSION['cart_array']["bags"] as $arr){
	$count++;
	if(($arr[0]==$lid)&&($arr[1]==$pid)){
		$status=1;
	}
	
	}
	
	return $status;
	
	
}
function updatecart($conn,$lid,$pid,$type){
	
$count=-1;
   foreach($_SESSION['cart_array']["bags"] as $arr){
	if(($arr[0]==$lid) &&(($arr[1]==$pid))){
		   $count++;

		   $oldQty=$_SESSION['cart_array']["bags"][$count][2];
		$qty=1;
		if($type==1)
		
		{
		  $_SESSION['cart_array']["bags"][$count][2]=$oldQty+$qty;
		}
		else
		{
					  $_SESSION['cart_array']["bags"][$count][2]=$oldQty-$qty;

			
		}
			// print_r($_SESSION['cart_array']["bags"]);       

	}
	   
   }
   return true;	
	
}
function orderidbyUserid($conn,$userid){
	$ds=mysqli_query($conn,"SELECT * FROM `orders` where `userid`='$userid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1;
 
}
	function getBoughtPackagefromOid($conn,$id){
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `orderlist` where `orderid`='$id'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $data[]=$fetch['planid'];
		}
	}
	//$improaster=implode(",",$data);
	return $data;
}


function getAttemptedQuestionsfromTestId($conn,$testgivenid)
{//	$ds=mysqli_query($conn,"SELECT * FROM `testattempted` where `testid`='$testgivenid' and `button`='0' order by `id` desc"); 
//echo "SELECT * FROM `testattempted` where `testid`='$testgivenid' and `answer`!=0 order by `id` desc";
	
	$ds=mysqli_query($conn,"SELECT * FROM `testattempted` where `testid`='$testgivenid' and `answer`!=0 order by `id` desc"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows=='')
	{
		$numrows=0;
	}
		
		
	return $numrows;
	
	
	
}

function getTotalquesfromTopicId($conn,$tid)
{
	
	
	//echo "SELECT * FROM `seminars` where `id`='$id'";
	$ds=mysqli_query($conn,"SELECT * FROM `questions` where `topic_id`='$tid' and `status`='1' and `view`='1'"); 
	$numrows=mysqli_num_rows($ds);
	if($numrows >0){
		while($fetch=mysqli_fetch_array($ds)){
		
			 $data[]=$fetch['id'];
		}
	}
	//$improaster=implode(",",$data);
	return $data;

	
	
}

function GetUserCorrectAnsFromTidQid($conn,$qid,$tid)
{
	
	$ds=mysqli_query($conn,"select * from `testattempted` where `questionid`='$qid' and `testid`='$tid' and `buttonval`!='0'");  
	$numrows=mysqli_fetch_assoc($ds);
	
	return $numrows;
	
	
	

	
	
}

function GetActiveQuesFromTopicId($conn,$strings)
{
	
	
	$ds=mysqli_query($conn,"select * from `questions` where `topic_id` in ($strings) and `status`='1' and `view`='1'"); 
$numrows=mysqli_num_rows($ds);
	
	return $numrows;
	
	
	

	
	
}
function GetSubjectsidsfromLevelid($conn,$level){
$ds=mysqli_query($conn,"SELECT  * FROM `levelsubjects` WHERE  `level_id`='$level' and `status`='1' and `view`='1'");
if($num=mysqli_num_rows($ds)>0)
{
	
while($resultset=mysqli_fetch_array($ds))
{
	$amtid=$resultset['subject_id'];
		  

	
	$resultarr[]=$amtid;
	
}
}
return $resultarr; 
}


function getdetailsfromUserIdandSubjectId($conn,$userid,$sid)
{
	
	$ds=mysqli_query($conn,"select * from `testgiven` where `userid`='$userid' and `subject_id`='$sid' order by `id` desc limit 0,1"); 
	
	$numrows=mysqli_num_rows($ds);
	if($numrows>0)
	{
$resultset=mysqli_fetch_assoc($ds);
	}
	
	else
	{
	$resultset='';	
		
	}
	return $resultset;
	
	
	
}
function sendgridmail($to,$message,$subject)
{
$email = new \SendGrid\Mail\Mail(); 
$email->setFrom("sardar@brandsforless.in", "Bosh Education");
$email->setSubject($subject);
$email->addTo($to, "Bosh Education");

$email->addContent(
    "text/html",$message
);
//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
$sendgrid = new \SendGrid('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');
try {
    $response = $sendgrid->send($email);
    $response->statusCode() . "\n";
   $response->headers();
   $response->body() . "\n";
} catch (Exception $e) {
    echo 'Caught exception: '. $e->getMessage() ."\n";
}
}


function GetPausedquestionIdfromTestId($conn,$testgivenid)
{//	$ds=mysqli_query($conn,"SELECT * FROM `testattempted` where `testid`='$testgivenid' and `button`='0' order by `id` desc"); 

	
	$ds=mysqli_query($conn,"SELECT * FROM `testattempted` where `testid`='$testgivenid'"); 
	while($resultset=mysqli_fetch_array($ds))
	{
		
		$data[]=$resultset['questionid'];
		
		
	}
		
		
	return $data;
	
	
	
}
function getmainLevelidfromId($conn,$lid)
{ //echo "SELECT `level_id` FROM  `levelsubjects` where `id`='$lid'"; die;
	$ds=mysqli_query($conn,"SELECT `level_id` FROM  `levelsubjects` where `id`='$lid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['level_id'];
	
	
	
	
}

function getattachedMainLevelidfromSIdLecelId($conn,$sid,$lid)
{ 
	$ds=mysqli_query($conn,"SELECT `id` FROM  `levelsubjects` where `subject_id`='$sid' and `level_id`='$lid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['id'];
	
	
	
	
}

function getExistenceofTestIdWithPracticeIdLid($conn,$test_name,$levelids,$userid)
{      
	//userid also   
	//$ds=mysqli_query($conn,"SELECT `id` FROM  `testgiven` where `testname`='$test_name' and `levelid`='$levelids' and `userid`='$userid'"); 
		$ds=mysqli_query($conn,"SELECT `id` FROM  `testgiven` where `id`='$test_name' and `levelid`='$levelids' and `userid`='$userid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['id'];
	
	
	
}

function getMiniExistenceofTestIdWithPracticeIdLid($conn,$test_name,$levelids,$userid)
{      
	//userid also   
	//echo "SELECT `id` FROM  `minitestgiven` where `testname`='$test_name' and `levelid`='$levelids' and `userid`='$userid'";  die;   
		$ds=mysqli_query($conn,"SELECT `id` FROM  `minitestgiven` where `id`='$test_name' and `levelid`='$levelids' and `userid`='$userid'"); 
	$ds1=mysqli_fetch_assoc($ds);
	return $ds1['id'];
	
	
	
}
?>  