


<link rel="icon" href="img/fav/favicon-96x96.png">

    <!-- Touch Icons - iOS and Android 2.1+ -->
    <link rel="apple-touch-icon" href="img/fav/android-icon-48x48.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/fav/android-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/fav/apple-icon-114x114.png" />
      <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>

    <!--bootstrap v4.0.0-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/material-kit.min.css">
    <!--animate-->
    <link rel="stylesheet" type="text/css" href="css/aos.css">
    <!--reset css-->
    <link rel="stylesheet" type="text/css" href="css/normalize.css">
    
    <!--owl-carousel-->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <!--pop up css-->
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
    <!--swiper css-->
    <link rel="stylesheet" type="text/css" href="css/swiper.css">
    <!--fontawesome cdn-->
    <!--animation spin css-->
    <link rel="stylesheet" type="text/css" href="css/animation-spin.css">
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <!--main style-->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <link href="https://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:400,500,600,700,900" rel="stylesheet">

    <!--modernizr-->
    <script src="js/vendor/modernizr.js"></script>

    <!--[if lt IE 9]>
    <script src="js/html5/respond.min.js"></script>
    <![endif]-->
    
    <style>
    a.navbar-brand img {
    width: 190px;
    }
	 div#loaders {
    position: absolute;
    top: 50%;
    left: 0; 
    right: 0;
    text-align: center;
}
    </style>


